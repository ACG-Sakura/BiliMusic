# V0.4.33 Release Status

## 本版修复
- 修复 V0.4.32 GitHub Actions 的 npm 安装步骤：不再依赖 `npm install --prefix netease-api` 的相对路径解析。
- Windows PowerShell 工作流显式切换到 `netease-api` 目录，检查该目录的 `package.json`，执行 npm install，并确认 API 依赖和 Node.js runtime 已生成。
- 本地 `build_windows.bat` 同步采用 `pushd netease-api` 的方式，避免本地与 Actions 行为不一致。
- 归档文件、解压目录、版本元数据、窗口标题、User-Agent 和 Artifact 名称统一为 `0.4.33`。

## Verification in this development environment
- Python automated tests: **68 passed** (`python -m pytest -q`).
- Python compile check: passed (`python -m compileall -q app tests main.py`).
- Node syntax check: passed (`node --check netease-api/server.js`).
- Workflow YAML parsing: passed.
- ZIP structure: validated to contain `BiliMusic_V0.4.33/netease-api/package.json` and `server.js`.
- GitHub Actions Windows build: not yet rerun after this fix.
- Real NetEase QR login, playback, GUI, and OBS acceptance: not performed here.
