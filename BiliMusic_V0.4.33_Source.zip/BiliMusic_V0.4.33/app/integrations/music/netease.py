"""NetEase Cloud Music client for the app-owned loopback API service.

The desktop app talks only to a local service bound to 127.0.0.1. Account
cookies are sent in the HTTP Cookie header and are stored by the UI through
Windows DPAPI; they are never written to SQLite, settings JSON, or logs.
"""
from __future__ import annotations

import base64
import ipaddress
import json
import re
import time
from dataclasses import dataclass
from typing import Any, Callable
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlencode, urlparse
from urllib.request import Request, urlopen


QUALITY_LEVELS = ("standard", "higher", "exhigh", "lossless", "hires")


class NeteaseError(RuntimeError):
    """A local API, authentication, or media-resolution error."""


@dataclass(frozen=True, slots=True)
class NeteaseTrack:
    external_id: str
    title: str
    artist: str
    album: str = ""
    duration_ms: int = 0
    fee: int = 0

    @property
    def external_url(self) -> str:
        return f"https://music.163.com/#/song?id={self.external_id}"


@dataclass(frozen=True, slots=True)
class NeteasePlaylist:
    playlist_id: str
    name: str
    description: str
    cover_url: str
    total_count: int
    tracks: tuple[NeteaseTrack, ...]


@dataclass(frozen=True, slots=True)
class QRCodeResult:
    key: str
    image_data_uri: str


@dataclass(frozen=True, slots=True)
class QRLoginStatus:
    code: int
    message: str
    cookie: str = ""


def parse_netease_playlist_id(source_ref: str) -> str:
    value = (source_ref or "").strip()
    if value.isdigit():
        return value
    parsed = urlparse(value if "://" in value else f"https://{value}")
    query_candidates = parse_qs(parsed.query).get("id", [])
    if "?" in parsed.fragment:
        query_candidates += parse_qs(parsed.fragment.split("?", 1)[1]).get("id", [])
    for candidate in query_candidates:
        if candidate.isdigit():
            return candidate
    match = re.search(r"/playlist/(\d+)", parsed.path + "/" + parsed.fragment, re.I)
    if match:
        return match.group(1)
    raise ValueError("无法识别网易云歌单 ID。请填写数字 ID 或 music.163.com 歌单链接。")


def _artist_text(raw: dict[str, Any]) -> str:
    values = raw.get("ar") or raw.get("artists") or []
    names = [str(item.get("name", "")).strip() for item in values if isinstance(item, dict)]
    return " / ".join(name for name in names if name) or "未知歌手"


def _track_from_raw(raw: dict[str, Any]) -> NeteaseTrack | None:
    track_id = raw.get("id")
    title = str(raw.get("name") or "").strip()
    if not track_id or not title:
        return None
    album_obj = raw.get("al") or raw.get("album") or {}
    album = str(album_obj.get("name") or "") if isinstance(album_obj, dict) else ""
    return NeteaseTrack(
        str(track_id), title, _artist_text(raw), album,
        int(raw.get("dt") or raw.get("duration") or 0), int(raw.get("fee") or 0),
    )


class NeteaseApiClient:
    """Small, testable HTTP client for the loopback NetEase API service."""

    def __init__(self, base_url: str = "http://127.0.0.1:3000", cookie: str = "",
                 timeout: float = 15.0, opener: Callable = urlopen):
        parsed = urlparse(base_url)
        host = parsed.hostname or ""
        try:
            loopback = ipaddress.ip_address(host).is_loopback
        except ValueError:
            loopback = host.lower() == "localhost"
        if parsed.scheme != "http" or not loopback:
            raise ValueError("网易云 API 地址必须是本机 HTTP 回环地址（127.0.0.1 / localhost）。")
        self.base_url = base_url.rstrip("/")
        self.cookie = (cookie or "").strip()
        self.timeout = float(timeout)
        self._opener = opener

    def with_cookie(self, cookie: str) -> "NeteaseApiClient":
        return NeteaseApiClient(self.base_url, cookie, self.timeout, self._opener)

    def _get(self, path: str, params: dict[str, Any] | None = None) -> tuple[dict[str, Any], str]:
        query = dict(params or {})
        query.setdefault("timestamp", int(time.time() * 1000))
        url = f"{self.base_url}{path}?{urlencode(query, doseq=True)}"
        headers = {"Accept": "application/json", "User-Agent": "BiliMusic/0.4.33"}
        if self.cookie:
            headers["Cookie"] = self.cookie
        request = Request(url, headers=headers, method="GET")
        try:
            with self._opener(request, timeout=self.timeout) as response:
                raw = response.read(8 * 1024 * 1024 + 1)
                response_headers = getattr(response, "headers", {})
        except HTTPError as exc:
            raise NeteaseError(f"网易云本地 API 返回 HTTP {exc.code}。") from exc
        except (URLError, TimeoutError, OSError) as exc:
            raise NeteaseError("无法连接本机网易云 API 服务，请检查服务是否正常启动。") from exc
        if len(raw) > 8 * 1024 * 1024:
            raise NeteaseError("网易云 API 返回内容超过 8 MB，已停止读取。")
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise NeteaseError("网易云 API 返回了无法识别的数据。") from exc
        if not isinstance(payload, dict):
            raise NeteaseError("网易云 API 返回结构不正确。")
        code = payload.get("code")
        if code not in (None, 200, 800, 801, 802, 803):
            message = str(payload.get("message") or payload.get("msg") or "请求未成功")
            raise NeteaseError(f"网易云 API 请求失败：{message}（code={code}）。")
        set_cookie = ""
        try:
            raw_cookie = response_headers.get_all("Set-Cookie") or []
            set_cookie = "; ".join(part.split(";", 1)[0] for part in raw_cookie if "=" in part)
        except (AttributeError, TypeError):
            pass
        return payload, set_cookie

    def ping(self) -> bool:
        try:
            self._get("/search", {"keywords": "BiliMusic", "type": 1, "limit": 1})
            return True
        except NeteaseError:
            return False

    def qr_login_create(self) -> QRCodeResult:
        data, _ = self._get("/login/qr/key", {"noCookie": "true"})
        key = str((data.get("data") or {}).get("unikey") or "").strip()
        if not key:
            raise NeteaseError("网易云未返回扫码登录 key。")
        image, _ = self._get("/login/qr/create", {"key": key, "qrimg": "true", "noCookie": "true"})
        qr_data = image.get("data") or {}
        image_uri = str(qr_data.get("qrimg") or "").strip()
        if not image_uri:
            qr_url = str(qr_data.get("qrurl") or "").strip()
            if not qr_url:
                raise NeteaseError("网易云未返回二维码图片。")
            # Some API versions return a URL rather than a data URI. The UI
            # handles only locally-rendered QR images to avoid external images.
            raise NeteaseError("当前 API 版本只返回二维码链接，无法在本机安全显示二维码图片。")
        return QRCodeResult(key, image_uri)

    def qr_login_check(self, key: str) -> QRLoginStatus:
        # Omit noCookie entirely: the API server interprets the literal string
        # "false" as truthy in JavaScript and would suppress Set-Cookie headers.
        payload, header_cookie = self._get("/login/qr/check", {"key": key})
        code = int(payload.get("code") or 0)
        data = payload.get("data") or {}
        cookie = str(data.get("cookie") or payload.get("cookie") or header_cookie or "").strip()
        message = str(payload.get("message") or payload.get("msg") or data.get("message") or "")
        return QRLoginStatus(code, message, cookie)

    def login_status(self) -> dict[str, Any]:
        payload, _ = self._get("/login/status")
        data = payload.get("data") or {}
        profile = data.get("profile") or (data.get("account") or {})
        return profile if isinstance(profile, dict) else {}

    def search(self, keyword: str, limit: int = 10) -> list[NeteaseTrack]:
        keyword = (keyword or "").strip()
        if not keyword:
            return []
        payload, _ = self._get("/search", {"keywords": keyword, "type": 1, "limit": max(1, min(int(limit), 50)), "offset": 0})
        result = payload.get("result") or {}
        raw_songs = result.get("songs") or []
        return [track for raw in raw_songs if isinstance(raw, dict) if (track := _track_from_raw(raw))]

    def fetch_playlist(self, source_ref: str, page_size: int = 500) -> NeteasePlaylist:
        playlist_id = parse_netease_playlist_id(source_ref)
        payload, _ = self._get("/playlist/detail", {"id": playlist_id, "limit": 1})
        detail = payload.get("playlist") or {}
        if not detail:
            raise NeteaseError("网易云没有返回歌单信息，请确认链接及账号权限。")
        total = int(detail.get("trackCount") or 0)
        tracks: list[NeteaseTrack] = []
        offset = 0
        page_size = max(1, min(int(page_size), 1000))
        while offset < total or (offset == 0 and total == 0):
            page, _ = self._get("/playlist/track/all", {"id": playlist_id, "limit": page_size, "offset": offset})
            raw_songs = page.get("songs") or []
            if not isinstance(raw_songs, list) or not raw_songs:
                break
            tracks.extend(track for raw in raw_songs if isinstance(raw, dict) if (track := _track_from_raw(raw)))
            offset += len(raw_songs)
            if len(raw_songs) < page_size or (total > 0 and offset >= total):
                break
        return NeteasePlaylist(
            playlist_id, str(detail.get("name") or "网易云歌单"),
            str(detail.get("description") or ""), str(detail.get("coverImgUrl") or ""),
            total, tuple(tracks),
        )

    def song_url(self, song_id: str | int, level: str = "exhigh") -> str:
        """Resolve a normal account-authorized stream, lowering quality if needed.

        This only retries the provider's ordinary song URL endpoint at lower
        quality levels. Preview-only responses are rejected; no unlock/proxy or
        alternate-source fallback is attempted.
        """
        if level not in QUALITY_LEVELS:
            level = "exhigh"
        highest_index = QUALITY_LEVELS.index(level)
        attempts = tuple(reversed(QUALITY_LEVELS[: highest_index + 1]))
        last_reason = "该歌曲当前没有完整可播放的资源。"
        for candidate in attempts:
            payload, _ = self._get("/song/url/v1", {"id": str(song_id), "level": candidate})
            entries = payload.get("data") or []
            row = entries[0] if isinstance(entries, list) and entries else {}
            url = str(row.get("url") or "").strip() if isinstance(row, dict) else ""
            parsed = urlparse(url)
            trial = row.get("freeTrialInfo") if isinstance(row, dict) else None
            if trial is None and parsed.scheme in {"http", "https"} and parsed.netloc:
                return url
            if trial is not None:
                last_reason = "当前账号只能获取试听片段或该歌曲受播放权限限制。"
            else:
                last_reason = str(row.get("message") or payload.get("message") or last_reason) if isinstance(row, dict) else last_reason
        raise NeteaseError(last_reason + "已尝试所选音质及可用的较低音质，歌曲已跳过。")

    def resolve_request(self, title: str, artist: str = "", level: str = "exhigh") -> NeteaseTrack:
        candidates = self.search(" ".join(x for x in (title, artist) if x), limit=12)
        if not candidates:
            raise NeteaseError(f"网易云没有搜索到《{title}》。")
        normalized = lambda value: "".join((value or "").casefold().split())
        target_title, target_artist = normalized(title), normalized(artist)
        exact = [track for track in candidates if normalized(track.title) == target_title]
        selected = next((track for track in exact if target_artist and target_artist in normalized(track.artist)), None)
        selected = selected or (exact[0] if exact else candidates[0])
        return selected

    @staticmethod
    def decode_qr_image(data_uri: str) -> bytes:
        prefix = "base64,"
        if prefix not in data_uri:
            raise NeteaseError("二维码图片格式不正确。")
        try:
            return base64.b64decode(data_uri.split(prefix, 1)[1], validate=True)
        except (ValueError, TypeError) as exc:
            raise NeteaseError("二维码图片数据无法解码。") from exc
