from pathlib import Path
import json


def test_netease_package_manifest_is_inside_service_directory():
    root = Path(__file__).resolve().parents[1]
    manifest = root / "netease-api" / "package.json"
    assert manifest.is_file()
    data = json.loads(manifest.read_text(encoding="utf-8"))
    assert "@neteasecloudmusicapienhanced/api" in data["dependencies"]
    assert (root / "netease-api" / "server.js").is_file()


def test_windows_build_uses_explicit_netease_service_directory():
    root = Path(__file__).resolve().parents[1]
    script = (root / "build_windows.bat").read_text(encoding="utf-8")
    assert "pushd netease-api" in script.lower()
    assert "npm install --omit=dev" in script
    assert "npm install --prefix netease-api" not in script
