from pathlib import Path
import json


def test_netease_package_manifest_is_inside_service_directory():
    root = Path(__file__).resolve().parents[1]
    manifest = root / "netease-api" / "package.json"
    assert manifest.is_file()
    data = json.loads(manifest.read_text(encoding="utf-8"))
    assert "@neteasecloudmusicapienhanced/api" in data["dependencies"]
    assert (root / "netease-api" / "server.js").is_file()


def test_windows_build_uses_explicit_netease_service_directory():
    root = Path(__file__).resolve().parents[1]
    script = (root / "build_windows.bat").read_text(encoding="utf-8")
    assert "pushd netease-api" in script.lower()
    assert "npm install --omit=dev" in script
    assert "npm install --prefix netease-api" not in script


def test_ci_verifies_pyinstaller6_internal_netease_layout():
    root = Path(__file__).resolve().parents[1]
    workflow = (root / ".github" / "workflows" / "build-windows.yml").read_text(encoding="utf-8")
    assert "Join-Path $dist '_internal/netease-api'" in workflow
    assert "Join-Path $dist 'netease-api'" in workflow
    service = (root / "app" / "integrations" / "music" / "netease_service.py").read_text(encoding="utf-8")
    assert "meipass / \"netease-api\"" in service or 'meipass / "netease-api"' in service


def test_ci_extracts_versioned_source_zip_before_locating_project_root():
    root = Path(__file__).resolve().parents[1]
    workflow = (root / ".github" / "workflows" / "build-windows.yml").read_text(encoding="utf-8")
    extract_step = workflow.index("Extract and locate V0.4.35 source archive")
    expand_archive = workflow.index("Expand-Archive -LiteralPath $archive")
    locate_marker = workflow.index("$projectCandidates = Get-ChildItem")
    assert "BiliMusic_V0.4.35_Source.zip" in workflow
    assert extract_step < expand_archive < locate_marker
    assert "$env:RUNNER_TEMP" in workflow
    assert "BILIMUSIC_PROJECT=$project" in workflow
