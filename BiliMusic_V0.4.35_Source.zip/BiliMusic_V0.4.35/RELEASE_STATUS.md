# V0.4.35 Release Status

## 本版修复
- GitHub Actions 第 28 次构建的失败点是 `Locate and validate source tree`：GitHub 仓库顶层只有 `BiliMusic_V0.4.34_Source.zip`，工作流未解压归档就递归搜索 `pyproject.toml`，因此找不到项目根目录。
- V0.4.35 工作流会先检查版本化源码 ZIP，解压到 `$RUNNER_TEMP`，再定位项目根目录并校验关键文件。
- 解压失败、ZIP 名称不符或目录结构不完整时，工作流会给出实际找到的 ZIP 名称或解压目录清单。
- PyInstaller 输出检查会同时识别 `_internal/netease-api` 与顶层 `netease-api` 两种布局，并确保 EXE、Node.js 与网易云 API 包 manifest 均存在。
- 增加 CI 回归测试，锁定“先解压、后定位”的顺序。

## 本地验证
- V0.4.34 基线测试：69 项通过（在开始本次版本更新前实际运行）。
- V0.4.35 自动化测试、Python 编译、YAML 解析和 ZIP 校验结果：以本轮开发环境实际执行结果为准，不能替代 GitHub Windows runner 构建。
- GitHub Actions Windows 构建：尚未对 V0.4.35 运行。
- 网易云真实扫码、会员曲目播放、Windows GUI 与 OBS 直播验收：尚未完成。
