from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QLabel, QPushButton,
    QListWidget, QStackedWidget, QFrame, QTableWidget, QTableWidgetItem,
    QHeaderView, QLineEdit, QMessageBox, QSpinBox, QFormLayout, QGridLayout,
    QAbstractItemView, QTextEdit, QComboBox, QColorDialog,
)

from app.core.queue_service import QueueService
from app.core.settings import SettingsStore
from app.storage.database import Database

def build_md3_style(mode: str = "dark", accent: str = "#6750A4") -> str:
    """Token-based Material 3 inspired palette for the Qt widget layer."""
    dark = mode == "dark"
    if dark:
        c = {"bg":"#141218", "surface":"#1D1B20", "surface2":"#211F26", "surface3":"#2B2930",
             "text":"#E6E1E5", "muted":"#CAC4D0", "outline":"#49454F", "selected":"#4A4458",
             "onaccent":"#FFFFFF", "field":"#2B2930", "tablealt":"#25232A"}
    else:
        c = {"bg":"#FEF7FF", "surface":"#F7F2FA", "surface2":"#F3EDF7", "surface3":"#ECE6F0",
             "text":"#1D1B20", "muted":"#625D67", "outline":"#79747E", "selected":"#E8DEF8",
             "onaccent":"#FFFFFF", "field":"#F3EDF7", "tablealt":"#F3EDF7"}
    return f"""
    QWidget {{ background: {c['bg']}; color: {c['text']}; font-family: \"Microsoft YaHei UI\", \"Microsoft YaHei\"; font-size: 13px; }}
    QFrame#Sidebar {{ background: {c['surface']}; border-right: 1px solid {c['outline']}; }}
    QLabel#Brand {{ font-size: 23px; font-weight: 800; color: {accent}; padding: 14px 8px 20px 8px; }}
    QLabel#PageTitle {{ font-size: 25px; font-weight: 700; }}
    QLabel#Muted {{ color: {c['muted']}; }}
    QLabel#Value {{ font-size: 25px; font-weight: 700; color: {c['text']}; }}
    QPushButton {{ background: {c['surface3']}; color: {c['text']}; border: 1px solid {c['outline']}; border-radius: 20px; padding: 10px 18px; min-height: 20px; }}
    QPushButton:hover {{ background: {c['selected']}; }}
    QPushButton:disabled {{ color: {c['muted']}; background: {c['surface']}; }}
    QPushButton#Primary {{ background: {accent}; color: {c['onaccent']}; border: none; font-weight: 600; }}
    QPushButton#Primary:hover {{ border: 1px solid {c['text']}; }}
    QListWidget {{ background: transparent; border: none; outline: none; padding: 4px; }}
    QListWidget::item {{ padding: 13px 14px; border-radius: 20px; margin: 2px 0; }}
    QListWidget::item:selected {{ background: {c['selected']}; color: {c['text']}; }}
    QTableWidget {{ background: {c['surface']}; alternate-background-color: {c['tablealt']}; gridline-color: {c['outline']}; border: 1px solid {c['outline']}; border-radius: 12px; selection-background-color: {c['selected']}; }}
    QHeaderView::section {{ background: {c['surface3']}; color: {c['text']}; padding: 11px; border: none; }}
    QLineEdit, QSpinBox, QComboBox {{ background: {c['field']}; border: 1px solid {c['outline']}; border-radius: 10px; padding: 10px; min-height: 20px; selection-background-color: {accent}; }}
    QTextEdit {{ background: {c['surface']}; border: 1px solid {c['outline']}; border-radius: 12px; padding: 10px; }}
    QFrame#Card {{ background: {c['surface2']}; border: 1px solid {c['outline']}; border-radius: 18px; }}
    QComboBox QAbstractItemView {{ background: {c['surface']}; selection-background-color: {c['selected']}; }}
    """



class MainWindow(QMainWindow):
    def __init__(self, database: Database, settings: SettingsStore, queue: QueueService):
        super().__init__()
        self.database = database
        self.settings = settings
        self.queue = queue
        self.setWindowTitle("BiliMusic — B站主播本地点歌姬")
        self.resize(1220, 790)
        self.setMinimumSize(1020, 680)
        self.theme_mode = self.settings.get("theme_mode", "dark")
        self.accent_color = self.settings.get("accent_color", "#6750A4")
        self.apply_theme()
        self._build_layout()
        self.refresh_queue()
        self.refresh_dashboard()

    def apply_theme(self):
        mode = self.theme_mode
        if mode == "system":
            from PySide6.QtGui import QGuiApplication
            scheme = QGuiApplication.styleHints().colorScheme()
            mode = "light" if scheme == Qt.ColorScheme.Light else "dark"
        self.setStyleSheet(build_md3_style(mode, self.accent_color))

    def choose_accent(self):
        color = QColorDialog.getColor(parent=self, title="选择主题强调色")
        if color.isValid():
            self.accent_color = color.name()
            self.settings.set("accent_color", self.accent_color)
            self.apply_theme()

    def _build_layout(self) -> None:
        base = QWidget()
        outer = QHBoxLayout(base)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(210)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(14, 12, 14, 16)
        brand = QLabel("BiliMusic")
        brand.setObjectName("Brand")
        side.addWidget(brand)
        self.nav = QListWidget()
        self.nav.addItems(["控制台", "点歌队列", "点歌规则", "账号与平台", "OBS 展示", "运行日志", "系统设置"])
        self.nav.setCurrentRow(0)
        self.nav.currentRowChanged.connect(self._switch_page)
        side.addWidget(self.nav)
        side.addStretch()
        foot = QLabel("本地开发版 · V0.1.2.1")
        foot.setObjectName("Muted")
        side.addWidget(foot)
        outer.addWidget(sidebar)

        self.pages = QStackedWidget()
        self.pages.addWidget(self.dashboard_page())
        self.pages.addWidget(self.queue_page())
        self.pages.addWidget(self.rules_page())
        self.pages.addWidget(self.accounts_page())
        self.pages.addWidget(self.obs_page())
        self.pages.addWidget(self.logs_page())
        self.pages.addWidget(self.system_page())
        outer.addWidget(self.pages, 1)
        self.setCentralWidget(base)

    def _switch_page(self, index: int) -> None:
        self.pages.setCurrentIndex(index)
        if index == 0:
            self.refresh_dashboard()
        elif index == 1:
            self.refresh_queue()
        elif index == 5:
            self.refresh_logs()

    @staticmethod
    def page_shell(title: str, subtitle: str = ""):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(26, 24, 26, 24)
        layout.setSpacing(16)
        heading = QLabel(title)
        heading.setObjectName("PageTitle")
        layout.addWidget(heading)
        if subtitle:
            desc = QLabel(subtitle)
            desc.setObjectName("Muted")
            desc.setWordWrap(True)
            layout.addWidget(desc)
        return widget, layout

    @staticmethod
    def card(title: str, value: str, hint: str):
        box = QFrame()
        box.setObjectName("Card")
        layout = QVBoxLayout(box)
        label = QLabel(title)
        label.setObjectName("Muted")
        value_label = QLabel(value)
        value_label.setObjectName("Value")
        hint_label = QLabel(hint)
        hint_label.setObjectName("Muted")
        hint_label.setWordWrap(True)
        layout.addWidget(label)
        layout.addWidget(value_label)
        layout.addWidget(hint_label)
        return box

    def dashboard_page(self):
        widget, layout = self.page_shell("控制台", "BiliMusic 本地运行概览。真实直播连接和音乐播放接入尚未启用。")
        cards = QGridLayout()
        cards.addWidget(self.card("B站连接", "未连接", "直播连接器尚未接入"), 0, 0)
        cards.addWidget(self.card("当前播放", "暂无", "播放器将在后续版本接入"), 0, 1)
        cards.addWidget(self.card("待播歌曲", str(len(self.queue.list_queue())), "本地 SQLite 队列"), 0, 2)
        layout.addLayout(cards)

        panel = QFrame()
        panel.setObjectName("Card")
        panel_layout = QVBoxLayout(panel)
        heading = QLabel("开发状态")
        heading.setStyleSheet("font-size: 16px; font-weight: 700;")
        panel_layout.addWidget(heading)
        for line in (
            "✓ 桌面界面与模块化项目结构",
            "✓ SQLite 数据库与配置持久化",
            "✓ 点歌队列、优先级排序、主播跨优先级手动调整顺序",
            "✓ 主播手动添加歌曲到待播队列",
            "✓ 本地操作日志",
            "○ B站账号登录、主播身份和大会员资格验证",
            "○ B站弹幕、粉丝牌、大航海和 SC 消息接入",
            "○ 网易云 / QQ 音乐官方授权播放接入",
            "○ 自动播放、OBS 浏览器源和安装包",
        ):
            label = QLabel(line)
            label.setStyleSheet("padding: 3px 0;")
            panel_layout.addWidget(label)
        layout.addWidget(panel)
        layout.addStretch()
        return widget

    def refresh_dashboard(self):
        # Dashboard cards are intentionally informational in this prototype.
        pass

    def queue_page(self):
        widget, layout = self.page_shell("点歌队列", "主播可手动添加歌曲，并可调整整张待播队列的播放顺序；手动排序后将优先遵循主播指定顺序。")
        form = QHBoxLayout()
        self.song_title = QLineEdit()
        self.song_title.setPlaceholderText("主播手动添加：歌曲名称")
        self.song_artist = QLineEdit()
        self.song_artist.setPlaceholderText("歌手（可选）")
        add_button = QPushButton("添加到队列")
        add_button.setObjectName("Primary")
        add_button.clicked.connect(self.add_song)
        form.addWidget(self.song_title, 3)
        form.addWidget(self.song_artist, 2)
        form.addWidget(add_button)
        layout.addLayout(form)

        self.queue_table = QTableWidget(0, 7)
        self.queue_table.setHorizontalHeaderLabels(["ID", "顺序", "歌曲", "歌手", "点歌人", "类型", "优先级"])
        self.queue_table.setColumnHidden(0, True)
        self.queue_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.queue_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.queue_table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.queue_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.queue_table.setAlternatingRowColors(True)
        layout.addWidget(self.queue_table)

        actions = QHBoxLayout()
        for text, callback in (
            ("刷新", self.refresh_queue),
            ("删除选中", self.delete_selected),
            ("上移（可跨优先级）", lambda: self.move_selected(-1)),
            ("下移（可跨优先级）", lambda: self.move_selected(1)),
        ):
            button = QPushButton(text)
            button.clicked.connect(callback)
            actions.addWidget(button)
        actions.addStretch()
        layout.addLayout(actions)
        return widget

    def add_song(self):
        title = self.song_title.text().strip()
        if not title:
            QMessageBox.information(self, "提示", "请先输入歌曲名称。")
            return
        try:
            self.queue.enqueue(title, self.song_artist.text(), source="manual", kind="normal")
        except ValueError as exc:
            QMessageBox.warning(self, "无法添加", str(exc))
            return
        self.song_title.clear()
        self.song_artist.clear()
        self.refresh_queue()

    def refresh_queue(self):
        if not hasattr(self, "queue_table"):
            return
        songs = self.queue.list_queue()
        self.queue_table.setRowCount(len(songs))
        kind_names = {"normal": "普通", "captain": "舰长", "admiral": "提督", "governor": "总督", "sc": "SC"}
        for row_index, song in enumerate(songs):
            values = [str(song.id), str(row_index + 1), song.title, song.artist, song.requester_name,
                      kind_names.get(song.kind, song.kind), str(song.priority)]
            for col, value in enumerate(values):
                item = QTableWidgetItem(value)
                if col == 0:
                    item.setData(Qt.ItemDataRole.UserRole, song.id)
                self.queue_table.setItem(row_index, col, item)
        if hasattr(self, "queue_count_label"):
            self.queue_count_label.setText(f"待播歌曲：{len(songs)}")

    def selected_song_id(self) -> int | None:
        row = self.queue_table.currentRow()
        if row < 0:
            return None
        item = self.queue_table.item(row, 0)
        return int(item.text()) if item else None

    def delete_selected(self):
        song_id = self.selected_song_id()
        if song_id is None:
            return
        self.queue.remove(song_id)
        self.refresh_queue()

    def move_selected(self, direction: int):
        song_id = self.selected_song_id()
        if song_id is None:
            return
        moved = self.queue.move(song_id, direction)
        if not moved:
            QMessageBox.information(self, "无法调整", "该歌曲已在队列边界，无法继续移动。")
        self.refresh_queue()
        for row in range(self.queue_table.rowCount()):
            if int(self.queue_table.item(row, 0).text()) == song_id:
                self.queue_table.selectRow(row)
                break

    def rules_page(self):
        widget, layout = self.page_shell("点歌规则", "规则会保存在本机数据库中。粉丝牌和 SC 的真实校验要等 B站消息接入后才能生效。")
        form = QFormLayout()
        self.daily_limit = QSpinBox(); self.daily_limit.setRange(0, 999)
        self.user_cd = QSpinBox(); self.user_cd.setRange(0, 86400)
        self.global_cd = QSpinBox(); self.global_cd.setRange(0, 3600)
        self.duplicate_cd = QSpinBox(); self.duplicate_cd.setRange(0, 10080)
        self.queue_limit = QSpinBox(); self.queue_limit.setRange(0, 999)
        self.fan_level = QSpinBox(); self.fan_level.setRange(0, 40)
        controls = [
            ("每日点歌次数（0=不限）", "daily_limit", self.daily_limit),
            ("个人点歌 CD（秒）", "user_cooldown_seconds", self.user_cd),
            ("全局点歌 CD（秒）", "global_cooldown_seconds", self.global_cd),
            ("歌曲重复 CD（分钟）", "duplicate_cooldown_minutes", self.duplicate_cd),
            ("每人同时待播上限（0=不限）", "queue_limit_per_user", self.queue_limit),
            ("最低粉丝牌等级（0=不限制）", "min_fan_badge_level", self.fan_level),
        ]
        for label, key, control in controls:
            control.setValue(int(self.settings.get(key, control.value())))
            form.addRow(label, control)
        layout.addLayout(form)

        role_panel = QFrame(); role_panel.setObjectName("Card")
        role_layout = QVBoxLayout(role_panel)
        role_title = QLabel("身份默认优先级（数值越大越靠前）")
        role_title.setStyleSheet("font-weight: 700;")
        role_layout.addWidget(role_title)
        roles = self.settings.get("role_priorities", {})
        self.role_controls = {}
        role_form = QFormLayout()
        for key, label, default in (
            ("normal", "普通观众", 10), ("captain", "舰长", 20),
            ("admiral", "提督", 30), ("governor", "总督", 40), ("sc", "SC 基础优先级", 50),
        ):
            spin = QSpinBox(); spin.setRange(0, 9999)
            spin.setValue(int(roles.get(key, default)))
            self.role_controls[key] = spin
            role_form.addRow(label, spin)
        role_layout.addLayout(role_form)
        layout.addWidget(role_panel)

        sc_panel = QFrame(); sc_panel.setObjectName("Card")
        sc_layout = QVBoxLayout(sc_panel)
        sc_title = QLabel("SC 金额优先级档位")
        sc_title.setStyleSheet("font-weight: 700;")
        sc_layout.addWidget(sc_title)
        self.sc_table = QTableWidget(0, 2)
        self.sc_table.setHorizontalHeaderLabels(["SC 起始金额（元）", "优先级"])
        self.sc_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.sc_table.setMaximumHeight(180)
        self.sc_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.sc_table.setEditTriggers(QAbstractItemView.DoubleClicked | QAbstractItemView.EditKeyPressed)
        for rule in self.settings.get("sc_priority_rules", []):
            row = self.sc_table.rowCount()
            self.sc_table.insertRow(row)
            self.sc_table.setItem(row, 0, QTableWidgetItem(str(rule.get("min_amount", 0))))
            self.sc_table.setItem(row, 1, QTableWidgetItem(str(rule.get("priority", 50))))
        sc_layout.addWidget(self.sc_table)
        sc_actions = QHBoxLayout()
        add_tier = QPushButton("新增档位")
        add_tier.clicked.connect(self.add_sc_tier)
        remove_tier = QPushButton("删除选中档位")
        remove_tier.clicked.connect(self.remove_sc_tier)
        sc_actions.addWidget(add_tier); sc_actions.addWidget(remove_tier); sc_actions.addStretch()
        sc_layout.addLayout(sc_actions)
        layout.addWidget(sc_panel)

        save = QPushButton("保存规则")
        save.setObjectName("Primary")
        save.clicked.connect(lambda: self.save_rules(controls))
        layout.addWidget(save)
        layout.addStretch()
        return widget

    def add_sc_tier(self):
        row = self.sc_table.rowCount()
        self.sc_table.insertRow(row)
        self.sc_table.setItem(row, 0, QTableWidgetItem("30"))
        self.sc_table.setItem(row, 1, QTableWidgetItem("50"))

    def remove_sc_tier(self):
        row = self.sc_table.currentRow()
        if row >= 0:
            self.sc_table.removeRow(row)

    def save_rules(self, controls):
        for _, key, control in controls:
            self.settings.set(key, control.value())
        self.settings.set("role_priorities", {key: spin.value() for key, spin in self.role_controls.items()})
        sc_rules = []
        try:
            for row in range(self.sc_table.rowCount()):
                amount_item = self.sc_table.item(row, 0)
                priority_item = self.sc_table.item(row, 1)
                if amount_item is None or priority_item is None:
                    raise ValueError("SC 档位存在空白单元格")
                amount = float(amount_item.text().strip())
                priority = int(priority_item.text().strip())
                if amount < 0 or priority < 0:
                    raise ValueError("SC 金额和优先级不能为负数")
                sc_rules.append({"min_amount": amount, "priority": priority})
        except ValueError as exc:
            QMessageBox.warning(self, "规则有误", str(exc))
            return
        sc_rules.sort(key=lambda item: item["min_amount"])
        self.settings.set("sc_priority_rules", sc_rules)
        self.database.log("INFO", "settings", "点歌规则和优先级配置已保存")
        QMessageBox.information(self, "保存成功", "点歌规则、身份优先级和 SC 档位已保存到本机数据库。")

    def accounts_page(self):
        widget, layout = self.page_shell("账号与平台", "账号登录功能尚未接入。正式接入时，登录凭证应保存到 Windows 安全凭据存储，而不是 SQLite 或明文配置文件。")
        entries = [
            ("B站账号", "目标资格：B站大会员 + 当前直播间主播身份。", "验证状态：尚未接入"),
            ("网易云音乐", "必须登录本人有权使用的会员账号，且只通过平台允许的播放方式。", "登录状态：尚未接入"),
            ("QQ 音乐", "必须登录本人有权使用的会员账号，且只通过平台允许的播放方式。", "登录状态：尚未接入"),
        ]
        for name, detail, status in entries:
            box = QFrame(); box.setObjectName("Card")
            row = QHBoxLayout(box)
            left = QVBoxLayout()
            title = QLabel(name); title.setStyleSheet("font-size: 16px; font-weight: 700;")
            desc = QLabel(detail); desc.setObjectName("Muted"); desc.setWordWrap(True)
            state = QLabel(status); state.setStyleSheet("color: #FBBF24;")
            left.addWidget(title); left.addWidget(desc); left.addWidget(state)
            row.addLayout(left); row.addStretch()
            button = QPushButton("尚未接入"); button.setEnabled(False)
            row.addWidget(button)
            layout.addWidget(box)
        warning = QLabel("说明：B站大会员资格及主播身份的第三方可验证性仍需确认。此页面目前不会将账号误判为通过或不通过。")
        warning.setObjectName("Muted")
        warning.setWordWrap(True)
        layout.addWidget(warning)
        layout.addStretch()
        return widget

    def obs_page(self):
        widget, layout = self.page_shell("OBS 展示", "后续通过本机 HTTP 服务提供浏览器源，不需要云服务器。")
        box = QFrame(); box.setObjectName("Card")
        inner = QVBoxLayout(box)
        inner.addWidget(QLabel("OBS 浏览器源状态：尚未启用"))
        inner.addWidget(QLabel("计划展示：当前歌曲、歌手、点歌人、下一首、SC 提示及歌词（视平台授权能力而定）。"))
        layout.addWidget(box)
        layout.addStretch()
        return widget

    def logs_page(self):
        widget, layout = self.page_shell("运行日志", "展示本地操作记录，便于排查点歌队列和配置问题。")
        self.log_view = QTextEdit()
        self.log_view.setReadOnly(True)
        layout.addWidget(self.log_view)
        button = QPushButton("刷新日志")
        button.clicked.connect(self.refresh_logs)
        layout.addWidget(button)
        self.refresh_logs()
        return widget

    def refresh_logs(self):
        if not hasattr(self, "log_view"):
            return
        rows = self.database.recent_logs(200)
        lines = [f"{row['created_at']}  [{row['level']}] [{row['category']}] {row['message']}" for row in rows]
        self.log_view.setPlainText("\n".join(lines) if lines else "暂无日志。")

    def change_theme_mode(self, _index: int):
        self.theme_mode = self.theme_picker.currentData()
        self.settings.set("theme_mode", self.theme_mode)
        self.apply_theme()

    def system_page(self):
        widget, layout = self.page_shell("系统设置", "界面采用 Material Design 3 风格；支持深色、浅色、跟随系统和自定义强调色。")
        theme_box = QFrame(); theme_box.setObjectName("Card")
        theme_layout = QFormLayout(theme_box)
        self.theme_picker = QComboBox()
        self.theme_picker.addItem("深色模式", "dark")
        self.theme_picker.addItem("浅色模式", "light")
        self.theme_picker.addItem("跟随系统", "system")
        idx = self.theme_picker.findData(self.theme_mode)
        self.theme_picker.setCurrentIndex(max(0, idx))
        self.theme_picker.currentIndexChanged.connect(self.change_theme_mode)
        accent_button = QPushButton("自定义主题色…")
        accent_button.clicked.connect(self.choose_accent)
        theme_layout.addRow("外观模式", self.theme_picker)
        theme_layout.addRow("强调色", accent_button)
        layout.addWidget(theme_box)
        box = QFrame(); box.setObjectName("Card")
        inner = QVBoxLayout(box)
        for line in (
            "运行模式：Windows 本地桌面版",
            "数据库：SQLite（本机用户数据目录）",
            "云服务器：不需要",
            "软件授权：不需要",
            "账号凭证：当前版本尚未保存任何平台账号凭证",
            "数据备份：正式版会加入一键备份与恢复",
        ):
            inner.addWidget(QLabel(line))
        layout.addWidget(box)
        layout.addStretch()
        return widget
