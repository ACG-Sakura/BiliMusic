from __future__ import annotations

from app.core.models import Song
from app.core.priority import resolve_priority
from app.storage.database import Database


class QueueService:
    """Queue rules shared by the UI and future Bilibili/SC event handlers."""

    def __init__(self, database: Database, settings_store=None):
        self.database = database
        self.settings_store = settings_store

    def enqueue(
        self,
        title: str,
        artist: str = "",
        requester_name: str = "主播手动添加",
        requester_uid: str = "",
        source: str = "manual",
        kind: str = "normal",
        priority: int | None = None,
        sc_amount: float = 0,
        sc_rules: list[dict] | None = None,
        role_priorities: dict[str, int] | None = None,
    ) -> int:
        clean_title = title.strip()
        if not clean_title:
            raise ValueError("歌曲名称不能为空")
        if self.settings_store is not None:
            if sc_rules is None:
                sc_rules = self.settings_store.get("sc_priority_rules", [])
            if role_priorities is None:
                role_priorities = self.settings_store.get("role_priorities", {})
        resolved_priority = priority if priority is not None else resolve_priority(
            kind, sc_amount=sc_amount, sc_rules=sc_rules, role_priorities=role_priorities
        )
        with self.database.session() as conn:
            manual_mode = conn.execute(
                "SELECT EXISTS(SELECT 1 FROM songs WHERE status='queued' AND manual_order=1)"
            ).fetchone()[0]
            if manual_mode:
                next_position = conn.execute(
                    "SELECT COALESCE(MAX(position), -1) + 1 FROM songs WHERE status='queued'"
                ).fetchone()[0]
            else:
                next_position = conn.execute(
                    "SELECT COALESCE(MAX(position), -1) + 1 FROM songs "
                    "WHERE status='queued' AND priority=?",
                    (int(resolved_priority),),
                ).fetchone()[0]
            cur = conn.execute(
                """INSERT INTO songs(title, artist, requester_name, requester_uid,
                   source, priority, position, manual_order, kind, status, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'queued', strftime('%Y-%m-%dT%H:%M:%fZ','now'))""",
                (clean_title, artist.strip(), requester_name.strip(), requester_uid,
                 source, int(resolved_priority), int(next_position), int(bool(manual_mode)), kind),
            )
            song_id = int(cur.lastrowid)
        self.database.log("INFO", "queue", f"已加入歌曲：{clean_title}（{kind}，优先级 {resolved_priority}）")
        return song_id

    def list_queue(self) -> list[Song]:
        manual_mode = self.database.fetchone(
            "SELECT EXISTS(SELECT 1 FROM songs WHERE status='queued' AND manual_order=1) AS enabled"
        )["enabled"]
        ordering = "position ASC, created_at ASC, id ASC" if manual_mode else "priority DESC, position ASC, created_at ASC, id ASC"
        rows = self.database.fetchall(f"SELECT * FROM songs WHERE status='queued' ORDER BY {ordering}")
        return [self._to_song(row) for row in rows]

    def get_song(self, song_id: int) -> Song | None:
        row = self.database.fetchone("SELECT * FROM songs WHERE id=?", (song_id,))
        return self._to_song(row) if row else None

    def remove(self, song_id: int) -> bool:
        row = self.database.fetchone("SELECT title FROM songs WHERE id=? AND status='queued'", (song_id,))
        if row is None:
            return False
        self.database.execute(
            "UPDATE songs SET status='cancelled', updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?",
            (song_id,),
        )
        self.database.log("INFO", "queue", f"已移除歌曲：{row['title']}")
        return True

    def mark_playing(self, song_id: int) -> bool:
        row = self.database.fetchone("SELECT id FROM songs WHERE id=? AND status='queued'", (song_id,))
        if row is None:
            return False
        now = "strftime('%Y-%m-%dT%H:%M:%fZ','now')"
        with self.database.session() as conn:
            conn.execute(f"UPDATE songs SET status='played', updated_at={now} WHERE status='playing'")
            conn.execute(f"UPDATE songs SET status='playing', updated_at={now} WHERE id=?", (song_id,))
        self.database.log("INFO", "player", f"开始播放队列歌曲 ID={song_id}")
        return True

    def finish_current(self, skipped: bool = False) -> int | None:
        current = self.database.fetchone("SELECT id FROM songs WHERE status='playing' ORDER BY id DESC LIMIT 1")
        if current is not None:
            new_status = "skipped" if skipped else "played"
            self.database.execute(
                "UPDATE songs SET status=?, updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?",
                (new_status, current["id"]),
            )
        queue = self.list_queue()
        if queue:
            self.mark_playing(queue[0].id)
            return queue[0].id
        return None

    def move(self, song_id: int, direction: int) -> bool:
        """Move a queued song. In manual-order mode, priority bands may be crossed."""
        if direction not in (-1, 1):
            raise ValueError("direction 只能是 -1 或 +1")
        items = self.list_queue()
        index = next((i for i, item in enumerate(items) if item.id == song_id), -1)
        target = index + direction
        if index < 0 or target < 0 or target >= len(items):
            return False
        current, neighbour = items[index], items[target]
        manual_mode = bool(self.database.fetchone(
            "SELECT EXISTS(SELECT 1 FROM songs WHERE status='queued' AND manual_order=1) AS enabled"
        )["enabled"])
        if current.priority != neighbour.priority and not manual_mode:
            # The first cross-priority adjustment switches the whole queue to
            # explicit host ordering; this is an intentional override of auto priority.
            manual_mode = True
        ordered = list(items)
        ordered[index], ordered[target] = ordered[target], ordered[index]
        self.reorder([song.id for song in ordered])
        return True

    def reorder(self, song_ids: list[int]) -> bool:
        """Persist the host's exact order for every currently queued song."""
        current_ids = [song.id for song in self.list_queue()]
        if len(song_ids) != len(current_ids) or set(song_ids) != set(current_ids):
            raise ValueError("排序列表必须包含全部待播歌曲，且不能重复")
        with self.database.session() as conn:
            for position, song_id in enumerate(song_ids):
                conn.execute(
                    "UPDATE songs SET position=?, manual_order=1, updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=? AND status='queued'",
                    (position, song_id),
                )
        self.database.log("INFO", "queue", "主播已手动调整整个待播队列顺序（优先级自动排序暂时让位）")
        return True

    @staticmethod
    def _to_song(row) -> Song:
        return Song(
            id=row["id"], title=row["title"], artist=row["artist"],
            requester_name=row["requester_name"], requester_uid=row["requester_uid"],
            source=row["source"], priority=row["priority"], kind=row["kind"],
            status=row["status"], created_at=row["created_at"],
        )
