from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

SongStatus = Literal["queued", "playing", "played", "skipped", "cancelled"]
SongKind = Literal["normal", "captain", "admiral", "governor", "sc"]


@dataclass(frozen=True, slots=True)
class Song:
    id: int
    title: str
    artist: str
    requester_name: str
    requester_uid: str
    source: str
    priority: int
    kind: str
    status: str
    created_at: str


@dataclass(frozen=True, slots=True)
class QueueSettings:
    daily_limit: int = 2
    user_cooldown_seconds: int = 300
    global_cooldown_seconds: int = 10
    duplicate_cooldown_minutes: int = 60
    queue_limit_per_user: int = 2
    min_fan_badge_level: int = 1


DEFAULT_SETTINGS: dict[str, object] = {
    "daily_limit": 2,
    "user_cooldown_seconds": 300,
    "global_cooldown_seconds": 10,
    "duplicate_cooldown_minutes": 60,
    "queue_limit_per_user": 2,
    "min_fan_badge_level": 1,
    "sc_priority_rules": [
        {"min_amount": 30, "priority": 50},
        {"min_amount": 50, "priority": 60},
        {"min_amount": 100, "priority": 70},
        {"min_amount": 200, "priority": 80},
    ],
    "role_priorities": {"normal": 10, "captain": 20, "admiral": 30, "governor": 40, "sc": 50},
    "membership_required": True,
    "host_account_required": True,
}

# Default priorities are intentionally configurable in the future UI.
DEFAULT_ROLE_PRIORITIES: dict[str, int] = {
    "normal": 10,
    "captain": 20,
    "admiral": 30,
    "governor": 40,
    "sc": 50,
}
