# BiliMusic V0.1.2.1 — Windows 本地桌面开发版

BiliMusic 是面向 B站主播的本地点歌桌面软件。当前版本完成了第一阶段的模块化重构：桌面 UI、SQLite 持久化、队列优先级、基础配置和本地操作日志。

> 当前是可运行的开发版骨架，不是完整点歌成品。它**尚未连接真实 B站直播间，也尚未登录或播放网易云/QQ 音乐**。账号、直播和播放器页面会明确显示“尚未接入”，不会伪装成已经可用。

## 当前已实现

### V0.1.2 更新

- 加入 MD3 风格主题基础：深色/浅色/跟随系统、自定义强调色。
- 主播手动添加歌曲到待播队列。
- 队列顺序调整不再限制在相同优先级，可跨优先级重排；手动重排后新歌排在队尾。


- PySide6 Windows 桌面界面，采用 Material Design 3 设计语言；支持深色、浅色、跟随系统和自定义强调色。
- 本地 SQLite 数据库，自动创建并迁移早期 V0.1 数据库字段。
- 点歌队列：主播手动添加歌曲、删除待播歌曲、查看队列。
- 主播可上移/下移任意待播歌曲，允许跨越舰长/提督/总督/SC 优先级；手动调整后，当前队列按主播指定顺序播放，新加入歌曲追加到队尾。
- 自动队列优先级：普通、舰长、提督、总督、SC；优先级数值越高越靠前。主播首次手动改序后，以手动顺序覆盖自动优先级排序。
- 默认优先级和 SC 金额档位配置数据。
- 点歌规则持久化：每日次数、个人 CD、全局 CD、重复 CD、每人待播上限、最低粉丝牌等级。
- 本地操作日志。
- B站消息和音乐播放器的接口契约，为后续真实连接器划定边界。
- Windows 启动脚本和 PyInstaller 开发打包脚本。
- 核心业务逻辑自动化测试。

## 尚未实现

- B站扫码登录、大会员验证和主播身份验证。
- B站直播弹幕、粉丝牌、大航海和 SC 的真实消息接入。
- 网易云、QQ 音乐会员账号登录与合规播放。
- 自动播放、暂停、恢复、切歌及用户切掉自己歌曲的真实播放器控制。
- OBS 本地浏览器源和 Windows 正式安装包。

这些功能不能通过简单填一个 URL 就保证可用：需要逐一验证平台当前开放的授权/接口条件。尤其是大会员资格能否被第三方客户端稳定验证、QQ 音乐/网易云是否向第三方软件开放会员曲目的合法播放能力，目前不作虚假承诺。

## Windows 运行

环境：Windows 10/11、Python 3.11 或更新版本。

1. 解压项目。
2. 双击 `run_windows.bat`。
3. 首次启动会创建 `.venv` 并安装依赖。
4. 程序数据保存在当前 Windows 用户的数据目录 `BiliMusic` 文件夹中，不写入程序安装目录。

也可以在 PowerShell 中手动运行：

```powershell
py -3 -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python main.py
```

## 运行测试

```powershell
py -3 -m pip install -r requirements-dev.txt
py -3 -m pytest -q
```

## 构建开发版 EXE

```powershell
build_windows.bat
```

输出位置：`dist\BiliMusic\BiliMusic.exe`。这是未签名的开发构建，不是正式安装程序。

## 数据与账号安全

- 数据库中保存歌曲、规则和操作日志。
- 本版本不保存 B站、网易云或 QQ 音乐的登录凭证。
- 后续如需保存平台登录会话，优先使用 Windows Credential Manager / 系统安全凭据存储；不得将 Cookie、Token 或密码写入 SQLite、普通 JSON 或日志。
- 本软件不破解会员、不绕过付费限制、不提取受保护音频。音乐播放仅接入平台明确允许的登录和播放方式。

## 项目结构

```text
BiliMusic/
├── main.py
├── app/
│   ├── core/              # 队列、设置、领域模型
│   ├── storage/           # SQLite 数据访问
│   ├── integrations/
│   │   ├── bilibili/      # B站连接器接口契约
│   │   └── music/         # 音乐平台播放器接口契约
│   └── ui/                # PySide6 界面
├── tests/
├── requirements.txt
├── requirements-dev.txt
├── run_windows.bat
└── build_windows.bat
```

## 参考项目

本项目借鉴公开项目的产品设计思路，不复制其实现代码：

- [AwooMusicBot](https://github.com/Enkianssus/AwooMusicBot)：点歌队列、权限与礼物规则设计。
- [BiliHUD](https://github.com/locez/bilihud)：Qt 桌面 UI、弹幕和 OBS 展示思路。
- [blivedm](https://github.com/xfgryujk/blivedm)：B站直播消息接入研究。
- [NekoFM](https://github.com/7starsseeker/nekofm)：播放器、队列和歌词功能设计参考。

在复用任何第三方代码前，需单独核对其许可证、依赖许可证和平台条款；本版本不包含上述项目的源代码。

## 下一阶段

V0.2 将先解决 B站接入可行性：对比官方直播开放平台与其他被允许的接入方式，明确消息范围、账号要求、签名/密钥要求及本机部署可行性，再实现连接和消息解析。当前官方文档调研记录见 [`docs/BILIBILI_INTEGRATION_RESEARCH.md`](docs/BILIBILI_INTEGRATION_RESEARCH.md)。未验证的平台能力不会提前宣称已经支持。
