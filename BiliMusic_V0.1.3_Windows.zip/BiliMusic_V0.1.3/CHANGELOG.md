# Changelog

## V0.1.3
- Reworked the desktop UI around a consistent Material 3-inspired blue/white design system.
- Light mode is now the default; dark mode and system-following mode remain available.
- Redesigned dashboard, queue management, rules, accounts, OBS, logs, and settings pages.
- Added queue summary, clearer source labels, improved table sizing, and more obvious host controls.
- Added log text search and level filtering.
- Preserved the existing SQLite schema and queue/rule business logic.

## V0.1.2.1
- Improved SQLite connection lifecycle handling for Windows test runs.
