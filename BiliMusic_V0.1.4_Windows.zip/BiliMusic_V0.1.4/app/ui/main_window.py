from __future__ import annotations

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor, QGuiApplication, QIntValidator
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QLabel, QPushButton,
    QListWidget, QStackedWidget, QFrame, QTableWidget, QTableWidgetItem,
    QHeaderView, QLineEdit, QMessageBox, QSpinBox, QFormLayout, QGridLayout,
    QAbstractItemView, QTextEdit, QComboBox, QColorDialog, QScrollArea,
    QSizePolicy, QSpacerItem,
)

from app.core.queue_service import QueueService
from app.core.settings import SettingsStore
from app.storage.database import Database


BLUE_LIGHT = {
    "bg": "#F5F8FD", "surface": "#FFFFFF", "surface2": "#EEF4FC",
    "surface3": "#E5EFFB", "text": "#172B4D", "muted": "#60738E",
    "outline": "#D5E0EF", "selected": "#DCEAFF", "field": "#F2F6FC",
    "accent": "#3568D4", "accent_hover": "#2858BD", "onaccent": "#FFFFFF",
    "tablealt": "#F7FAFE", "success": "#18794E", "warning": "#9A6700",
}
BLUE_DARK = {
    "bg": "#101923", "surface": "#172332", "surface2": "#1D2B3D",
    "surface3": "#26384D", "text": "#E4EDF8", "muted": "#A9B9CC",
    "outline": "#3A4D63", "selected": "#29466B", "field": "#1D2B3D",
    "accent": "#8AB4F8", "accent_hover": "#A6C7FF", "onaccent": "#10243E",
    "tablealt": "#1A2939", "success": "#8BD5B0", "warning": "#F3C969",
}


def build_md3_style(mode: str = "light", accent: str | None = None) -> str:
    """Token-based Material 3-inspired blue/white theme for the Qt widget layer."""
    c = dict(BLUE_DARK if mode == "dark" else BLUE_LIGHT)
    if accent:
        c["accent"] = accent
    return f"""
    QWidget {{
        background: {c['bg']}; color: {c['text']};
        font-family: "Microsoft YaHei UI", "Microsoft YaHei", sans-serif;
        font-size: 13px;
    }}
    QLabel {{ background: transparent; border: none; }}
    QFrame#Sidebar {{ background: {c['surface']}; border: none; border-right: 1px solid {c['outline']}; }}
    QLabel#Brand {{ font-size: 24px; font-weight: 800; color: {c['accent']}; padding: 12px 8px 22px 8px; }}
    QLabel#PageTitle {{ font-size: 26px; font-weight: 750; color: {c['text']}; }}
    QLabel#PageSubtitle {{ color: {c['muted']}; font-size: 13px; }}
    QLabel#Muted {{ color: {c['muted']}; }}
    QLabel#Value {{ font-size: 25px; font-weight: 750; color: {c['text']}; }}
    QLabel#SectionTitle {{ font-size: 16px; font-weight: 700; }}
    QLabel#Eyebrow {{ color: {c['muted']}; font-size: 11px; font-weight: 650; }}
    QFrame#Card {{ background: {c['surface']}; border: 1px solid {c['outline']}; border-radius: 18px; }}
    QFrame#TintCard {{ background: {c['surface2']}; border: 1px solid transparent; border-radius: 18px; }}
    QFrame#MiniCard {{ background: {c['surface2']}; border: none; border-radius: 14px; }}
    QPushButton {{
        background: {c['surface3']}; color: {c['text']}; border: 1px solid transparent;
        border-radius: 12px; padding: 9px 16px; min-height: 22px; font-weight: 600;
    }}
    QPushButton:hover {{ background: {c['selected']}; }}
    QPushButton:pressed {{ padding-top: 10px; padding-bottom: 8px; }}
    QPushButton:disabled {{ color: {c['muted']}; background: {c['surface2']}; }}
    QPushButton#Primary {{ background: {c['accent']}; color: {c['onaccent']}; border: none; }}
    QPushButton#Primary:hover {{ background: {c['accent_hover']}; }}
    QPushButton#Tonal {{ background: {c['selected']}; color: {c['text']}; border: none; }}
    QPushButton#TextButton {{ background: transparent; border: none; color: {c['accent']}; }}
    QListWidget {{ background: transparent; border: none; outline: none; padding: 5px 0; }}
    QListWidget::item {{ padding: 12px 14px; border-radius: 13px; margin: 3px 0; color: {c['muted']}; }}
    QListWidget::item:hover {{ background: {c['surface2']}; color: {c['text']}; }}
    QListWidget::item:selected {{ background: {c['selected']}; color: {c['text']}; font-weight: 700; }}
    QTableWidget {{
        background: {c['surface']}; alternate-background-color: {c['tablealt']};
        gridline-color: transparent; border: 1px solid {c['outline']}; border-radius: 14px;
        selection-background-color: {c['selected']}; selection-color: {c['text']};
        outline: none; padding: 4px;
    }}
    QTableWidget::item {{ padding: 9px 8px; border-bottom: 1px solid {c['outline']}; }}
    QHeaderView::section {{ background: {c['surface2']}; color: {c['muted']}; padding: 12px 8px; border: none; font-weight: 700; }}
    QLineEdit, QSpinBox, QComboBox {{
        background: {c['field']}; color: {c['text']}; border: 1px solid {c['outline']};
        border-radius: 12px; padding: 10px 12px; min-height: 22px; selection-background-color: {c['accent']};
    }}
    QLineEdit:focus, QSpinBox:focus, QComboBox:focus {{ border: 2px solid {c['accent']}; padding: 9px 11px; }}
    QComboBox {{ padding-right: 30px; }}
    QComboBox::drop-down {{ subcontrol-origin: padding; subcontrol-position: center right; width: 28px; border: none; }}
    QComboBox::down-arrow {{ width: 8px; height: 8px; border: none; border-right: 2px solid {c['muted']}; border-bottom: 2px solid {c['muted']}; margin-right: 10px; }}
    QComboBox QAbstractItemView {{ background: {c['surface']}; selection-background-color: {c['selected']}; border: 1px solid {c['outline']}; border-radius: 10px; padding: 4px; }}
    QTextEdit {{ background: {c['surface']}; border: 1px solid {c['outline']}; border-radius: 14px; padding: 12px; }}
    QScrollArea {{ background: transparent; border: none; }}
    QScrollBar:vertical {{ background: transparent; width: 10px; margin: 3px; }}
    QScrollBar::handle:vertical {{ background: {c['outline']}; border-radius: 5px; min-height: 30px; }}
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
    """


class ReorderableQueueTable(QTableWidget):
    """A queue table that persists row drag-and-drop as the host's exact order."""
    def __init__(self, rows: int, columns: int, on_reordered, parent=None):
        super().__init__(rows, columns, parent)
        self.on_reordered = on_reordered
        self.setDragEnabled(True)
        self.setAcceptDrops(True)
        self.setDropIndicatorShown(True)
        self.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.setDragDropOverwriteMode(False)

    def dropEvent(self, event):
        super().dropEvent(event)
        if event.isAccepted():
            QTimer.singleShot(0, self.on_reordered)


class MainWindow(QMainWindow):
    def __init__(self, database: Database, settings: SettingsStore, queue: QueueService):
        super().__init__()
        self.database = database
        self.settings = settings
        self.queue = queue
        self.setWindowTitle("BiliMusic — B站主播本地点歌姬")
        self.resize(1280, 820)
        self.setMinimumSize(1050, 700)
        self.apply_theme()
        self._build_layout()
        self.refresh_queue()
        self.refresh_dashboard()

    def apply_theme(self):
        # V0.1.4 keeps the product's blue-white light appearance fixed.
        self.setStyleSheet(build_md3_style("light", "#3568D4"))

    def _build_layout(self) -> None:
        base = QWidget()
        outer = QHBoxLayout(base)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(224)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(16, 18, 16, 18)
        side.setSpacing(8)
        brand = QLabel("BiliMusic")
        brand.setObjectName("Brand")
        side.addWidget(brand)
        brand_sub = QLabel("LIVE MUSIC DESK")
        brand_sub.setObjectName("Eyebrow")
        brand_sub.setContentsMargins(8, 0, 0, 14)
        side.addWidget(brand_sub)
        self.nav = QListWidget()
        self.nav.addItems(["⌂  控制台", "♫  点歌队列", "☷  点歌规则", "◎  账号与平台", "▣  OBS 展示", "≡  运行日志", "⚙  系统设置"])
        self.nav.setCurrentRow(0)
        self.nav.currentRowChanged.connect(self._switch_page)
        side.addWidget(self.nav, 1)
        footer_line = QFrame()
        footer_line.setFixedHeight(1)
        footer_line.setStyleSheet("background: palette(mid); border: none;")
        side.addWidget(footer_line)
        foot = QLabel("本地开发版 · V0.1.4")
        foot.setObjectName("Muted")
        foot.setContentsMargins(8, 8, 0, 0)
        side.addWidget(foot)
        outer.addWidget(sidebar)

        self.pages = QStackedWidget()
        self.pages.addWidget(self.dashboard_page())
        self.pages.addWidget(self.queue_page())
        self.pages.addWidget(self.rules_page())
        self.pages.addWidget(self.accounts_page())
        self.pages.addWidget(self.obs_page())
        self.pages.addWidget(self.logs_page())
        self.pages.addWidget(self.system_page())
        outer.addWidget(self.pages, 1)
        self.setCentralWidget(base)

    def _switch_page(self, index: int) -> None:
        self.pages.setCurrentIndex(index)
        if index == 0:
            self.refresh_dashboard()
        elif index == 1:
            self.refresh_queue()
        elif index == 5:
            self.refresh_logs()

    @staticmethod
    def page_shell(title: str, subtitle: str = ""):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(16)
        heading = QLabel(title)
        heading.setObjectName("PageTitle")
        layout.addWidget(heading)
        if subtitle:
            desc = QLabel(subtitle)
            desc.setObjectName("PageSubtitle")
            desc.setWordWrap(True)
            layout.addWidget(desc)
        return widget, layout

    @staticmethod
    def scroll_page(title: str, subtitle: str = ""):
        page, page_layout = MainWindow.page_shell(title, subtitle)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 2, 8, 8)
        content_layout.setSpacing(16)
        scroll.setWidget(content)
        page_layout.addWidget(scroll, 1)
        return page, content_layout

    @staticmethod
    def card(title: str, value: str, hint: str, tinted: bool = False):
        box = QFrame()
        box.setObjectName("TintCard" if tinted else "Card")
        layout = QVBoxLayout(box)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(7)
        label = QLabel(title)
        label.setObjectName("Muted")
        value_label = QLabel(value)
        value_label.setObjectName("Value")
        hint_label = QLabel(hint)
        hint_label.setObjectName("Muted")
        hint_label.setWordWrap(True)
        layout.addWidget(label)
        layout.addWidget(value_label)
        layout.addWidget(hint_label)
        return box

    @staticmethod
    def section_card(title: str, subtitle: str = ""):
        box = QFrame()
        box.setObjectName("Card")
        layout = QVBoxLayout(box)
        layout.setContentsMargins(18, 16, 18, 18)
        layout.setSpacing(12)
        heading = QLabel(title)
        heading.setObjectName("SectionTitle")
        layout.addWidget(heading)
        if subtitle:
            desc = QLabel(subtitle)
            desc.setObjectName("Muted")
            desc.setWordWrap(True)
            layout.addWidget(desc)
        return box, layout

    def dashboard_page(self):
        widget, layout = self.page_shell("控制台", "BiliMusic 本地运行概览。直播连接和音乐播放模块仍处于后续接入阶段。")
        cards = QGridLayout()
        cards.setSpacing(14)
        cards.addWidget(self.card("B站连接", "未连接", "直播连接器尚未接入", True), 0, 0)
        cards.addWidget(self.card("当前播放", "暂无", "播放器模块尚未接入"), 0, 1)
        queue_card = self.card("待播歌曲", str(len(self.queue.list_queue())), "本地 SQLite 队列", True)
        self.dashboard_queue_value = queue_card.findChild(QLabel, "Value")
        cards.addWidget(queue_card, 0, 2)
        layout.addLayout(cards)

        panel, panel_layout = self.section_card("开发进度", "已完成的本地基础能力与尚待接入的外部平台能力。")
        status_rows = [
            (True, "桌面界面与模块化项目结构"),
            (True, "SQLite 数据库与配置持久化"),
            (True, "点歌队列、优先级排序和主播手动调整顺序"),
            (True, "主播手动添加歌曲到待播队列"),
            (True, "本地操作日志"),
            (False, "B站账号登录、主播身份和大会员资格验证"),
            (False, "B站弹幕、粉丝牌、大航海和 SC 消息接入"),
            (False, "网易云 / QQ 音乐官方授权播放接入"),
            (False, "自动播放、OBS 浏览器源和正式安装包"),
        ]
        for done, text in status_rows:
            row = QHBoxLayout()
            mark = QLabel("✓" if done else "○")
            mark.setStyleSheet("font-size: 16px; font-weight: 800;")
            mark.setFixedWidth(24)
            mark.setObjectName("Muted" if not done else "")
            label = QLabel(text)
            label.setObjectName("Muted" if not done else "")
            row.addWidget(mark)
            row.addWidget(label, 1)
            panel_layout.addLayout(row)
        layout.addWidget(panel)
        layout.addStretch()
        return widget

    def refresh_dashboard(self):
        if hasattr(self, "dashboard_queue_value"):
            self.dashboard_queue_value.setText(str(len(self.queue.list_queue())))

    def queue_page(self):
        widget, layout = self.page_shell("点歌队列", "管理待播歌曲。主播手动调整顺序后，以主播指定顺序为准。")
        summary = QHBoxLayout()
        summary.setSpacing(12)
        self.queue_count_value = QLabel("0")
        self.queue_count_value.setObjectName("Value")
        count_card, count_layout = self.section_card("待播歌曲")
        count_layout.addWidget(self.queue_count_value)
        self.queue_mode_label = QLabel("当前排序：自动优先级")
        self.queue_mode_label.setObjectName("Muted")
        mode_card, mode_layout = self.section_card("队列排序")
        mode_layout.addWidget(self.queue_mode_label)
        summary.addWidget(count_card, 1)
        summary.addWidget(mode_card, 2)
        layout.addLayout(summary)

        add_card, add_layout = self.section_card("主播手动添加", "添加的歌曲会标记为「主播手动添加」，并进入待播队列。")
        form = QHBoxLayout()
        self.song_title = QLineEdit()
        self.song_title.setPlaceholderText("输入歌曲名称")
        self.song_artist = QLineEdit()
        self.song_artist.setPlaceholderText("歌手（可选）")
        add_button = QPushButton("＋  添加到队列")
        add_button.setObjectName("Primary")
        add_button.clicked.connect(self.add_song)
        form.addWidget(self.song_title, 3)
        form.addWidget(self.song_artist, 2)
        form.addWidget(add_button)
        add_layout.addLayout(form)
        layout.addWidget(add_card)

        table_card, table_layout = self.section_card("待播列表", "选择一首歌曲后，可删除或调整其播放顺序。")
        self.queue_table = ReorderableQueueTable(0, 7, self.persist_drag_order)
        self.queue_table.setHorizontalHeaderLabels(["ID", "序号", "歌曲", "歌手", "点歌人", "来源 / 身份", "优先级"])
        self.queue_table.setColumnHidden(0, True)
        self.queue_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.queue_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.queue_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.queue_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.queue_table.horizontalHeader().setSectionResizeMode(4, QHeaderView.Stretch)
        self.queue_table.horizontalHeader().setSectionResizeMode(5, QHeaderView.ResizeToContents)
        self.queue_table.horizontalHeader().setSectionResizeMode(6, QHeaderView.ResizeToContents)
        self.queue_table.verticalHeader().setVisible(False)
        self.queue_table.verticalHeader().setDefaultSectionSize(42)
        self.queue_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.queue_table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.queue_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.queue_table.setToolTip("按住歌曲行并拖动，可直接调整待播顺序")
        self.queue_table.setAlternatingRowColors(True)
        self.queue_table.setMinimumHeight(250)
        table_layout.addWidget(self.queue_table)
        actions = QHBoxLayout()
        refresh = QPushButton("刷新")
        refresh.clicked.connect(self.refresh_queue)
        delete = QPushButton("删除选中")
        delete.clicked.connect(self.delete_selected)
        delete_all = QPushButton("全部删除")
        delete_all.setObjectName("Tonal")
        delete_all.clicked.connect(self.delete_all_queued)
        up = QPushButton("↑  上移")
        up.setObjectName("Tonal")
        up.clicked.connect(lambda: self.move_selected(-1))
        down = QPushButton("↓  下移")
        down.setObjectName("Tonal")
        down.clicked.connect(lambda: self.move_selected(1))
        for button in (refresh, delete, delete_all, up, down):
            actions.addWidget(button)
        actions.addStretch()
        table_layout.addLayout(actions)
        layout.addWidget(table_card, 1)
        return widget

    def persist_drag_order(self):
        if not hasattr(self, "queue_table"):
            return
        ids = []
        for row in range(self.queue_table.rowCount()):
            item = self.queue_table.item(row, 0)
            if item is not None:
                ids.append(int(item.text()))
        try:
            if ids and len(ids) == len(self.queue.list_queue()):
                self.queue.reorder(ids)
                self.refresh_queue()
                self.queue_mode_label.setText("当前排序：主播手动顺序")
        except (ValueError, RuntimeError) as exc:
            QMessageBox.warning(self, "排序未保存", str(exc))
            self.refresh_queue()

    def add_song(self):
        title = self.song_title.text().strip()
        if not title:
            QMessageBox.information(self, "提示", "请先输入歌曲名称。")
            return
        try:
            self.queue.enqueue(title, self.song_artist.text().strip(), source="manual", kind="normal")
        except ValueError as exc:
            QMessageBox.warning(self, "无法添加", str(exc))
            return
        self.song_title.clear()
        self.song_artist.clear()
        self.refresh_queue()
        self.refresh_dashboard()

    def refresh_queue(self):
        if not hasattr(self, "queue_table"):
            return
        songs = self.queue.list_queue()
        self.queue_table.setRowCount(len(songs))
        kind_names = {"normal": "普通", "captain": "舰长", "admiral": "提督", "governor": "总督", "sc": "SC"}
        source_names = {"manual": "主播手动添加", "danmaku": "弹幕点歌", "sc": "SC 点歌"}
        for row_index, song in enumerate(songs):
            source = source_names.get(song.source, song.source or "弹幕点歌")
            identity = kind_names.get(song.kind, song.kind)
            values = [str(song.id), str(row_index + 1), song.title, song.artist or "—",
                      song.requester_name or "—", f"{source} · {identity}", str(song.priority)]
            for col, value in enumerate(values):
                item = QTableWidgetItem(value)
                if col == 0:
                    item.setData(Qt.ItemDataRole.UserRole, song.id)
                if col == 1:
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                self.queue_table.setItem(row_index, col, item)
        self.queue_count_value.setText(str(len(songs)))
        if hasattr(self, "queue_mode_label"):
            manual_mode = bool(self.database.fetchone("SELECT EXISTS(SELECT 1 FROM songs WHERE status='queued' AND manual_order=1) AS enabled")["enabled"])
            self.queue_mode_label.setText("当前排序：主播手动顺序" if manual_mode else "当前排序：自动优先级")

    def selected_song_id(self) -> int | None:
        row = self.queue_table.currentRow()
        if row < 0:
            return None
        item = self.queue_table.item(row, 0)
        return int(item.text()) if item else None

    def delete_selected(self):
        song_id = self.selected_song_id()
        if song_id is None:
            QMessageBox.information(self, "提示", "请先选择一首待播歌曲。")
            return
        song = self.queue.get_song(song_id)
        title = song.title if song else "所选歌曲"
        answer = QMessageBox.question(
            self, "确认删除", f"确定从待播队列中删除《{title}》吗？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        self.queue.remove(song_id)
        self.refresh_queue()
        self.refresh_dashboard()

    def delete_all_queued(self):
        count = len(self.queue.list_queue())
        if count == 0:
            QMessageBox.information(self, "提示", "当前待播队列为空。")
            return
        answer = QMessageBox.question(
            self, "确认清空队列",
            f"确定删除全部 {count} 首待播歌曲吗？\n此操作只清空待播队列，不会删除已播放历史。",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        self.queue.remove_all_queued()
        self.refresh_queue()
        self.refresh_dashboard()

    def move_selected(self, direction: int):
        song_id = self.selected_song_id()
        if song_id is None:
            QMessageBox.information(self, "提示", "请先选择一首待播歌曲。")
            return
        moved = self.queue.move(song_id, direction)
        if not moved:
            QMessageBox.information(self, "无法调整", "该歌曲已在队列边界，无法继续移动。")
        self.refresh_queue()
        for row in range(self.queue_table.rowCount()):
            if int(self.queue_table.item(row, 0).text()) == song_id:
                self.queue_table.selectRow(row)
                break

    def rules_page(self):
        widget, layout = self.scroll_page("点歌规则", "设置会保存在本机数据库。粉丝牌和 SC 的真实校验需要等 B站消息接入后才能生效。")
        basic_card, basic_layout = self.section_card("基础点歌限制", "普通灯牌用户与舰长及以上用户分别计算冷却；SC 点歌不受个人冷却限制。")
        form = QFormLayout()
        form.setHorizontalSpacing(24)
        form.setVerticalSpacing(10)
        self.daily_limit = self._number_field(0, 999)
        self.normal_badge_cd = self._number_field(0, 86400)
        self.captain_cd = self._number_field(0, 86400)
        self.duplicate_cd = self._number_field(0, 10080)
        self.queue_limit = self._number_field(0, 999)
        self.fan_level = self._number_field(0, 40)
        controls = [
            ("每日点歌次数（0 = 不限）", "daily_limit", self.daily_limit),
            ("普通灯牌用户点歌冷却（秒）", "normal_badge_cooldown_seconds", self.normal_badge_cd),
            ("舰长及以上点歌冷却（秒）", "captain_cooldown_seconds", self.captain_cd),
            ("歌曲重复冷却（分钟）", "duplicate_cooldown_minutes", self.duplicate_cd),
            ("每人同时待播上限（0 = 不限）", "queue_limit_per_user", self.queue_limit),
            ("最低粉丝牌等级（0 = 不限制）", "min_fan_badge_level", self.fan_level),
        ]
        for label, key, control in controls:
            fallback = 180 if key == "captain_cooldown_seconds" else control.property("defaultValue")
            control.setText(str(self.settings.get(key, fallback)))
            form.addRow(label, control)
        basic_layout.addLayout(form)
        layout.addWidget(basic_card)

        role_card, role_layout = self.section_card("身份优先级", "数值越大，默认排序越靠前；主播手动调整顺序后以手动顺序为准。")
        roles = self.settings.get("role_priorities", {})
        self.role_controls = {}
        role_grid = QGridLayout()
        role_grid.setHorizontalSpacing(14)
        role_grid.setVerticalSpacing(10)
        for index, (key, label, default) in enumerate((
            ("normal", "普通观众", 10), ("captain", "舰长", 20),
            ("admiral", "提督", 30), ("governor", "总督", 40), ("sc", "SC 基础优先级", 50),
        )):
            field = self._number_field(0, 9999)
            field.setText(str(roles.get(key, default)))
            self.role_controls[key] = field
            cell = QVBoxLayout()
            label_widget = QLabel(label); label_widget.setObjectName("Muted")
            cell.addWidget(label_widget); cell.addWidget(field)
            role_grid.addLayout(cell, index // 3, index % 3)
        role_layout.addLayout(role_grid)
        layout.addWidget(role_card)

        sc_card, sc_layout = self.section_card("SC 金额优先级", "为不同 SC 金额设置优先级档位。SC 点歌不使用普通/舰长个人冷却。")
        self.sc_table = QTableWidget(0, 2)
        self.sc_table.setHorizontalHeaderLabels(["SC 起始金额（元）", "优先级"])
        self.sc_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.sc_table.verticalHeader().setVisible(False)
        self.sc_table.verticalHeader().setDefaultSectionSize(38)
        self.sc_table.setMaximumHeight(210)
        self.sc_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.sc_table.setEditTriggers(QAbstractItemView.DoubleClicked | QAbstractItemView.EditKeyPressed)
        for rule in self.settings.get("sc_priority_rules", []):
            row = self.sc_table.rowCount()
            self.sc_table.insertRow(row)
            self.sc_table.setItem(row, 0, QTableWidgetItem(str(rule.get("min_amount", 0))))
            self.sc_table.setItem(row, 1, QTableWidgetItem(str(rule.get("priority", 50))))
        sc_layout.addWidget(self.sc_table)
        sc_actions = QHBoxLayout()
        add_tier = QPushButton("＋ 新增金额档位")
        add_tier.clicked.connect(self.add_sc_tier)
        remove_tier = QPushButton("删除选中档位")
        remove_tier.clicked.connect(self.remove_sc_tier)
        sc_actions.addWidget(add_tier); sc_actions.addWidget(remove_tier); sc_actions.addStretch()
        sc_layout.addLayout(sc_actions)
        layout.addWidget(sc_card)

        save_row = QHBoxLayout()
        save_row.addStretch()
        save = QPushButton("保存所有规则")
        save.setObjectName("Primary")
        save.clicked.connect(lambda: self.save_rules(controls))
        save.setMinimumWidth(180)
        save_row.addWidget(save)
        layout.addLayout(save_row)
        layout.addStretch()
        return widget

    @staticmethod
    def _number_field(minimum: int, maximum: int) -> QLineEdit:
        field = QLineEdit()
        field.setValidator(QIntValidator(minimum, maximum, field))
        field.setProperty("defaultValue", minimum)
        field.setMaximumHeight(48)
        return field

    def add_sc_tier(self):
        row = self.sc_table.rowCount()
        self.sc_table.insertRow(row)
        self.sc_table.setItem(row, 0, QTableWidgetItem("30"))
        self.sc_table.setItem(row, 1, QTableWidgetItem("50"))

    def remove_sc_tier(self):
        row = self.sc_table.currentRow()
        if row >= 0:
            self.sc_table.removeRow(row)

    def save_rules(self, controls):
        parsed = {}
        try:
            for _, key, control in controls:
                text = control.text().strip()
                if not text:
                    raise ValueError("规则数值不能为空")
                parsed[key] = int(text)
            role_values = {}
            for key, field in self.role_controls.items():
                text = field.text().strip()
                if not text:
                    raise ValueError("身份优先级不能为空")
                role_values[key] = int(text)
            sc_rules = []
            for row in range(self.sc_table.rowCount()):
                amount_item = self.sc_table.item(row, 0)
                priority_item = self.sc_table.item(row, 1)
                if amount_item is None or priority_item is None:
                    raise ValueError("SC 档位存在空白单元格")
                amount = float(amount_item.text().strip())
                priority = int(priority_item.text().strip())
                if amount < 0 or priority < 0:
                    raise ValueError("SC 金额和优先级不能为负数")
                sc_rules.append({"min_amount": amount, "priority": priority})
        except ValueError as exc:
            QMessageBox.warning(self, "规则有误", str(exc))
            return
        for key, value in parsed.items():
            self.settings.set(key, value)
        # Legacy global cooldown is intentionally no longer read by this version.
        self.settings.set("role_priorities", role_values)
        sc_rules.sort(key=lambda item: item["min_amount"])
        self.settings.set("sc_priority_rules", sc_rules)
        self.database.log("INFO", "settings", "点歌规则和优先级配置已保存")
        QMessageBox.information(self, "保存成功", "点歌规则、身份优先级和 SC 档位已保存到本机数据库。")

    def accounts_page(self):
        widget, layout = self.scroll_page("账号与平台", "平台接入尚未启用。正式接入时，登录凭证将保存到 Windows 安全凭据存储。")
        entries = [
            ("B站账号", "目标资格：B站大会员 + 当前直播间主播身份。", "验证尚未接入", "B站"),
            ("网易云音乐", "使用本人有权使用的会员账号，并通过平台允许的播放方式接入。", "登录尚未接入", "网易云"),
            ("QQ 音乐", "使用本人有权使用的会员账号，并通过平台允许的播放方式接入。", "登录尚未接入", "QQ 音乐"),
        ]
        for name, detail, status, badge in entries:
            box, row = self.section_card(name, detail)
            line = QHBoxLayout()
            state = QLabel("●  " + status)
            state.setObjectName("Muted")
            button = QPushButton("尚未接入")
            button.setEnabled(False)
            line.addWidget(state)
            line.addStretch()
            line.addWidget(button)
            row.addLayout(line)
            layout.addWidget(box)
        warning = QLabel("说明：B站大会员资格及主播身份的第三方可验证性仍需确认。本页面不会将账号误判为通过或不通过。")
        warning.setObjectName("Muted")
        warning.setWordWrap(True)
        layout.addWidget(warning)
        layout.addStretch()
        return widget

    def obs_page(self):
        widget, layout = self.scroll_page("OBS 展示", "通过本机 HTTP 服务提供浏览器源，不需要云服务器。当前版本尚未启动 OBS 服务。")
        status_card, status_layout = self.section_card("浏览器源状态")
        status = QLabel("○  尚未启用")
        status.setObjectName("Muted")
        status_layout.addWidget(status)
        layout.addWidget(status_card)
        preview, preview_layout = self.section_card("计划展示内容", "接入完成后，可在 OBS 中添加浏览器源展示以下信息。")
        for line in ("当前歌曲与歌手", "点歌人和点歌来源", "下一首待播歌曲", "SC 提示与歌词（视平台授权能力而定）"):
            label = QLabel("•  " + line)
            label.setObjectName("Muted")
            preview_layout.addWidget(label)
        layout.addWidget(preview)
        layout.addStretch()
        return widget

    def logs_page(self):
        widget, layout = self.page_shell("运行日志", "查看本地操作记录，便于排查点歌队列和配置问题。")
        toolbar = QHBoxLayout()
        self.log_search = QLineEdit()
        self.log_search.setPlaceholderText("搜索日志内容…")
        self.log_search.textChanged.connect(self.refresh_logs)
        self.log_level = QComboBox()
        self.log_level.setObjectName("LogLevelFilter")
        self.log_level.setMinimumWidth(150)
        self.log_level.setMinimumHeight(44)
        self.log_level.addItem("全部等级", "all")
        self.log_level.addItem("INFO", "INFO")
        self.log_level.addItem("WARNING", "WARNING")
        self.log_level.addItem("ERROR", "ERROR")
        self.log_level.currentIndexChanged.connect(self.refresh_logs)
        toolbar.addWidget(self.log_search, 1)
        toolbar.addWidget(self.log_level)
        layout.addLayout(toolbar)
        self.log_view = QTextEdit()
        self.log_view.setReadOnly(True)
        layout.addWidget(self.log_view, 1)
        button = QPushButton("刷新日志")
        button.clicked.connect(self.refresh_logs)
        layout.addWidget(button)
        self.refresh_logs()
        return widget

    def refresh_logs(self):
        if not hasattr(self, "log_view"):
            return
        rows = self.database.recent_logs(500)
        query = self.log_search.text().strip().lower() if hasattr(self, "log_search") else ""
        level = self.log_level.currentData() if hasattr(self, "log_level") else "all"
        lines = []
        for row in rows:
            if level != "all" and row["level"] != level:
                continue
            line = f"{row['created_at']}  [{row['level']}] [{row['category']}] {row['message']}"
            if query and query not in line.lower():
                continue
            lines.append(line)
        self.log_view.setPlainText("\n".join(lines) if lines else "没有符合条件的日志。")

    def system_page(self):
        widget, layout = self.scroll_page("系统设置", "BiliMusic 固定采用蓝白色 Material Design 3 浅色界面。")
        info_box, info_layout = self.section_card("运行环境", "当前版本的本地运行方式与数据存储说明。")
        for line in (
            "界面主题：蓝白色浅色模式（固定）",
            "运行模式：Windows 本地桌面版",
            "数据库：SQLite（本机用户数据目录）",
            "云服务器：不需要",
            "软件授权：不需要",
            "账号凭证：当前版本尚未保存任何平台账号凭证",
            "数据备份：后续版本加入一键备份与恢复",
        ):
            label = QLabel("•  " + line)
            label.setObjectName("Muted")
            info_layout.addWidget(label)
        layout.addWidget(info_box)
        layout.addStretch()
        return widget

