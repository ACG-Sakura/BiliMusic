from pathlib import Path
import json


def test_netease_package_manifest_is_inside_service_directory():
    root = Path(__file__).resolve().parents[1]
    manifest = root / "netease-api" / "package.json"
    assert manifest.is_file()
    data = json.loads(manifest.read_text(encoding="utf-8"))
    assert "@neteasecloudmusicapienhanced/api" in data["dependencies"]
    assert (root / "netease-api" / "server.js").is_file()


def test_windows_build_uses_explicit_netease_service_directory():
    root = Path(__file__).resolve().parents[1]
    script = (root / "build_windows.bat").read_text(encoding="utf-8")
    assert "pushd netease-api" in script.lower()
    assert "npm install --omit=dev" in script
    assert "npm install --prefix netease-api" not in script


def test_ci_verifies_pyinstaller6_internal_netease_layout():
    root = Path(__file__).resolve().parents[1]
    workflow = (root / ".github" / "workflows" / "build-windows.yml").read_text(encoding="utf-8")
    assert "Join-Path $dist '_internal/netease-api'" in workflow
    assert "Join-Path $dist 'netease-api'" in workflow
    service = (root / "app" / "integrations" / "music" / "netease_service.py").read_text(encoding="utf-8")
    assert "meipass / \"netease-api\"" in service or 'meipass / "netease-api"' in service


def test_ci_extracts_versioned_source_zip_before_locating_project_root():
    root = Path(__file__).resolve().parents[1]
    workflow = (root / ".github" / "workflows" / "build-windows.yml").read_text(encoding="utf-8")
    extract_step = workflow.index("Extract and locate V0.4.394 source archive")
    expand_archive = workflow.index("Expand-Archive -LiteralPath $archive")
    locate_marker = workflow.index("$projectCandidates = Get-ChildItem")
    assert "BiliMusic_V0.4.394_Source.zip" in workflow
    assert extract_step < expand_archive < locate_marker
    assert "$env:RUNNER_TEMP" in workflow
    assert "BILIMUSIC_PROJECT=$project" in workflow


def test_skip_and_qt_stop_suppress_reentrant_end_events():
    root = Path(__file__).resolve().parents[1]
    playback = (root / "app" / "core" / "playback.py").read_text(encoding="utf-8")
    backend = (root / "app" / "integrations" / "music" / "qt_player.py").read_text(encoding="utf-8")
    assert 'self._stop_active("主播手动跳过")' in playback
    assert "self.current_source = None" in playback[playback.index("def _stop_active"):]
    assert "_suppress_end_until_playing = True" in backend
    assert "not self._suppress_end_until_playing" in backend


def test_login_status_is_verified_and_shown_not_just_credential_saved():
    root = Path(__file__).resolve().parents[1]
    ui = (root / "app" / "ui" / "main_window.py").read_text(encoding="utf-8")
    client = (root / "app" / "integrations" / "music" / "netease.py").read_text(encoding="utf-8")
    assert "验证登录状态" in ui
    assert "NeteaseAccountStatusWorker" in ui
    assert "UID {user_id}" in ui
    assert "网易云尚未确认登录状态" in client



def test_v0437_ui_exposes_full_playlist_lyrics_and_history_clear_features():
    root = Path(__file__).resolve().parents[1]
    ui = (root / "app" / "ui" / "main_window.py").read_text(encoding="utf-8")
    playback = (root / "app" / "core" / "playback.py").read_text(encoding="utf-8")
    playlists = (root / "app" / "core" / "playlists.py").read_text(encoding="utf-8")
    assert "播放全部歌曲（当前歌单）" in ui
    assert "doubleClicked.connect(self.play_selected_netease_track)" in ui
    assert '"歌词", "网易云歌曲自动获取逐句时间轴' in ui
    assert "scrollToItem(item, QAbstractItemView.PositionAtCenter)" in ui
    assert "clear_playback_history" in ui
    assert "cache_manager.clear_all()" in ui
    assert "def play_playlist(self, playlist_id: int)" in playback
    assert "self._playlist_playback_requested" in playback
    assert "def clear_playback_history(self)" in playlists


def test_obs_overlay_assets_are_bundled_and_dependencies_declared():
    root = Path(__file__).resolve().parents[1]
    workflow = (root / ".github" / "workflows" / "build-windows.yml").read_text(encoding="utf-8")
    script = (root / "build_windows.bat").read_text(encoding="utf-8")
    requirements = (root / "requirements.txt").read_text(encoding="utf-8")
    assert "--collect-all websockets" in workflow
    assert "app/integrations/obs/web;app/integrations/obs/web" in workflow
    assert "--collect-all websockets" in script
    assert "app\\integrations\\obs\\web;app\\integrations\\obs\\web" in script
    assert "websockets>=14,<17" in requirements
    assert (root / "app/integrations/obs/web/index.html").is_file()
    assert (root / "app/integrations/obs/web/app.js").is_file()
    assert (root / "app/integrations/obs/web/styles.css").is_file()
    assert not (root / "app/integrations/obs/web/fonts").exists()


def test_v04392_version_metadata_and_obs_font_assets_are_clean():
    root = Path(__file__).resolve().parents[1]
    metadata = (root / "pyproject.toml").read_text(encoding="utf-8")
    workflow = (root / ".github/workflows/build-windows.yml").read_text(encoding="utf-8")
    ui = (root / "app/ui/main_window.py").read_text(encoding="utf-8")
    assert 'version = "0.4.394"' in metadata
    assert "BiliMusic_V0.4.394_Source.zip" in workflow
    assert "V0.4.394" in ui
    assert not (root / "app/integrations/obs/web/fonts").exists()
