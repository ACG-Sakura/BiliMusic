# V0.4.394 Release Status

## 本次修复
- 修复 OBS 自定义 TTF 字体选择后不生效的问题。
- 原因：脚本只在 OBS overlay 子元素上设置 CSS 自定义属性，但 `body` 的 `font-family` 已在父级计算完成，子元素继承的是 `body` 的字体。
- 修复：将选定字体族直接设置到 `#overlay` 根元素，使所有显示文本继承该字体；调用 `document.fonts.load()` 主动触发字体加载。恢复系统默认时同步清除根元素字体设置。

## 自动化检查
- pytest：100 项通过。
- Python compileall：通过。
- OBS 前端 JavaScript 语法检查：通过。
- GitHub Actions YAML 解析：通过。

## 尚未验证
- 当前环境的 Chromium 页面导航被运行环境策略拦截，因此未完成真实浏览器字体渲染测试。
- 未运行 Windows PyInstaller 构建，未进行 OBS Studio Windows 实机验收。

本版基于 V0.4.393 修复字体应用逻辑，保留 TTF-only 字体选择、连续滚动和既有桌面播放器功能。
