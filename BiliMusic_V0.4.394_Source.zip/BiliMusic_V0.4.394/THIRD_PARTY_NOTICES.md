# Third-party references and notices

## Architecture reference

- `virtual-kori/Bili-Danmu-Songs-For-Netease` — https://github.com/virtual-kori/Bili-Danmu-Songs-For-Netease

BiliMusic V0.4.394 uses this project's documented overall design as a technical reference (local NetEase API service, QR login, search, queue, local playback and optional autoplay). BiliMusic does not copy its source files.

## OBS overlay architecture reference

- `Enkianssus/AwooMusicBot` — https://github.com/Enkianssus/AwooMusicBot
- `Enkianssus/AwooMusicBot-Overlay-Default` — https://github.com/Enkianssus/AwooMusicBot-Overlay-Default

V0.4.394 reviewed the documented local read-only HTTP + WebSocket pattern and OBS browser-source integration as an architectural reference. BiliMusic's OBS server and front-end files in this release are independently implemented and do not copy the referenced repositories' source files.

## Optional user-provided font asset

The OBS page uses the system font by default. Users may select a local TTF font file from the OBS settings page. The selected font is read from its original local path and served only by the loopback OBS endpoint; it is not copied into, installed by, or redistributed with BiliMusic.

## Runtime dependency

- npm package: `@neteasecloudmusicapienhanced/api` (pinned to `4.41.1` in `netease-api/package.json`)
- Upstream repository: https://github.com/NeteaseCloudMusicApiEnhanced/api-enhanced
- Upstream license: MIT (see the upstream repository's LICENSE file for the exact notice and terms).

The npm package is a community-maintained third-party API implementation, not a NetEase official SDK. BiliMusic launches it as a local service bound to `127.0.0.1` only. The BiliMusic launcher forcibly sets `ENABLE_GENERAL_UNBLOCK=false` and `ENABLE_PROXY=false`. Do not enable those options or expose the local service to other devices.

The package's own license covers its software terms only; it does not grant music copyright, platform API authorization, account entitlements, or permission to publicly transmit music. Users must follow applicable NetEase terms and copyright requirements.

## Other dependencies

Python dependency versions and licenses are declared by their respective PyPI distributions and are installed from `requirements.txt` / `requirements-dev.txt`. Qt / PySide6 is distributed under its applicable Qt licensing terms; consult the official Qt licensing page before redistribution: https://www.qt.io/licensing/.
