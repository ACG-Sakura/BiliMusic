# BiliMusic release status

- V0.1.4.2: accepted baseline for the original queue UI and drag sorting.
- V0.2.0: local message simulation and queue-rule workflow accepted by user.
- V0.3.0: Windows build accepted for local preview; real Bilibili Open Live end-to-end connection remains pending platform approval and permission validation.
- V0.4.1: expanded to QQ Music personal playlist metadata sync (requires the user's own API Key), local-file playback, playback history, and audience-queue/autoplay scheduling. NetEase official desktop sync and direct QQ/NetEase platform audio playback remain unverified/unimplemented; local playback is supported for user-imported files.
