# Music provider integration boundaries (V0.4.1)

Research checked on 2026-11-23. This note separates provider-documented capabilities from BiliMusic's implementation.

## QQ Music metadata

The Tencent Music-maintained `tencentmusic/qqmusic-skills` documentation describes a QQ Music personal music query skill. It documents a `POST https://a.y.qq.com/playlists/detail` route with `dissId` and optional `page`, returning playlist metadata (`dissName`, `desc`, `picUrl`, `totalNum`) and track metadata (`songMid`, `songName`, `singerName`, `songH5Url`). The same documentation says the key is user-bound, and states that the service is for personal music query/experience; it prohibits bulk library crawling, data mining, or other unauthorized use.

BiliMusic therefore only sends a user-initiated read-only query for the selected playlist, spaces paged requests, stores metadata and official H5 links, and does not request or store audio addresses.

Reference: https://github.com/tencentmusic/qqmusic-skills/blob/main/qqmusic/SKILL.md
Reference: https://github.com/tencentmusic/qqmusic-skills/blob/main/qqmusic/playlists.md

## QQ Music audio playback

Public documentation for Tencent LianLian's QQ Music SDK documents account authorization, playback URL fields, playlist construction, and sync-to-IoT-device operations. However, that SDK is documented for a Tencent LianLian custom H5/IoT environment. It does not establish that an independent Windows desktop application may embed those playback URLs or control playback directly. This version does not repurpose that SDK or fetch audio URLs.

Reference: https://cloud.tencent.com/document/product/1081/67456

## NetEase Cloud Music

The public research located NetEase's official developer contact route, but did not establish a public API specification authorizing playlist synchronization and audio playback from a standalone Windows desktop client. Third-party reverse-engineered endpoints and cookie-based clients are intentionally not used. NetEase playlist URLs can be stored and opened in the official service; automated synchronization remains disabled pending written provider documentation or approval suitable for this app.

Reference: https://app.wyyunmusic.com/contact.html

## BiliMusic local playback

The actual player in this build plays only files explicitly imported by the user from the local machine via Qt Multimedia. A locally playable file is not, by itself, proof that it may be rebroadcast; the user must have the necessary rights for any live use. The app does not decrypt DRM, extract platform streams, or bypass subscription/paywall controls.
