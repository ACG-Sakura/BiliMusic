"""Playback scheduler independent of Qt, testable with a fake audio backend."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Protocol


class AudioBackend(Protocol):
    def play_file(self, path: str) -> None: ...
    def pause(self) -> None: ...
    def resume(self) -> None: ...
    def stop(self) -> None: ...
    def set_volume(self, value: float) -> None: ...


class PlaybackCoordinator:
    """Audience requests interrupt autoplay; audience requests never interrupt each other."""

    def __init__(self, queue, playlists, backend: AudioBackend,
                 on_state: Callable[[str, str], None] | None = None):
        self.queue = queue
        self.playlists = playlists
        self.backend = backend
        self.on_state = on_state or (lambda _state, _detail: None)
        self.current_source: str | None = None
        self.current_track = None
        self.current_started_at = ""
        self._auto_order: list[int] = []
        self._auto_pos = 0
        self._autoplay_last_id: int | None = None
        self._inside_callback = False

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat(timespec="seconds")

    def poll(self) -> None:
        queued = self.queue.list_queue()
        if queued:
            if self.current_source == "autoplay":
                self._finish_current("被观众点歌中断")
                self.backend.stop()
                self.current_source = None
                self.current_track = None
            if self.current_source is None:
                self._start_next_request()
            return
        if self.current_source is None and self.playlists.autoplay_enabled():
            self._start_next_autoplay()

    def _start_next_request(self) -> None:
        queued = self.queue.list_queue()
        if not queued:
            if self.playlists.autoplay_enabled():
                self._start_next_autoplay()
            return
        self.queue.mark_playing(queued[0].id)
        self._start_request_id(queued[0].id)

    def _start_request_id(self, song_id: int) -> None:
        """Start a queue row already marked as playing; skip unresolved rows safely."""
        current_id: int | None = song_id
        while current_id is not None:
            song = self.queue.get_song(current_id)
            if song is None:
                current_id = None
                break
            local = self.playlists.find_local_audio(song.title, song.artist)
            if local is None:
                self.playlists.record_playback(song.title, song.artist, "观众点歌", song.requester_name,
                                               "本地未找到匹配音频，已跳过", "", self._now(), self._now())
                self.on_state("未找到音频", f"《{song.title}》没有匹配的本地音频文件，已跳过。")
                current_id = self.queue.finish_current(skipped=True)
                continue
            self._start_file(local, "观众点歌", song.requester_name)
            if self.current_source == "request":
                return
            # Audio backend rejected the source. _start_file may have left the row
            # marked playing, so advance through the queue rather than wedging it.
            current_id = self.queue.finish_current(skipped=True)
        self.current_source = None
        self.current_track = None
        if self.playlists.autoplay_enabled():
            self._start_next_autoplay()

    def _start_file(self, track, source: str, requester_name: str = "") -> None:
        path = Path(track.file_path)
        if not path.is_file():
            self.on_state("文件不存在", str(path))
            return
        try:
            self.backend.play_file(str(path))
        except Exception as exc:
            self.on_state("播放失败", str(exc))
            return
        self.current_source = "request" if source == "观众点歌" else "autoplay"
        self.current_track = (track, source, requester_name)
        self.current_started_at = self._now()
        self.on_state("正在播放", f"{track.title} — {track.artist or '未知歌手'}")

    def _next_autoplay_track(self):
        tracks = self.playlists.list_local_audio_tracks()
        if not tracks:
            return None
        mode = self.playlists.local_audio_mode()
        if mode == "随机播放":
            import random
            choices = [t for t in tracks if t.id != self._autoplay_last_id] or tracks
            track = random.choice(choices)
        else:
            if not self._auto_order:
                self._auto_order = [t.id for t in tracks]
                self._auto_pos = 0
            if self._auto_pos >= len(self._auto_order):
                if mode == "顺序播放":
                    return None
                self._auto_pos = 0
            target_id = self._auto_order[self._auto_pos]
            self._auto_pos += 1
            track = next((t for t in tracks if t.id == target_id), None)
        return track

    def _start_next_autoplay(self) -> None:
        if not self.playlists.autoplay_enabled() or self.current_source is not None:
            return
        track = self._next_autoplay_track()
        if track is None:
            self.on_state("等待音频", "自动播放已开启，但本地音频库为空或已播放完毕。")
            return
        attempts = len(self.playlists.list_local_audio_tracks())
        while attempts and track is not None and not Path(track.file_path).is_file():
            self.on_state("文件不存在", f"已跳过：{track.file_path}")
            self._autoplay_last_id = track.id
            track = self._next_autoplay_track()
            attempts -= 1
        if track is None or not Path(track.file_path).is_file():
            self.on_state("等待音频", "本地音频库中没有可播放的文件。")
            return
        self._autoplay_last_id = track.id
        self._start_file(track, "自动播放")

    def on_track_ended(self) -> None:
        if self.current_source is None:
            return
        source = self.current_source
        self._finish_current("播放完成")
        self.current_source = None
        self.current_track = None
        if source == "request":
            next_id = self.queue.finish_current(skipped=False)
            if next_id is not None:
                self._start_request_id(next_id)
            else:
                self._start_next_autoplay()
        else:
            self._start_next_request()

    def play_local_track(self, track_id: int) -> bool:
        track = next((t for t in self.playlists.list_local_audio_tracks() if t.id == track_id), None)
        if track is None or not Path(track.file_path).is_file():
            self.on_state("文件不存在", "所选本地音频文件不存在。")
            return False
        if self.current_source == "request":
            self.on_state("当前有观众点歌", "观众点歌正在播放，不能用手动播放打断。")
            return False
        if self.current_source:
            self._finish_current("主播切换歌曲")
            self.backend.stop()
        self.current_source = None
        self.current_track = None
        self._start_file(track, "主播手动播放")
        return self.current_source is not None

    def skip_current(self) -> None:
        if self.current_source is None:
            self.poll()
            return
        source = self.current_source
        self._finish_current("主播手动跳过")
        self.backend.stop()
        self.current_source = None
        self.current_track = None
        if source == "request":
            next_id = self.queue.finish_current(skipped=True)
            if next_id is not None:
                self._start_request_id(next_id)
            else:
                self._start_next_autoplay()
        else:
            self._start_next_request()

    def handle_error(self, message: str) -> None:
        if self.current_source is None:
            self.on_state("播放错误", message)
            return
        source = self.current_source
        self._finish_current(f"播放错误：{message}")
        self.backend.stop()
        self.current_source = None
        self.current_track = None
        if source == "request":
            next_id = self.queue.finish_current(skipped=True)
            if next_id is not None:
                self._start_request_id(next_id)
            else:
                self._start_next_autoplay()
        else:
            self._start_next_request()

    def pause(self) -> None:
        self.backend.pause()

    def resume(self) -> None:
        self.backend.resume()

    def set_volume(self, value: float) -> None:
        self.backend.set_volume(max(0.0, min(1.0, float(value))))

    def _finish_current(self, result: str) -> None:
        if not self.current_track:
            return
        track, source, requester = self.current_track
        self.playlists.record_playback(track.title, track.artist, source, requester, result,
                                       track.file_path, self.current_started_at or self._now(), self._now())
        self.on_state(result, f"{track.title} — {track.artist or '未知歌手'}")
