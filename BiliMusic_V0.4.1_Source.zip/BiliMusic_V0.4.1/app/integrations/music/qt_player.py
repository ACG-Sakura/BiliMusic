"""Qt Multimedia adapter for user-imported local audio files."""
from __future__ import annotations

from PySide6.QtCore import QObject, QUrl
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer


class QtLocalAudioBackend(QObject):
    def __init__(self, on_ended, on_error, on_position=None, parent=None):
        super().__init__(parent)
        self.player = QMediaPlayer(self)
        self.audio = QAudioOutput(self)
        self.player.setAudioOutput(self.audio)
        self._on_ended = on_ended
        self._on_error = on_error
        self._on_position = on_position or (lambda _position, _duration: None)
        self.player.mediaStatusChanged.connect(self._status_changed)
        self.player.errorOccurred.connect(self._error_changed)
        self.player.positionChanged.connect(self._position_changed)
        self.player.durationChanged.connect(lambda _duration: self._position_changed(self.player.position()))

    def play_file(self, path: str) -> None:
        url = QUrl.fromLocalFile(path)
        if not url.isValid() or url.isEmpty():
            raise ValueError("本地音频文件路径无效。")
        self.player.setSource(url)
        self.player.play()

    def pause(self) -> None:
        self.player.pause()

    def resume(self) -> None:
        self.player.play()

    def stop(self) -> None:
        self.player.stop()

    def set_volume(self, value: float) -> None:
        self.audio.setVolume(max(0.0, min(1.0, float(value))))

    def set_position(self, milliseconds: int) -> None:
        self.player.setPosition(max(0, int(milliseconds)))

    def _status_changed(self, status) -> None:
        if status == QMediaPlayer.MediaStatus.EndOfMedia:
            self._on_ended()

    def _error_changed(self, _error, error_string: str) -> None:
        if error_string:
            self._on_error(error_string)

    def _position_changed(self, position: int) -> None:
        self._on_position(int(position), int(self.player.duration()))
