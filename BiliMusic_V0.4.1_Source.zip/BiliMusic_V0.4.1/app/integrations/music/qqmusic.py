"""Read-only QQ Music personal playlist metadata client.

This uses only the documented QQ Music Skills endpoint. It never requests audio
URLs, extracts protected media, handles cookies, or bypasses membership.
"""
from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlparse
from urllib.request import Request, urlopen


class MusicProviderError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class RemotePlaylistTrack:
    external_id: str
    title: str
    artist: str
    external_url: str = ""


@dataclass(frozen=True, slots=True)
class RemotePlaylist:
    playlist_id: str
    name: str
    description: str
    cover_url: str
    total_count: int
    tracks: tuple[RemotePlaylistTrack, ...]


def parse_qq_playlist_id(source_ref: str) -> str:
    value = (source_ref or "").strip()
    if value.isdigit():
        return value
    parsed = urlparse(value)
    query = parse_qs(parsed.query)
    for key in ("id", "dissid", "disstid"):
        candidate = query.get(key, [""])[0]
        if candidate.isdigit():
            return candidate
    match = re.search(r"(?:playlist|diss)[/=:](\d{3,20})", parsed.path + parsed.query, re.I)
    if match:
        return match.group(1)
    raise ValueError("无法从来源链接中识别 QQ 音乐歌单 ID，请填写数字歌单 ID 或官方歌单链接。")


class QQMusicSkillsClient:
    """User-initiated, read-only playlist metadata lookup via QQ Music Skills."""
    BASE_URL = "https://a.y.qq.com"
    SKILL_VERSION = "0.0.3"
    PAGE_LIMIT = 100

    def __init__(self, api_key: str, timeout: float = 12.0, min_interval: float = 0.5,
                 opener=urlopen, sleep=time.sleep):
        key = (api_key or "").strip()
        if not key.startswith("qmk-") or len(key) < 12:
            raise ValueError("QQ 音乐 API Key 格式不正确。")
        self._api_key = key
        self.timeout = timeout
        self.min_interval = max(0.0, min_interval)
        self._opener = opener
        self._sleep = sleep
        self._last_request = 0.0

    def _post(self, path: str, params: dict) -> dict:
        wait = self.min_interval - (time.monotonic() - self._last_request)
        if wait > 0:
            self._sleep(wait)
        payload = json.dumps(
            {"params": params, "comm": {"skill_version": self.SKILL_VERSION}},
            ensure_ascii=False,
        ).encode("utf-8")
        request = Request(
            self.BASE_URL + path,
            data=payload,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "BiliMusic/0.4.1 (personal playlist metadata sync)",
            },
            method="POST",
        )
        try:
            with self._opener(request, timeout=self.timeout) as response:
                raw = response.read(4 * 1024 * 1024 + 1)
            self._last_request = time.monotonic()
        except HTTPError as exc:
            raise MusicProviderError(f"QQ 音乐接口返回 HTTP {exc.code}。请检查 API Key 或稍后重试。") from exc
        except (URLError, TimeoutError, OSError) as exc:
            raise MusicProviderError("无法连接 QQ 音乐服务，请检查网络后重试。") from exc
        if len(raw) > 4 * 1024 * 1024:
            raise MusicProviderError("QQ 音乐返回内容过大，已停止读取。")
        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise MusicProviderError("QQ 音乐返回了无法识别的数据。") from exc
        if not isinstance(data, dict):
            raise MusicProviderError("QQ 音乐返回数据格式不正确。")
        for code_key in ("ret", "sub_ret"):
            code = data.get(code_key)
            if code not in (None, 0, "0", ""):
                message = str(data.get("msg") or "请求未成功")
                raise MusicProviderError(f"QQ 音乐接口错误：{message}（{code_key}={code}）。")
        return data

    def fetch_playlist(self, source_ref: str) -> RemotePlaylist:
        playlist_id = parse_qq_playlist_id(source_ref)
        tracks: list[RemotePlaylistTrack] = []
        name = ""
        description = ""
        cover = ""
        total = 0
        page = 0
        while page < self.PAGE_LIMIT:
            data = self._post("/playlists/detail", {"dissId": int(playlist_id), "page": page})
            if page == 0:
                name = str(data.get("dissName") or "QQ 音乐歌单")
                description = str(data.get("desc") or "")
                cover = str(data.get("picUrl") or "")
                try:
                    total = int(data.get("totalNum") or 0)
                except (TypeError, ValueError):
                    total = 0
            entries = data.get("trackList") or []
            if not isinstance(entries, list):
                raise MusicProviderError("QQ 音乐歌单歌曲列表格式不正确。")
            for item in entries:
                if not isinstance(item, dict):
                    continue
                song_id = str(item.get("songMid") or "").strip()
                title = str(item.get("songName") or "").strip()
                artist = str(item.get("singerName") or "").strip()
                link = str(item.get("songH5Url") or "").strip()
                if song_id and title:
                    tracks.append(RemotePlaylistTrack(song_id, title, artist, link))
            if not data.get("hasMore"):
                break
            page += 1
        else:
            raise MusicProviderError("歌单分页超过安全上限，已停止同步。")
        if not name and not tracks:
            raise MusicProviderError("QQ 音乐没有返回歌单内容，请确认链接和 API Key 权限。")
        return RemotePlaylist(playlist_id, name, description, cover, total, tuple(tracks))
