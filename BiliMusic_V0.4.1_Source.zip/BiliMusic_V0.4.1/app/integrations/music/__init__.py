"""Music platform integration boundary."""

from .qqmusic import QQMusicSkillsClient, MusicProviderError
from .secret_store import WindowsMusicSecretStore, SecretStoreError

__all__ = ["QQMusicSkillsClient", "MusicProviderError", "WindowsMusicSecretStore", "SecretStoreError"]
