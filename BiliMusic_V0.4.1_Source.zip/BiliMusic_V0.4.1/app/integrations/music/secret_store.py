"""Windows DPAPI-backed storage for music provider API keys."""
from __future__ import annotations

import ctypes
import os
from ctypes import wintypes
from pathlib import Path
from platformdirs import user_data_dir


class SecretStoreError(RuntimeError):
    pass


class _DataBlob(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]


class WindowsMusicSecretStore:
    ENTROPY = b"BiliMusic.MusicProvider.Secrets.v1"

    def __init__(self, path: str | Path | None = None):
        self.path = Path(path) if path else Path(user_data_dir("BiliMusic", "BiliMusic")) / "music-secrets.bin"

    @staticmethod
    def _require_windows():
        if os.name != "nt":
            raise SecretStoreError("音乐平台密钥安全存储仅支持 Windows。")

    @classmethod
    def _crypt(cls, data: bytes, decrypt: bool) -> bytes:
        cls._require_windows()
        crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        source_buf = ctypes.create_string_buffer(data)
        entropy_buf = ctypes.create_string_buffer(cls.ENTROPY)
        source = _DataBlob(len(data), ctypes.cast(source_buf, ctypes.POINTER(ctypes.c_byte)))
        entropy = _DataBlob(len(cls.ENTROPY), ctypes.cast(entropy_buf, ctypes.POINTER(ctypes.c_byte)))
        output = _DataBlob()
        if decrypt:
            crypt32.CryptUnprotectData.argtypes = [ctypes.POINTER(_DataBlob), ctypes.POINTER(wintypes.LPWSTR), ctypes.POINTER(_DataBlob), wintypes.LPVOID, wintypes.LPVOID, wintypes.DWORD, ctypes.POINTER(_DataBlob)]
            crypt32.CryptUnprotectData.restype = wintypes.BOOL
            ok = crypt32.CryptUnprotectData(ctypes.byref(source), None, ctypes.byref(entropy), None, None, 0, ctypes.byref(output))
        else:
            crypt32.CryptProtectData.argtypes = [ctypes.POINTER(_DataBlob), wintypes.LPCWSTR, ctypes.POINTER(_DataBlob), wintypes.LPVOID, wintypes.LPVOID, wintypes.DWORD, ctypes.POINTER(_DataBlob)]
            crypt32.CryptProtectData.restype = wintypes.BOOL
            ok = crypt32.CryptProtectData(ctypes.byref(source), "BiliMusic Music API keys", ctypes.byref(entropy), None, None, 0x1, ctypes.byref(output))
        if not ok:
            raise SecretStoreError(f"Windows DPAPI 操作失败（错误码 {ctypes.get_last_error()}）。")
        kernel32.LocalFree.argtypes = [wintypes.HLOCAL]
        kernel32.LocalFree.restype = wintypes.HLOCAL
        try:
            return ctypes.string_at(output.pbData, output.cbData)
        finally:
            kernel32.LocalFree(ctypes.cast(output.pbData, wintypes.HLOCAL))

    def save(self, api_key: str) -> None:
        value = (api_key or "").strip()
        if not value.startswith("qmk-"):
            raise ValueError("QQ 音乐 API Key 格式不正确。")
        encrypted = self._crypt(value.encode("utf-8"), False)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_suffix(self.path.suffix + ".tmp")
        temp.write_bytes(encrypted)
        os.replace(temp, self.path)

    def load(self) -> str | None:
        if not self.path.exists():
            return None
        try:
            return self._crypt(self.path.read_bytes(), True).decode("utf-8")
        except SecretStoreError:
            raise
        except Exception as exc:
            raise SecretStoreError("无法读取本机已保存的音乐平台密钥，请重新保存。") from exc

    def delete(self) -> None:
        self.path.unlink(missing_ok=True)
