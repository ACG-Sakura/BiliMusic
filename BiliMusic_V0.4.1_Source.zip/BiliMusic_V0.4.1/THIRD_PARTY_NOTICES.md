# Third-party references and notices

BiliMusic V0.1.1 contains no source code copied from the reference repositories listed below. They are acknowledged as design and technical research references only.

- AwooMusicBot — https://github.com/Enkianssus/AwooMusicBot
- BiliHUD — https://github.com/locez/bilihud
- blivedm — https://github.com/xfgryujk/blivedm
- NekoFM — https://github.com/7starsseeker/nekofm

If code from any third-party project is incorporated in a later release, its license, notices, dependencies, and applicable platform terms must be reviewed and preserved before distribution.

## V0.4.1 music provider documentation references

- QQ Music Skills documentation maintained by Tencent Music: https://github.com/tencentmusic/qqmusic-skills
- Tencent Cloud IoT QQ Music H5 SDK documentation (research reference only; not repurposed as a Windows playback SDK): https://cloud.tencent.com/document/product/1081/67456
- NetEase Cloud Music official developer contact information: https://app.wyyunmusic.com/contact.html

BiliMusic V0.4.1 does not copy provider SDK implementation code. It uses the documented QQ Music Skills read-only playlist metadata request shape and keeps provider audio delivery outside the application until an applicable desktop authorization is established.
