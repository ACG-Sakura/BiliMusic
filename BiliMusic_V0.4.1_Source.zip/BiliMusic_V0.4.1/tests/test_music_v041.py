from __future__ import annotations

import json
from pathlib import Path

import pytest

from app.core.playback import PlaybackCoordinator
from app.core.playlists import PlaylistService
from app.core.queue_service import QueueService
from app.storage.database import Database
from app.integrations.music.qqmusic import QQMusicSkillsClient, MusicProviderError, parse_qq_playlist_id, RemotePlaylist


class FakeBackend:
    def __init__(self):
        self.played = []
        self.stopped = 0
        self.paused = 0
        self.resumed = 0
        self.volume = 1.0

    def play_file(self, path):
        self.played.append(path)

    def pause(self): self.paused += 1
    def resume(self): self.resumed += 1
    def stop(self): self.stopped += 1
    def set_volume(self, value): self.volume = value


def make_services(tmp_path):
    db = Database(tmp_path / "test.db")
    db.initialize()
    playlists = PlaylistService(db)
    queue = QueueService(db)
    return db, playlists, queue


def test_local_audio_import_dedupe_and_title_matching(tmp_path):
    _db, service, _queue = make_services(tmp_path)
    audio = tmp_path / "晴天.mp3"
    audio.write_bytes(b"dummy test fixture")
    assert service.add_local_audio_files([audio, audio]) == 1
    tracks = service.list_local_audio_tracks()
    assert len(tracks) == 1
    assert tracks[0].title == "晴天"
    assert service.find_local_audio(" 晴天 ") == tracks[0]


def test_point_request_interrupts_autoplay_and_resumes_next_track(tmp_path):
    _db, playlists, queue = make_services(tmp_path)
    first = tmp_path / "自动一.mp3"
    second = tmp_path / "晴天.mp3"
    first.write_bytes(b"a")
    second.write_bytes(b"b")
    playlists.add_local_audio_files([first, second])
    playlists.set_local_audio_mode("列表循环")
    playlists.set_autoplay(True)
    backend = FakeBackend()
    coordinator = PlaybackCoordinator(queue, playlists, backend)

    coordinator.poll()
    assert Path(backend.played[-1]).name == "自动一.mp3"
    assert coordinator.current_source == "autoplay"

    queue.enqueue("晴天", requester_name="观众A", source="danmaku")
    coordinator.poll()
    assert backend.stopped == 1
    assert Path(backend.played[-1]).name == "晴天.mp3"
    assert coordinator.current_source == "request"

    coordinator.on_track_ended()
    assert Path(backend.played[-1]).name == "晴天.mp3" or coordinator.current_source == "autoplay"
    assert coordinator.current_source == "autoplay"
    # The interrupted autoplay track is skipped; playback proceeds from the next item.
    assert Path(backend.played[-1]).name == "晴天.mp3"


def test_unmatched_request_is_skipped_and_autoplay_can_continue(tmp_path):
    db, playlists, queue = make_services(tmp_path)
    track = tmp_path / "本地歌曲.mp3"
    track.write_bytes(b"a")
    playlists.add_local_audio_files([track])
    playlists.set_autoplay(True)
    backend = FakeBackend()
    coordinator = PlaybackCoordinator(queue, playlists, backend)
    bad_id = queue.enqueue("曲库没有这首", requester_name="观众B", source="danmaku")

    coordinator.poll()

    status = db.fetchone("SELECT status FROM songs WHERE id=?", (bad_id,))["status"]
    assert status == "skipped"
    assert coordinator.current_source == "autoplay"
    assert Path(backend.played[-1]).name == "本地歌曲.mp3"


def test_playback_history_written(tmp_path):
    _db, playlists, _queue = make_services(tmp_path)
    playlists.record_playback("晴天", "周杰伦", "自动播放", "", "播放完成", "/music/qingtian.mp3", "start", "end")
    rows = playlists.playback_history()
    assert len(rows) == 1
    assert rows[0]["result"] == "播放完成"


def test_qq_playlist_id_parser():
    assert parse_qq_playlist_id("123456") == "123456"
    assert parse_qq_playlist_id("https://y.qq.com/n/ryqq/playlist/123456") == "123456"
    assert parse_qq_playlist_id("https://y.qq.com/n/ryqq/playlist?id=123456") == "123456"
    with pytest.raises(ValueError):
        parse_qq_playlist_id("not a playlist")


def test_qq_music_skills_client_uses_documented_read_only_route_and_parses_pages():
    payloads = [
        {"dissId": 123456, "dissName": "测试歌单", "desc": "desc", "picUrl": "https://img.example/cover.jpg",
         "totalNum": 2, "hasMore": True,
         "trackList": [{"songMid": "abc", "songName": "晴天", "singerName": "周杰伦", "songH5Url": "https://y.qq.com/song/abc"}]},
        {"dissId": 123456, "dissName": "测试歌单", "totalNum": 2, "hasMore": False,
         "trackList": [{"songMid": "def", "songName": "稻香", "singerName": "周杰伦", "songH5Url": "https://y.qq.com/song/def"}]},
    ]
    requests = []

    class Response:
        def __init__(self, value): self.value = value
        def __enter__(self): return self
        def __exit__(self, *_): pass
        def read(self, _limit): return json.dumps(self.value).encode()

    def opener(request, timeout):
        requests.append(request)
        return Response(payloads[len(requests) - 1])

    client = QQMusicSkillsClient("qmk-1234567890abcdef", opener=opener, sleep=lambda _t: None, min_interval=0)
    result = client.fetch_playlist("123456")
    assert result.name == "测试歌单"
    assert [track.title for track in result.tracks] == ["晴天", "稻香"]
    assert len(requests) == 2
    assert all(req.full_url == "https://a.y.qq.com/playlists/detail" for req in requests)
    assert all(req.get_header("Authorization") == "Bearer qmk-1234567890abcdef" for req in requests)
    bodies = [json.loads(req.data.decode()) for req in requests]
    assert bodies[0]["params"] == {"dissId": 123456, "page": 0}
    assert bodies[1]["params"]["page"] == 1


def test_sync_remote_playlist_replaces_metadata_snapshot(tmp_path):
    _db, service, _queue = make_services(tmp_path)
    pid = service.add_playlist("old", "QQ音乐", "123")
    service.add_track(pid, "manual old")

    class Item:
        def __init__(self, external_id, title, artist, external_url):
            self.external_id = external_id; self.title = title; self.artist = artist; self.external_url = external_url

    remote = RemotePlaylist("123", "已同步歌单", "说明", "https://img.example/cover.jpg", 1,
                            (Item("mid-1", "晴天", "周杰伦", "https://y.qq.com/song/mid-1"),))
    service.replace_synced_tracks(pid, remote)
    rows = service.list_tracks(pid)
    assert len(rows) == 1
    assert rows[0].title == "晴天"
    assert rows[0].source_ref == "mid-1"
    assert service.get_playlist(pid)["name"] == "已同步歌单"


def test_playlist_service_migrates_existing_v040_tables(tmp_path):
    import sqlite3
    db_path = tmp_path / "legacy-v040.db"
    conn = sqlite3.connect(db_path)
    conn.execute("""CREATE TABLE playlists (
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
        platform TEXT NOT NULL CHECK(platform IN ('网易云音乐','QQ音乐')),
        source_ref TEXT NOT NULL DEFAULT '', play_mode TEXT NOT NULL DEFAULT '顺序播放',
        enabled INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )""")
    conn.execute("""CREATE TABLE playlist_tracks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        playlist_id INTEGER NOT NULL REFERENCES playlists(id) ON DELETE CASCADE,
        title TEXT NOT NULL, artist TEXT NOT NULL DEFAULT '',
        source_ref TEXT NOT NULL DEFAULT '', position INTEGER NOT NULL DEFAULT 0,
        UNIQUE(playlist_id, position)
    )""")
    conn.execute("INSERT INTO playlists(name,platform,source_ref) VALUES('旧歌单','QQ音乐','123456')")
    conn.execute("INSERT INTO playlist_tracks(playlist_id,title) VALUES(1,'旧歌曲')")
    conn.commit(); conn.close()

    db = Database(db_path)
    service = PlaylistService(db)
    assert service.list_playlists()[0].name == "旧歌单"
    assert service.list_tracks(1)[0].title == "旧歌曲"
    columns = {row["name"] for row in db.fetchall("PRAGMA table_info(playlists)")}
    assert "sync_status" in columns and "cover_url" in columns


def test_local_audio_track_metadata_can_be_edited(tmp_path):
    _db, service, _queue = make_services(tmp_path)
    audio = tmp_path / "01 - 周杰伦 - qingtian.mp3"
    audio.write_bytes(b"a")
    service.add_local_audio_files([audio])
    track = service.list_local_audio_tracks()[0]
    service.update_local_audio_track(track.id, "晴天", "周杰伦")
    matched = service.find_local_audio("晴天", "周杰伦")
    assert matched is not None
    assert matched.file_path == str(audio.resolve())
