# V0.4.393 Release Status

## 本版改动

- 基于 V0.4.392 TTF-only 源码包推进版本号至 0.4.393；本次不改变功能实现。
- 待播列表改为 requestAnimationFrame 驱动的匀速连续滚动，固定速度 22 px/s，不提供速度选项。
- 待播不超过三首时静止；超过三首时滚动；通过整份队列复制实现无缝循环。
- 队列变化时尽量保持当前顶部歌曲及其行内偏移，避免每次更新跳回开头。
- 移除预设字体资源与硬编码字体引用，默认使用系统字体。
- OBS 设置页新增本地字体选择和恢复系统默认，仅支持 TTF。
- 字体文件从用户所选原始路径读取，仅通过本机 OBS HTTP 服务的 `/overlay/custom-font` 路由提供；不会安装字体、复制文件、打包字体或暴露原始路径。
- 字体路径失效或格式无效时自动回退系统字体。

## 本地自动化验证

- `pytest -q`：99 项通过（本次 TTF-only 修改后重新执行）。
- `python -m compileall -q app tests main.py`：通过。
- `node --check app/integrations/obs/web/app.js`：通过。
- `pyproject.toml` 版本和 GitHub Actions YAML 解析：通过，版本为 `0.4.393`。
- 测试覆盖TTF 字体文件头标识及 OTF/TTC 拒绝、错误格式拒绝、选中字体的 HTTP 提供、字体缺失时 404，以及连续滚动的固定速度/RAF 代码结构。

## 尚未完成的实机验收

- 当前容器没有安装 PySide6，因此没有启动完整 Qt 桌面 GUI，也没有运行 Windows PyInstaller 构建。
- 尝试使用容器中的 Chromium 做实际页面动画/字体加载验证，但浏览器导航被运行环境拦截（`ERR_BLOCKED_BY_ADMINISTRATOR`），因此不将浏览器渲染验证计为通过。
- 仍需在 Windows 上构建后，使用 OBS Studio Browser Source 检查连续滚动视觉效果，以及所选 TTF 字体是否按预期显示。

## 版本范围

V0.4.393 保留 V0.4.392 的 OBS 待播队列动画和 OBS 字体配置，不改变原播放器、歌单、歌词或 B 站接入状态。没有加入滚动速度选项。B 站直播弹幕/官方开放平台真实接入不在本版范围内。
