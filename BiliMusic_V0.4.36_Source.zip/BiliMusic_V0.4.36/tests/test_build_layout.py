from pathlib import Path
import json


def test_netease_package_manifest_is_inside_service_directory():
    root = Path(__file__).resolve().parents[1]
    manifest = root / "netease-api" / "package.json"
    assert manifest.is_file()
    data = json.loads(manifest.read_text(encoding="utf-8"))
    assert "@neteasecloudmusicapienhanced/api" in data["dependencies"]
    assert (root / "netease-api" / "server.js").is_file()


def test_windows_build_uses_explicit_netease_service_directory():
    root = Path(__file__).resolve().parents[1]
    script = (root / "build_windows.bat").read_text(encoding="utf-8")
    assert "pushd netease-api" in script.lower()
    assert "npm install --omit=dev" in script
    assert "npm install --prefix netease-api" not in script


def test_ci_verifies_pyinstaller6_internal_netease_layout():
    root = Path(__file__).resolve().parents[1]
    workflow = (root / ".github" / "workflows" / "build-windows.yml").read_text(encoding="utf-8")
    assert "Join-Path $dist '_internal/netease-api'" in workflow
    assert "Join-Path $dist 'netease-api'" in workflow
    service = (root / "app" / "integrations" / "music" / "netease_service.py").read_text(encoding="utf-8")
    assert "meipass / \"netease-api\"" in service or 'meipass / "netease-api"' in service


def test_ci_extracts_versioned_source_zip_before_locating_project_root():
    root = Path(__file__).resolve().parents[1]
    workflow = (root / ".github" / "workflows" / "build-windows.yml").read_text(encoding="utf-8")
    extract_step = workflow.index("Extract and locate V0.4.36 source archive")
    expand_archive = workflow.index("Expand-Archive -LiteralPath $archive")
    locate_marker = workflow.index("$projectCandidates = Get-ChildItem")
    assert "BiliMusic_V0.4.36_Source.zip" in workflow
    assert extract_step < expand_archive < locate_marker
    assert "$env:RUNNER_TEMP" in workflow
    assert "BILIMUSIC_PROJECT=$project" in workflow


def test_skip_and_qt_stop_suppress_reentrant_end_events():
    root = Path(__file__).resolve().parents[1]
    playback = (root / "app" / "core" / "playback.py").read_text(encoding="utf-8")
    backend = (root / "app" / "integrations" / "music" / "qt_player.py").read_text(encoding="utf-8")
    assert 'self._stop_active("主播手动跳过")' in playback
    assert "self.current_source = None" in playback[playback.index("def _stop_active"):]
    assert "_suppress_end_until_playing = True" in backend
    assert "not self._suppress_end_until_playing" in backend


def test_login_status_is_verified_and_shown_not_just_credential_saved():
    root = Path(__file__).resolve().parents[1]
    ui = (root / "app" / "ui" / "main_window.py").read_text(encoding="utf-8")
    client = (root / "app" / "integrations" / "music" / "netease.py").read_text(encoding="utf-8")
    assert "验证登录状态" in ui
    assert "NeteaseAccountStatusWorker" in ui
    assert "UID {user_id}" in ui
    assert "网易云尚未确认登录状态" in client
