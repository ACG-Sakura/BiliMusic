# BiliMusic V0.3.0 — Windows 本地桌面开发版

BiliMusic 是面向 B站主播的本地点歌桌面软件。V0.3.0 在用户已实机验收的 V0.2.0 本地功能基线上，新增 B站直播开放平台接入预览模块。

> **重要状态区分**：V0.2.0 本地模拟消息、点歌队列、规则和既有桌面功能已由用户在 Windows 实机验收通过。V0.3.0 的真实 B站官方连接尚未用已获批的开发者凭证完成联调，因此当前仍是接入预览，不代表已成功连接 B站。

## V0.3.0 新增内容

- 官方 API 客户端：`/v2/app/start`、`/v2/app/heartbeat`、`/v2/app/end`。
- API 请求签名模块（HMAC-SHA256）及精确请求体 MD5。
- WSS 后台连接、鉴权包、消息帧解析、长连心跳和项目心跳。
- 多个官方返回 WSS 节点的备用尝试。
- 官方消息映射：弹幕、SC、大航海、礼物、点赞、进房、开播/下播。
- 新增「B站开放平台」页面，可填写并安全保存凭证、发起/断开连接、查看事件处理结果。
- 凭证由 Windows DPAPI 按当前 Windows 用户加密保存，不进入 SQLite、普通 JSON 或运行日志。

## V0.2.0 本地验收通过基线

- 蓝白色 MD3 浅色界面、SQLite 数据持久化。
- 点歌队列、手动添加、删除、上移/下移、鼠标拖动排序。
- 点歌规则、身份优先级、SC 金额档位。
- 「B站消息测试」本地模拟界面。
- 点歌弹幕格式：`点歌 歌名 歌手`，歌手可省略。

## 开始真实接入前的必要条件

1. B站开放平台开发者权限及审核通过后发放的 `access_key` / `access_secret`。
2. 已创建并按平台要求审核的项目 `app_id`。
3. 主播身份码（code）。
4. B站为该应用开通的具体消息类型权限，例如弹幕、SC、大航海等。
5. 向 B站确认该产品作为 Windows 本地桌面工具的 client 长连接接入形态及运行要求。

开放平台快速开始文档说明，开发者权限需单独申请；长连 client/server 模式由平台配置，消息类型需提前申请。官方 API 文档说明启动接口返回场次、WSS 信息和主播信息，项目心跳推荐每 20 秒一次，长连心跳需持续发送。请以 B站最新文档与实际审批结果为准。

## 凭证安全

- 不要把 `access_key`、`access_secret` 或主播身份码发到聊天、截图、Issue 或 Git 仓库。
- 软件只在 Windows DPAPI 加密存储中保存这组凭证。
- 不读取 B站网页登录 Cookie，不要求用户提供账号密码，不绕过平台鉴权或审核。
- 如平台对开发者认证或年龄资格设有限制，必须遵守其要求；本软件不提供绕过审核的方式。

## 当前仍未完成

- 真实开放平台凭证下的端到端连接验收。
- 经平台授权的消息类型联调及真实消息字段校正。
- 断网后的自动恢复策略与 7 天连接周期维护的实机验证。
- 网易云/QQ 音乐授权播放、自动播放和 OBS 本地浏览器源。
- 大会员状态识别（目前没有已确认可供本软件使用的授权校验接口）。

## Windows 运行

需要 Windows 10/11 和 Python 3.11+。解压后运行 `run_windows.bat`，或执行：

```powershell
py -3 -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python main.py
```

## 运行测试

```powershell
py -3 -m pip install -r requirements-dev.txt
py -3 -m pytest -q
```

## Windows 打包

```powershell
build_windows.bat
```

输出位于 `dist\BiliMusic\BiliMusic.exe`。这是未签名的开发构建。
