# V0.4.402 Release Status

## 已实现
- 网易云仍为首选音源，保留原有登录、歌单、播放资源解析与 Qt Multimedia 播放架构。
- 网易云未登录、服务启动失败或解析失败时，自动切换到 B站视频音频备用源。
- 新增 B站 WBI 签名、视频搜索、BV/av/分P信息解析、DASH 音频流解析。
- 新增仅绑定 `127.0.0.1` 的本机 Range 代理，为 B站流请求添加 Referer，兼容 Qt Multimedia。
- B站备用源播放仍经过既有播放协调器，沿用队列优先级、播放器 generation 与“实际开始播放后记录历史”的规则。

## 自动化验证
- `python -m pytest -q`：107 项通过。
- `python -m compileall -q app tests`：通过。

## 尚未实测
- B站真实 WBI 搜索与 DASH 音频流在目标网络环境中的可用性。
- Qt Multimedia 对 B站代理流的真实 Range/解码行为。
- Windows PyInstaller 构建、真实音频设备及 OBS/直播软件实机播放。

本版不声称已经完成上述联网与 Windows 实机验收。
