"""Qt Multimedia adapter with generation-safe startup and failure reporting."""
from __future__ import annotations

import re
from urllib.parse import urlsplit

from PySide6.QtCore import QObject, QTimer, QUrl
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer


class QtLocalAudioBackend(QObject):
    """Play local files and remote streams while tagging callbacks by source.

    QMediaPlayer is asynchronous. A track is not considered to be playing until
    PlayingState is observed. Generation tokens invalidate old callbacks after
    a track is skipped or replaced.
    """

    LOAD_TIMEOUT_MS = 30_000

    def __init__(self, on_ended, on_error, on_position=None, parent=None,
                 on_started=None, on_status=None):
        super().__init__(parent)
        self.player = QMediaPlayer(self)
        self.audio = QAudioOutput(self)
        self.player.setAudioOutput(self.audio)
        self._on_ended = on_ended
        self._on_error = on_error
        self._on_position = on_position or (lambda _position, _duration: None)
        self._on_started = on_started or (lambda _generation: None)
        self._on_status = on_status or (lambda _status, _generation: None)
        self._generation = 0
        self._active_source = QUrl()
        self._has_started = False
        self._terminal_event_sent = False
        self._ended_event_sent = False
        self._loading_timer = QTimer(self)
        self._loading_timer.setSingleShot(True)
        self._loading_timer.timeout.connect(self._loading_timed_out)
        self.player.mediaStatusChanged.connect(self._status_changed)
        self.player.playbackStateChanged.connect(self._playback_state_changed)
        self.player.errorOccurred.connect(self._error_changed)
        self.player.positionChanged.connect(self._position_changed)
        self.player.durationChanged.connect(
            lambda _duration: self._position_changed(self.player.position())
        )

    @property
    def generation(self) -> int:
        return self._generation

    def _begin_source(self, url: QUrl) -> int:
        self._generation += 1
        self._active_source = url
        self._has_started = False
        self._terminal_event_sent = False
        self._ended_event_sent = False
        self._loading_timer.stop()
        generation = self._generation
        self.player.setSource(url)
        self.player.play()
        self._loading_timer.start(self.LOAD_TIMEOUT_MS)
        return generation

    def play_file(self, path: str) -> int:
        url = QUrl.fromLocalFile(path)
        if not url.isValid() or url.isEmpty():
            raise ValueError("本地音频文件路径无效。")
        return self._begin_source(url)

    def play_url(self, media_url: str) -> int:
        """Stream a temporary NetEase media URL; never save the URL to SQLite."""
        url = QUrl((media_url or "").strip())
        if not url.isValid() or url.isEmpty() or url.scheme() not in {"http", "https"} or not url.host():
            raise ValueError("网易云返回的播放地址无效。")
        return self._begin_source(url)

    def pause(self) -> None:
        self.player.pause()

    def resume(self) -> None:
        self.player.play()

    def stop(self) -> None:
        # Invalidate pending callbacks before Qt emits status changes for old media.
        self._generation += 1
        self._active_source = QUrl()
        self._has_started = False
        self._terminal_event_sent = True
        self._ended_event_sent = True
        self._loading_timer.stop()
        self.player.stop()

    def set_volume(self, value: float) -> None:
        self.audio.setVolume(max(0.0, min(1.0, float(value))))

    def set_position(self, milliseconds: int) -> None:
        self.player.setPosition(max(0, int(milliseconds)))

    def _dispatch_for_generation(self, generation: int, callback, *args) -> None:
        # Defer until coordinator.start_* has stored the returned generation.
        QTimer.singleShot(
            0,
            lambda: callback(*args, generation) if generation == self._generation else None,
        )

    def _playback_state_changed(self, state) -> None:
        if state == QMediaPlayer.PlaybackState.PlayingState and not self._has_started:
            generation = self._generation
            if self._active_source.isEmpty() or self._terminal_event_sent:
                return
            self._has_started = True
            self._loading_timer.stop()
            self._dispatch_for_generation(generation, self._on_started)

    def _status_changed(self, status) -> None:
        generation = self._generation
        if self._active_source.isEmpty():
            return
        status_name = getattr(status, "name", str(status))
        self._dispatch_for_generation(generation, self._on_status, status_name)
        if status == QMediaPlayer.MediaStatus.InvalidMedia:
            self._emit_error(
                "Qt Multimedia 将媒体标记为 InvalidMedia（媒体格式、资源或解码器不可用）。",
                generation,
            )
        elif (status == QMediaPlayer.MediaStatus.EndOfMedia and self._has_started
              and not self._ended_event_sent and not self._terminal_event_sent):
            self._ended_event_sent = True
            self._loading_timer.stop()
            self._dispatch_for_generation(generation, self._on_ended)

    def _error_changed(self, error, error_string: str) -> None:
        generation = self._generation
        error_name = getattr(error, "name", str(error))
        details = (error_string or "Qt Multimedia 未提供错误说明。").strip()
        details = re.sub(r"https?://[^\s<>\"]+", self._redact_url, details)
        source_host = self._active_source.host() if not self._active_source.isEmpty() else "未知"
        self._emit_error(
            f"Qt Multimedia 错误={error_name}；{details}；媒体服务器={source_host}",
            generation,
        )

    @staticmethod
    def _redact_url(match: re.Match) -> str:
        """Keep only URL origin in logs; signed query parameters are private."""
        try:
            parsed = urlsplit(match.group(0).rstrip(".,;)]}"))
            host = parsed.hostname or "未知主机"
            if parsed.port:
                host = f"{host}:{parsed.port}"
            return f"{parsed.scheme}://{host}/[路径和参数已隐藏]"
        except ValueError:
            return "[媒体 URL 已隐藏]"

    def _emit_error(self, message: str, generation: int) -> None:
        if generation != self._generation or self._terminal_event_sent:
            return
        self._terminal_event_sent = True
        self._loading_timer.stop()
        self._dispatch_for_generation(generation, self._on_error, message)

    def _loading_timed_out(self) -> None:
        generation = self._generation
        if self._active_source.isEmpty() or self._has_started or self._terminal_event_sent:
            return
        self._emit_error(
            f"音频加载超时：{self.LOAD_TIMEOUT_MS // 1000} 秒内未进入 PlayingState。",
            generation,
        )

    def _position_changed(self, position: int) -> None:
        self._on_position(int(position), int(self.player.duration()))
