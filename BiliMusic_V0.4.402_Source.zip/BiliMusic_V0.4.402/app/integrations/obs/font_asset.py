from __future__ import annotations

from pathlib import Path
from typing import Any


SUPPORTED_FONT_EXTENSIONS = {".ttf"}
MAX_FONT_BYTES = 64 * 1024 * 1024
_FONT_SIGNATURES = {
    ".ttf": {b"\x00\x01\x00\x00", b"true", b"typ1"},
}


def inspect_font_file(path_value: str | Path | None) -> dict[str, Any] | None:
    """Return safe metadata for a user-selected local font, or None if unavailable."""
    if not path_value:
        return None
    try:
        path = Path(path_value).expanduser().resolve(strict=True)
        if not path.is_file() or path.suffix.lower() not in SUPPORTED_FONT_EXTENSIONS:
            return None
        stat = path.stat()
        if stat.st_size < 12 or stat.st_size > MAX_FONT_BYTES:
            return None
        with path.open("rb") as stream:
            signature = stream.read(4)
        if signature not in _FONT_SIGNATURES[path.suffix.lower()]:
            return None
        extension = path.suffix.lower()
        return {
            "path": path,
            "name": path.name,
            "extension": extension,
            "format": "truetype",
            "revision": f"{stat.st_mtime_ns:x}-{stat.st_size:x}",
            "size": stat.st_size,
        }
    except (OSError, RuntimeError, ValueError):
        return None
