(function () {
  'use strict';
  const root = document.getElementById('overlay');
  const currentLine = document.getElementById('current-line');
  const queueTrack = document.getElementById('queue-track');
  const queueCount = document.getElementById('queue-count');
  const connectionState = document.getElementById('connection-state');
  let socket = null;
  let reconnectTimer = null;
  let pollTimer = null;
  let reconnectDelay = 1000;
  let queueRows = [];
  let queueScrollPosition = 0;
  let queueScrollFrame = null;
  let queueLastFrameTime = 0;
  const QUEUE_ROW_HEIGHT = 38;
  // Deliberately fixed: the OBS page has no user-facing speed control.
  const QUEUE_SCROLL_PIXELS_PER_SECOND = 22;
  let lastQueueSignature = '';
  let lastCurrentSignature = '';

  function text(value, fallback) {
    if (value === null || value === undefined || String(value).trim() === '') return fallback || '';
    return String(value);
  }
  function songLine(song) {
    return [text(song.title, '未知歌曲'), text(song.artist, ''), song.requesterName ? '@' + song.requesterName : ''].filter(Boolean).join('　');
  }
  function makeMarquee(line, className) {
    const holder = document.createElement('div');
    holder.className = 'marquee';
    const first = document.createElement('span');
    first.className = 'marquee-text';
    first.textContent = line;
    const copy = document.createElement('span');
    copy.className = 'marquee-copy';
    copy.textContent = line;
    holder.append(first, copy);
    if (className) holder.dataset.kind = className;
    requestAnimationFrame(() => {
      const overflow = Math.max(0, first.scrollWidth - holder.parentElement.clientWidth);
      const travel = first.scrollWidth;
      copy.style.display = overflow > 4 ? 'inline-block' : 'none';
      if (overflow > 4) {
        holder.classList.add('is-scrolling');
        holder.style.setProperty('--marquee-distance', travel + 'px');
        holder.style.setProperty('--marquee-duration', Math.max(7, travel / 38) + 's');
      } else {
        holder.classList.remove('is-scrolling');
      }
    });
    return holder;
  }
  function renderCurrent(song) {
    const signature = song ? JSON.stringify([song.id, song.title, song.artist, song.requesterName]) : 'idle';
    if (signature === lastCurrentSignature) return;
    lastCurrentSignature = signature;
    currentLine.replaceChildren();
    const line = song ? songLine(song) : '等待播放';
    currentLine.append(makeMarquee(line, 'current'));
  }
  function stopQueueAnimation() {
    if (queueScrollFrame !== null) cancelAnimationFrame(queueScrollFrame);
    queueScrollFrame = null;
    queueLastFrameTime = 0;
  }
  function animateQueue(timestamp) {
    if (queueRows.length <= 3) {
      stopQueueAnimation();
      return;
    }
    if (!queueLastFrameTime) queueLastFrameTime = timestamp;
    const elapsed = Math.min(64, Math.max(0, timestamp - queueLastFrameTime));
    queueLastFrameTime = timestamp;
    const cycleHeight = queueRows.length * QUEUE_ROW_HEIGHT;
    queueScrollPosition = (queueScrollPosition + elapsed * QUEUE_SCROLL_PIXELS_PER_SECOND / 1000) % cycleHeight;
    queueTrack.style.transform = 'translate3d(0,' + (-queueScrollPosition).toFixed(3) + 'px,0)';
    queueScrollFrame = requestAnimationFrame(animateQueue);
  }
  function renderQueue(songs) {
    const signature = JSON.stringify(songs.map(song => [song.id, song.title, song.artist, song.requesterName]));
    queueCount.textContent = songs.length + ' 首待播';
    if (signature === lastQueueSignature) return;

    // Preserve the song currently crossing the top edge when the queue changes.
    const previousRows = queueRows;
    let preservedTopId = null;
    let preservedFraction = 0;
    if (previousRows.length > 3) {
      const oldCycleHeight = previousRows.length * QUEUE_ROW_HEIGHT;
      const normalized = oldCycleHeight ? queueScrollPosition % oldCycleHeight : 0;
      const oldTopIndex = Math.floor(normalized / QUEUE_ROW_HEIGHT) % previousRows.length;
      preservedTopId = previousRows[oldTopIndex] && previousRows[oldTopIndex].id;
      preservedFraction = (normalized % QUEUE_ROW_HEIGHT) / QUEUE_ROW_HEIGHT;
    }

    lastQueueSignature = signature;
    queueRows = songs.slice();
    stopQueueAnimation();
    queueScrollPosition = 0;
    queueTrack.style.transform = 'translate3d(0,0,0)';
    queueTrack.replaceChildren();
    if (!songs.length) {
      const empty = document.createElement('div');
      empty.className = 'queue-row empty-row';
      empty.textContent = '暂无待播歌曲';
      queueTrack.append(empty);
      return;
    }

    // A second full copy makes the loop visually seamless at the cycle boundary.
    const visibleItems = songs.length > 3 ? songs.concat(songs) : songs;
    visibleItems.forEach((song, index) => {
      const row = document.createElement('div');
      row.className = 'queue-row';
      const number = document.createElement('span');
      number.className = 'queue-index';
      number.textContent = String((index % songs.length) + 1).padStart(2, '0');
      const copy = document.createElement('div');
      copy.className = 'queue-song';
      copy.append(makeMarquee(songLine(song), 'queue'));
      row.append(number, copy);
      queueTrack.append(row);
    });

    if (songs.length > 3 && preservedTopId !== null && preservedTopId !== undefined) {
      const newIndex = songs.findIndex(song => String(song.id) === String(preservedTopId));
      if (newIndex >= 0) queueScrollPosition = newIndex * QUEUE_ROW_HEIGHT + preservedFraction * QUEUE_ROW_HEIGHT;
    }
    if (songs.length > 3) {
      const cycleHeight = songs.length * QUEUE_ROW_HEIGHT;
      queueScrollPosition %= cycleHeight;
      queueTrack.style.transform = 'translate3d(0,' + (-queueScrollPosition).toFixed(3) + 'px,0)';
      queueScrollFrame = requestAnimationFrame(animateQueue);
    }
  }
  function applyStyle(style) {
    if (!style || typeof style !== 'object') return;
    root.dataset.background = style.background === 'translucent' ? 'translucent' : 'transparent';
    root.dataset.align = ['left', 'center', 'right'].includes(style.alignment) ? style.alignment : 'left';
    const safeColor = (value, fallback) => /^#[0-9a-fA-F]{6}$/.test(String(value || '')) ? value : fallback;
    root.style.setProperty('--current-color', safeColor(style.currentColor, '#f7faff'));
    root.style.setProperty('--queue-color', safeColor(style.queueColor, '#e7efff'));
    root.style.setProperty('--font-size', Math.max(16, Math.min(56, Number(style.fontSize) || 28)) + 'px');
    const opacity = Math.max(.1, Math.min(.95, Number(style.opacity) || .72));
    root.style.setProperty('--panel-bg', 'rgba(14,25,43,' + opacity + ')');
    applyFont(style);
  }
  function applyFont(style) {
    const enabled = style.fontEnabled === true;
    const existingRule = document.getElementById('user-font-rule');
    if (!enabled) {
      if (existingRule) existingRule.remove();
      const fallback = 'system-ui, "Microsoft YaHei UI", "Microsoft YaHei", sans-serif';
      root.style.setProperty('--font-family', fallback);
      // font-family must be applied to the overlay element itself. Setting only a
      // custom property on #overlay cannot affect the body's already-computed font.
      root.style.fontFamily = fallback;
      return;
    }
    const formatHint = style.fontFormat === 'collection' ? '' : ' format(\"' + (style.fontFormat === 'opentype' ? 'opentype' : 'truetype') + '\")';
    const revision = encodeURIComponent(String(style.fontRevision || 'current'));
    let rule = existingRule;
    if (!rule) {
      rule = document.createElement('style');
      rule.id = 'user-font-rule';
      document.head.append(rule);
    }
    rule.textContent = '@font-face{font-family:"BiliMusicUserFont";src:url("/overlay/custom-font?v=' + revision + '")' + formatHint + ';font-display:swap;}';
    const selectedFamily = '"BiliMusicUserFont", system-ui, "Microsoft YaHei UI", "Microsoft YaHei", sans-serif';
    root.style.setProperty('--font-family', selectedFamily);
    // Apply directly to the overlay so all visible text inherits the selected face.
    root.style.fontFamily = selectedFamily;
    if (document.fonts && typeof document.fonts.load === 'function') {
      document.fonts.load('24px BiliMusicUserFont').catch(() => {
        // Keep the system fallback if Chromium cannot decode the selected font.
      });
    }
  }
  function renderState(state) {
    if (!state || typeof state !== 'object') return;
    renderCurrent(state.current || null);
    renderQueue(Array.isArray(state.queue) ? state.queue : []);
    applyStyle(state.display || {});
    root.dataset.offline = 'false';
    connectionState.textContent = 'BiliMusic 已连接';
  }
  function setOffline() {
    root.dataset.offline = 'true';
    connectionState.textContent = '等待连接 BiliMusic 本地服务';
  }
  function poll() {
    fetch('/api/v1/state', { cache: 'no-store' })
      .then(response => { if (!response.ok) throw new Error('HTTP ' + response.status); return response.json(); })
      .then(renderState).catch(setOffline);
  }
  function startPolling() {
    if (pollTimer) return;
    poll();
    pollTimer = window.setInterval(poll, 1000);
  }
  function reconnect() {
    if (reconnectTimer) return;
    reconnectTimer = window.setTimeout(() => { reconnectTimer = null; connect(); }, reconnectDelay);
    reconnectDelay = Math.min(15000, reconnectDelay * 2);
  }
  function connect() {
    if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) return;
    try { socket = new WebSocket('ws://' + window.location.host + '/ws'); }
    catch (_error) { startPolling(); reconnect(); return; }
    socket.addEventListener('open', () => {
      reconnectDelay = 1000;
      if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
      poll();
    });
    socket.addEventListener('message', event => {
      try {
        const message = JSON.parse(event.data);
        renderState(message && message.type === 'state' ? message.data : message);
      } catch (_error) { /* Ignore malformed messages. */ }
    });
    socket.addEventListener('close', () => { socket = null; startPolling(); reconnect(); });
    socket.addEventListener('error', () => { try { socket.close(); } catch (_error) {} });
  }
  window.addEventListener('resize', () => { lastQueueSignature = ''; poll(); });
  window.addEventListener('pagehide', () => {
    if (pollTimer) clearInterval(pollTimer);
    if (reconnectTimer) clearTimeout(reconnectTimer);
    stopQueueAnimation();
    if (socket) socket.close();
  });
  connect();
  // HTTP is started immediately too, ensuring that a blocked WebSocket never leaves a blank source.
  poll();
}());
