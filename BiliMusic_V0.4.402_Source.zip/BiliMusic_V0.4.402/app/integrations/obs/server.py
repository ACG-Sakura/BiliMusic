from __future__ import annotations

import json
import logging
import mimetypes
import threading
from pathlib import Path
from typing import Callable, Any
from urllib.parse import urlsplit

from websockets.http11 import Response
from websockets.datastructures import Headers
from websockets.sync.server import ServerConnection, serve

from .font_asset import inspect_font_file


WEB_ROOT = Path(__file__).resolve().parent / "web"
LOGGER = logging.getLogger(__name__)


def _http_response(status: int, reason: str, body: bytes = b"", content_type: str = "text/plain; charset=utf-8") -> Response:
    headers = Headers([
        ("Content-Type", content_type),
        ("Content-Length", str(len(body))),
        ("Cache-Control", "no-store"),
        ("X-Content-Type-Options", "nosniff"),
    ])
    return Response(status, reason, headers, body)


class OBSOverlayServer:
    """Loopback-only HTTP + WebSocket server for the OBS read-only queue overlay."""

    def __init__(
        self,
        state_provider: Callable[[], dict[str, Any]],
        preferred_port: int = 5556,
        font_path_provider: Callable[[], str | Path | None] | None = None,
    ):
        self._state_provider = state_provider
        self._font_path_provider = font_path_provider or (lambda: None)
        self._preferred_port = max(0, min(65535, int(preferred_port)))
        self._server = None
        self._thread: threading.Thread | None = None
        self._lock = threading.RLock()
        self._running = False
        self._port: int | None = None
        self._error = ""
        self._stop_event = threading.Event()

    def status(self) -> dict[str, Any]:
        with self._lock:
            return {"running": self._running, "port": self._port, "error": self._error}

    def start(self) -> dict[str, Any]:
        with self._lock:
            if self._running:
                return self.status()
            stop_event = threading.Event()
            self._stop_event = stop_event
            last_error = ""
            candidates = ([0] if self._preferred_port == 0 else [self._preferred_port] +
                          list(range(self._preferred_port + 1, min(65536, self._preferred_port + 21))))
            for candidate in candidates:
                port_holder = {"port": candidate}
                try:
                    server = serve(
                        lambda websocket, event=stop_event: self._handle_websocket(websocket, event),
                        host="127.0.0.1",
                        port=candidate,
                        process_request=lambda connection, request, holder=port_holder: self._process_request(
                            connection, request, int(holder["port"])
                        ),
                        compression=None,
                        ping_interval=20,
                        ping_timeout=20,
                        max_size=4096,
                        open_timeout=5,
                    )
                except OSError as exc:
                    last_error = f"端口 {candidate} 不可用：{exc}"
                    continue
                actual_port = int(server.socket.getsockname()[1])
                port_holder["port"] = actual_port
                self._server = server
                self._port = actual_port
                self._running = True
                self._error = ""
                self._thread = threading.Thread(
                    target=self._serve, args=(server,), name="BiliMusic-OBS-HTTP", daemon=True
                )
                self._thread.start()
                return self.status()
            self._server = None
            self._port = None
            self._running = False
            self._error = last_error or "没有可用的本机端口。"
            return self.status()

    def _serve(self, server) -> None:
        try:
            with server:
                server.serve_forever()
        except Exception as exc:  # Keep a server-thread failure visible to the UI.
            LOGGER.exception("OBS overlay server stopped unexpectedly")
            with self._lock:
                self._error = str(exc)
        finally:
            with self._lock:
                self._running = False
                self._server = None
                self._thread = None

    def stop(self) -> None:
        with self._lock:
            server = self._server
            thread = self._thread
            self._stop_event.set()
        if server is not None:
            try:
                server.shutdown()
            except Exception:
                pass
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=3)
        with self._lock:
            self._server = None
            self._thread = None
            self._running = False
            self._port = None

    def set_preferred_port(self, port: int) -> None:
        with self._lock:
            self._preferred_port = max(0, min(65535, int(port)))

    @staticmethod
    def _is_local_host(host: str, port: int) -> bool:
        return host.strip().lower() in {f"127.0.0.1:{port}", f"localhost:{port}"}

    def _process_request(self, _connection: ServerConnection, request, port: int) -> Response | None:
        host = request.headers.get("Host", "")
        if not self._is_local_host(host, port):
            return _http_response(403, "Forbidden", b"Loopback host required")
        origin = request.headers.get("Origin")
        allowed_origins = {None, f"http://127.0.0.1:{port}", f"http://localhost:{port}"}
        if origin not in allowed_origins:
            return _http_response(403, "Forbidden", b"Invalid origin")

        path = urlsplit(request.path).path
        if path == "/ws":
            return None  # Let websockets perform the upgrade.

        if path in {"/", "/overlay", "/overlay/"}:
            path = "/index.html"
        elif path.startswith("/overlay/"):
            path = path[len("/overlay"):]

        if path == "/custom-font":
            try:
                font_info = inspect_font_file(self._font_path_provider())
                if font_info is None:
                    return _http_response(404, "Not Found", b"No valid custom font selected")
                font_path = font_info["path"]
                font_bytes = font_path.read_bytes()
                content_type = "font/ttf"
                return _http_response(200, "OK", font_bytes, content_type)
            except OSError:
                return _http_response(404, "Not Found", b"Custom font unavailable")

        if path == "/health":
            payload = {"ok": True, "schemaVersion": 1, "service": "BiliMusic OBS Queue Overlay"}
            return _http_response(200, "OK", json.dumps(payload).encode("utf-8"), "application/json; charset=utf-8")
        if path in {"/api/v1/state", "/api/v1/queue"}:
            try:
                state = self._state_provider()
                if path.endswith("/queue"):
                    state = {key: state[key] for key in ("schemaVersion", "timestamp", "queue", "queueLength") if key in state}
                body = json.dumps(state, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
                return _http_response(200, "OK", body, "application/json; charset=utf-8")
            except Exception:
                LOGGER.exception("Unable to build OBS overlay state")
                return _http_response(500, "Internal Server Error", b"State unavailable")

        # Static paths are an explicit allow-list; arbitrary filesystem paths aren't served.
        assets = {
            "/index.html": WEB_ROOT / "index.html",
            "/styles.css": WEB_ROOT / "styles.css",
            "/app.js": WEB_ROOT / "app.js",
        }
        asset = assets.get(path)
        if asset is None or not asset.is_file():
            return _http_response(404, "Not Found", b"Not found")
        content_type = mimetypes.guess_type(asset.name)[0] or "application/octet-stream"
        if content_type.startswith("text/") or content_type in {"application/javascript", "application/json"}:
            content_type += "; charset=utf-8"
        return _http_response(200, "OK", asset.read_bytes(), content_type)

    def _handle_websocket(self, websocket: ServerConnection, stop_event: threading.Event) -> None:
        last_fingerprint = ""
        try:
            while not stop_event.is_set():
                state = self._state_provider()
                fingerprint_state = dict(state)
                fingerprint_state["timestamp"] = ""
                fingerprint = json.dumps(fingerprint_state, ensure_ascii=False, sort_keys=True,
                                         separators=(",", ":"))
                if fingerprint != last_fingerprint:
                    payload = json.dumps({"type": "state", "data": state}, ensure_ascii=False,
                                         separators=(",", ":"))
                    websocket.send(payload)
                    last_fingerprint = fingerprint
                # Read-only socket: any message from a browser closes the connection.
                try:
                    incoming = websocket.recv(timeout=0.35)
                    if incoming is not None:
                        websocket.close(code=1008, reason="read-only")
                        return
                except TimeoutError:
                    continue
        except Exception:
            # A browser closing/reloading its source is normal.
            return
