from __future__ import annotations

import hashlib
import urllib.parse

from app.integrations.music.bilibili_video import (
    BilibiliVideoClient, MIXIN_TAB, _mixin_key,
)


def test_parse_bilibili_video_refs_and_page_number():
    assert BilibiliVideoClient._parse_ref("BV1xx411c7mD") == ("BV1xx411c7mD", 1)
    assert BilibiliVideoClient._parse_ref("https://www.bilibili.com/video/BV1xx411c7mD?p=3") == ("BV1xx411c7mD", 3)
    assert BilibiliVideoClient._parse_ref("av170001 p2") == ("av170001", 2)


def test_wbi_mixin_key_uses_bilibili_permutation():
    raw = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_"
    expected = "".join(raw[i] for i in MIXIN_TAB)[:32]
    assert _mixin_key("https://i.test/" + raw[:32] + ".png", "https://i.test/" + raw[32:] + ".png") == expected


def test_wbi_url_uses_percent_encoded_spaces_and_sorted_signature(monkeypatch):
    client = BilibiliVideoClient()
    client._key = "test-mixin-key"
    client._key_at = 10**20
    monkeypatch.setattr("app.integrations.music.bilibili_video.time.time", lambda: 1700000000)
    url = client._wbi_url("https://api.bilibili.com/test", {"keyword": "hello world", "page": 1})
    query = urllib.parse.urlsplit(url).query
    assert "keyword=hello%20world" in query
    parsed = dict(urllib.parse.parse_qsl(query))
    signed = "&".join(
        f"{urllib.parse.quote(k)}={urllib.parse.quote(v)}"
        for k, v in sorted({"keyword": "hello world", "page": "1", "wts": "1700000000"}.items())
    )
    assert parsed["w_rid"] == hashlib.md5((signed + "test-mixin-key").encode()).hexdigest()


def test_local_proxy_forwards_range_and_injects_bilibili_referer():
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    from threading import Thread
    from urllib.request import Request, urlopen
    from app.integrations.music.bilibili_video import local_bilibili_stream

    seen = {}

    class Upstream(BaseHTTPRequestHandler):
        def log_message(self, *_args):
            pass
        def do_GET(self):
            seen["referer"] = self.headers.get("Referer")
            seen["range"] = self.headers.get("Range")
            body = b"0123456789"
            if self.headers.get("Range") == "bytes=2-5":
                body = body[2:6]
                self.send_response(206)
                self.send_header("Content-Range", "bytes 2-5/10")
            else:
                self.send_response(200)
            self.send_header("Content-Type", "audio/mp4")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Accept-Ranges", "bytes")
            self.end_headers()
            self.wfile.write(body)

    upstream = ThreadingHTTPServer(("127.0.0.1", 0), Upstream)
    thread = Thread(target=upstream.serve_forever, daemon=True)
    thread.start()
    try:
        local = local_bilibili_stream(f"http://127.0.0.1:{upstream.server_address[1]}/audio")
        req = Request(local, headers={"Range": "bytes=2-5"})
        with urlopen(req, timeout=5) as response:
            assert response.status == 206
            assert response.read() == b"2345"
        assert seen["referer"] == "https://www.bilibili.com/"
        assert seen["range"] == "bytes=2-5"
    finally:
        upstream.shutdown()
        upstream.server_close()
