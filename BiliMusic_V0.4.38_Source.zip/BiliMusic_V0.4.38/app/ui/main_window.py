from __future__ import annotations

from PySide6.QtCore import QByteArray, QMimeData, Qt, Signal, QUrl, QTimer, QThread
from PySide6.QtGui import QColor, QDrag, QGuiApplication, QIntValidator, QDesktopServices, QImage, QPixmap
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QLabel, QPushButton,
    QListWidget, QListWidgetItem, QStackedWidget, QFrame, QTableWidget, QTableWidgetItem,
    QHeaderView, QLineEdit, QMessageBox, QSpinBox, QFormLayout, QGridLayout,
    QAbstractItemView, QTextEdit, QComboBox, QColorDialog, QScrollArea,
    QSizePolicy, QSpacerItem, QInputDialog, QFileDialog, QSlider, QDialog,
)

from app.core.queue_service import QueueService
from app.core.settings import SettingsStore
from app.storage.database import Database
from app.core.playlists import PlaylistService
from app.core.cache_manager import CacheManager
from app.core.playback import PlaybackCoordinator
from app.integrations.music.qt_player import QtLocalAudioBackend
from app.integrations.music.netease import NeteaseApiClient, NeteaseError, NeteasePlaylist
from app.integrations.music.netease_service import NeteaseServiceManager, NeteaseServiceError
from app.integrations.music.secret_store import WindowsMusicSecretStore, SecretStoreError
from app.integrations.bilibili.contracts import LiveMessage, BilibiliClientPlaceholder
from app.integrations.bilibili.connection import (
    ConnectionManager, ConnectionState, SimulatedBilibiliClient,
)
from app.integrations.bilibili.rules import SongRequestHandler
from app.integrations.bilibili.pipeline import BilibiliEventPipeline
from app.integrations.bilibili.open_live_api import OpenLiveCredentials
from app.integrations.bilibili.open_live_client import OfficialBilibiliOpenLiveClient
from app.integrations.bilibili.credential_store import WindowsCredentialStore, CredentialStoreError


BLUE_LIGHT = {
    "bg": "#F5F8FD", "surface": "#FFFFFF", "surface2": "#EEF4FC",
    "surface3": "#E5EFFB", "text": "#172B4D", "muted": "#60738E",
    "outline": "#D5E0EF", "selected": "#DCEAFF", "field": "#F2F6FC",
    "accent": "#3568D4", "accent_hover": "#2858BD", "onaccent": "#FFFFFF",
    "tablealt": "#F7FAFE", "success": "#18794E", "warning": "#9A6700",
}
BLUE_DARK = {
    "bg": "#101923", "surface": "#172332", "surface2": "#1D2B3D",
    "surface3": "#26384D", "text": "#E4EDF8", "muted": "#A9B9CC",
    "outline": "#3A4D63", "selected": "#29466B", "field": "#1D2B3D",
    "accent": "#8AB4F8", "accent_hover": "#A6C7FF", "onaccent": "#10243E",
    "tablealt": "#1A2939", "success": "#8BD5B0", "warning": "#F3C969",
}


def build_md3_style(mode: str = "light", accent: str | None = None) -> str:
    """Token-based Material 3-inspired blue/white theme for the Qt widget layer."""
    c = dict(BLUE_DARK if mode == "dark" else BLUE_LIGHT)
    if accent:
        c["accent"] = accent
    return f"""
    QWidget {{
        background: {c['bg']}; color: {c['text']};
        font-family: "Microsoft YaHei UI", "Microsoft YaHei", sans-serif;
        font-size: 13px;
    }}
    QLabel {{ background: transparent; border: none; }}
    QFrame#Sidebar {{ background: {c['surface']}; border: none; border-right: 1px solid {c['outline']}; }}
    QLabel#Brand {{ font-size: 24px; font-weight: 800; color: {c['accent']}; padding: 12px 8px 22px 8px; }}
    QLabel#PageTitle {{ font-size: 26px; font-weight: 750; color: {c['text']}; }}
    QLabel#PageSubtitle {{ color: {c['muted']}; font-size: 13px; }}
    QLabel#Muted {{ color: {c['muted']}; }}
    QLabel#Value {{ font-size: 25px; font-weight: 750; color: {c['text']}; }}
    QLabel#SectionTitle {{ font-size: 16px; font-weight: 700; }}
    QLabel#Eyebrow {{ color: {c['muted']}; font-size: 11px; font-weight: 650; }}
    QFrame#Card {{ background: {c['surface']}; border: 1px solid {c['outline']}; border-radius: 18px; }}
    QFrame#TintCard {{ background: {c['surface2']}; border: 1px solid transparent; border-radius: 18px; }}
    QFrame#MiniCard {{ background: {c['surface2']}; border: none; border-radius: 14px; }}
    QPushButton {{
        background: {c['surface3']}; color: {c['text']}; border: 1px solid transparent;
        border-radius: 12px; padding: 9px 16px; min-height: 22px; font-weight: 600;
    }}
    QPushButton:hover {{ background: {c['selected']}; }}
    QPushButton:pressed {{ padding-top: 10px; padding-bottom: 8px; }}
    QPushButton:disabled {{ color: {c['muted']}; background: {c['surface2']}; }}
    QPushButton#Primary {{ background: {c['accent']}; color: {c['onaccent']}; border: none; }}
    QPushButton#Primary:hover {{ background: {c['accent_hover']}; }}
    QPushButton#Tonal {{ background: {c['selected']}; color: {c['text']}; border: none; }}
    QPushButton#TextButton {{ background: transparent; border: none; color: {c['accent']}; }}
    QListWidget {{ background: transparent; border: none; outline: none; padding: 5px 0; }}
    QListWidget::item {{ padding: 12px 14px; border-radius: 13px; margin: 3px 0; color: {c['muted']}; }}
    QListWidget::item:hover {{ background: {c['surface2']}; color: {c['text']}; }}
    QListWidget::item:selected {{ background: {c['selected']}; color: {c['text']}; font-weight: 700; }}
    QTableWidget {{
        background: {c['surface']}; alternate-background-color: {c['tablealt']};
        gridline-color: transparent; border: 1px solid {c['outline']}; border-radius: 14px;
        selection-background-color: {c['selected']}; selection-color: {c['text']};
        outline: none; padding: 4px;
    }}
    QTableWidget::item {{ padding: 9px 8px; border-bottom: 1px solid {c['outline']}; }}
    QHeaderView::section {{ background: {c['surface2']}; color: {c['muted']}; padding: 12px 8px; border: none; font-weight: 700; }}
    QLineEdit, QSpinBox, QComboBox {{
        background: {c['field']}; color: {c['text']}; border: 1px solid {c['outline']};
        border-radius: 12px; padding: 10px 12px; min-height: 22px; selection-background-color: {c['accent']};
    }}
    QLineEdit:focus, QSpinBox:focus, QComboBox:focus {{ border: 2px solid {c['accent']}; padding: 9px 11px; }}
    QComboBox {{ padding-right: 30px; }}
    QComboBox::drop-down {{ subcontrol-origin: padding; subcontrol-position: center right; width: 28px; border: none; }}
    QComboBox::down-arrow {{ width: 8px; height: 8px; border: none; border-right: 2px solid {c['muted']}; border-bottom: 2px solid {c['muted']}; margin-right: 10px; }}
    QComboBox QAbstractItemView {{ background: {c['surface']}; selection-background-color: {c['selected']}; border: 1px solid {c['outline']}; border-radius: 10px; padding: 4px; }}
    QTextEdit {{ background: {c['surface']}; border: 1px solid {c['outline']}; border-radius: 14px; padding: 12px; }}
    QScrollArea {{ background: transparent; border: none; }}
    QScrollBar:vertical {{ background: transparent; width: 10px; margin: 3px; }}
    QScrollBar::handle:vertical {{ background: {c['outline']}; border-radius: 5px; min-height: 30px; }}
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
    """


class ReorderableQueueTable(QTableWidget):
    """Queue table with a custom drag operation that never lets Qt remove the source row."""

    SONG_MIME_TYPE = "application/x-bilimusic-queue-song-id"

    def __init__(self, rows: int, columns: int, on_reordered, parent=None):
        super().__init__(rows, columns, parent)
        self.on_reordered = on_reordered
        self._dragged_song_id: int | None = None
        self._pending_target_row: int | None = None
        self.setDragEnabled(True)
        self.setAcceptDrops(True)
        self.setDropIndicatorShown(True)
        self.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.setDragDropOverwriteMode(False)

    def startDrag(self, supported_actions):
        """Run our own QDrag instead of QAbstractItemView.startDrag.

        Qt's base implementation performs source-side row cleanup after an accepted
        MoveAction. That cleanup is intended for model-level moves, but this table
        persists the move in SQLite and repopulates its rows itself. Calling the base
        implementation therefore removes the just-refreshed source row a second time.
        Our custom drag transports only the stable song ID and leaves the table model
        untouched; persistence and refresh happen after the drag loop returns.
        """
        row = self.currentRow()
        id_item = self.item(row, 0) if row >= 0 else None
        if id_item is None:
            return

        song_id = id_item.data(Qt.ItemDataRole.UserRole)
        if song_id is None:
            try:
                song_id = int(id_item.text())
            except (TypeError, ValueError):
                return
        self._dragged_song_id = int(song_id)

        drag = QDrag(self)
        mime_data = QMimeData()
        mime_data.setData(self.SONG_MIME_TYPE, QByteArray(str(self._dragged_song_id).encode("ascii")))
        drag.setMimeData(mime_data)
        try:
            # MoveAction communicates reorder semantics. Because we do not call the
            # base view's startDrag(), Qt will not delete the source row afterwards.
            result = drag.exec(Qt.DropAction.MoveAction, Qt.DropAction.MoveAction)
            target_row = self._pending_target_row
            # Apply the database reorder and rebuild the visible table only after
            # QDrag.exec() has returned and Qt has finished the drop-event dispatch.
            if result == Qt.DropAction.MoveAction and target_row is not None:
                self.on_reordered(self._dragged_song_id, target_row)
        finally:
            self._dragged_song_id = None
            self._pending_target_row = None

    def dragEnterEvent(self, event):
        if event.source() == self and event.mimeData().hasFormat(self.SONG_MIME_TYPE):
            event.setDropAction(Qt.DropAction.MoveAction)
            event.accept()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if event.source() == self and event.mimeData().hasFormat(self.SONG_MIME_TYPE):
            event.setDropAction(Qt.DropAction.MoveAction)
            event.accept()
        else:
            event.ignore()

    def dropEvent(self, event):
        if event.source() != self or not event.mimeData().hasFormat(self.SONG_MIME_TYPE):
            event.ignore()
            return
        try:
            song_id = int(bytes(event.mimeData().data(self.SONG_MIME_TYPE)).decode("ascii"))
        except (TypeError, ValueError, UnicodeDecodeError):
            event.ignore()
            return

        target_row = self.indexAt(event.position().toPoint()).row()
        if target_row < 0:
            target_row = self.rowCount() - 1
        if target_row < 0:
            event.ignore()
            return

        if self._dragged_song_id is None or song_id != self._dragged_song_id:
            event.ignore()
            return
        # Defer persistence/UI refresh until startDrag() resumes after QDrag.exec().
        self._pending_target_row = target_row
        event.setDropAction(Qt.DropAction.MoveAction)
        event.accept()


class NeteaseLoginWorker(QThread):
    qr_ready = Signal(bytes)
    status_changed = Signal(str)
    authenticated = Signal(str)
    failed = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._cancelled = False

    def cancel(self):
        self._cancelled = True

    def run(self):
        try:
            client = NeteaseApiClient()
            qr = client.qr_login_create()
            self.qr_ready.emit(NeteaseApiClient.decode_qr_image(qr.image_data_uri))
            self.status_changed.emit("请使用网易云音乐 App 扫描二维码")
            for _ in range(120):
                if self._cancelled:
                    return
                result = client.qr_login_check(qr.key)
                if result.code == 803:
                    if not result.cookie:
                        raise NeteaseError("扫码已确认，但服务未返回登录凭证。请重试。")
                    self.authenticated.emit(result.cookie)
                    return
                if result.code == 802:
                    self.status_changed.emit("已扫码，请在手机上确认登录")
                elif result.code == 800:
                    raise NeteaseError("二维码已过期，请重新生成。")
                else:
                    self.status_changed.emit("等待扫码…")
                self.msleep(2000)
            raise NeteaseError("等待扫码超时，请重新尝试。")
        except Exception as exc:
            self.failed.emit(str(exc))


class NeteaseAccountStatusWorker(QThread):
    verified = Signal(str, int)
    failed = Signal(str)

    def __init__(self, cookie: str, parent=None):
        super().__init__(parent)
        self.cookie = cookie

    def run(self):
        try:
            profile = NeteaseApiClient(cookie=self.cookie).login_status()
            nickname = str(profile.get("nickname") or "网易云用户")
            user_id = int(profile.get("user_id") or 0)
            if user_id <= 0:
                raise NeteaseError("网易云没有返回有效的账号 ID，无法确认登录状态。")
            self.verified.emit(nickname, user_id)
        except Exception as exc:
            self.failed.emit(str(exc))


class NeteasePlaylistSyncWorker(QThread):
    succeeded = Signal(object)
    failed = Signal(str)

    def __init__(self, cookie: str, source_ref: str, parent=None):
        super().__init__(parent)
        self.cookie = cookie
        self.source_ref = source_ref

    def run(self):
        try:
            remote = NeteaseApiClient(cookie=self.cookie).fetch_playlist(self.source_ref)
            self.succeeded.emit(remote)
        except Exception as exc:
            self.failed.emit(str(exc))


class NeteaseResolveWorker(QThread):
    resolved = Signal(str, int, str, str, str, str)
    failed = Signal(str, int, str)

    def __init__(self, cookie: str, mode: str, reference_id: int, title: str,
                 artist: str = "", song_id: str = "", level: str = "exhigh", parent=None):
        super().__init__(parent)
        self.cookie = cookie
        self.mode = mode
        self.reference_id = reference_id
        self.title = title
        self.artist = artist
        self.song_id = song_id
        self.level = level

    def run(self):
        try:
            client = NeteaseApiClient(cookie=self.cookie)
            if self.song_id:
                from app.integrations.music.netease import NeteaseTrack
                track = NeteaseTrack(self.song_id, self.title, self.artist)
            else:
                track = client.resolve_request(self.title, self.artist, self.level)
            url = client.song_url(track.external_id, self.level)
            self.resolved.emit(self.mode, self.reference_id, url, track.title, track.artist, track.external_id)
        except Exception as exc:
            self.failed.emit(self.mode, self.reference_id, str(exc))


class NeteaseLyricsWorker(QThread):
    loaded = Signal(str, object)
    failed = Signal(str, str)

    def __init__(self, cookie: str, song_id: str, parent=None):
        super().__init__(parent)
        self.cookie = cookie
        self.song_id = str(song_id)

    def run(self):
        try:
            rows = NeteaseApiClient(cookie=self.cookie).lyrics(self.song_id)
            self.loaded.emit(self.song_id, rows)
        except Exception as exc:
            self.failed.emit(self.song_id, str(exc))


class MainWindow(QMainWindow):
    open_live_state_signal = Signal(str, str)
    open_live_message_signal = Signal(object)

    def __init__(self, database: Database, settings: SettingsStore, queue: QueueService):
        super().__init__()
        self.database = database
        self.settings = settings
        self.queue = queue
        self.playlists = PlaylistService(database)
        self.cache_manager = CacheManager(database)
        self.cache_manager.cleanup_if_due()
        self.music_secret_store = WindowsMusicSecretStore()
        self.music_secret_store.remove_legacy_qq_key()
        self.netease_service = NeteaseServiceManager()
        self._playlist_sync_worker = None
        self._netease_login_worker = None
        self._netease_login_dialog = None
        self._netease_status_worker = None
        self._netease_verified_profile: tuple[str, int] | None = None
        self._netease_status_error = ""
        self._netease_status_checking = False
        self._show_netease_status_result = False
        self._remote_workers = {}
        self._lyrics_worker = None
        self._lyrics_workers = {}
        self._lyric_song_id = ""
        self._lyric_rows = []
        self._lyric_active_index = -1
        self.player_backend = QtLocalAudioBackend(
            self._on_media_ended, self._on_media_error, self._on_media_position, self
        )
        self.playback = PlaybackCoordinator(
            queue, self.playlists, self.player_backend, self._on_player_state,
            self._queue_remote_request, self._autoplay_remote_track,
        )
        self.playback_timer = QTimer(self)
        self.playback_timer.setInterval(500)
        self.playback_timer.timeout.connect(self.playback.poll)
        self.playback_timer.start()
        self.simulated_client = SimulatedBilibiliClient()
        self.connection_manager = ConnectionManager(
            BilibiliClientPlaceholder(), lambda message: None, self._on_real_connection_state
        )
        self.simulated_manager = ConnectionManager(
            self.simulated_client, self._on_simulated_message, self._on_simulated_state
        )
        self.request_pipeline = BilibiliEventPipeline(SongRequestHandler(queue, settings))
        self.simulation_room_id = 0
        self.open_live_credential_store = WindowsCredentialStore()
        self.open_live_client = OfficialBilibiliOpenLiveClient(
            lambda message: self.open_live_message_signal.emit(message),
            lambda state, detail: self.open_live_state_signal.emit(state, detail),
        )
        self.open_live_state_signal.connect(self._on_open_live_state)
        self.open_live_message_signal.connect(self._on_open_live_message)
        self.setWindowTitle("BiliMusic V0.4.38 — 网易云单平台本地点歌姬")
        self.resize(1280, 820)
        self.setMinimumSize(1050, 700)
        self.apply_theme()
        self._build_layout()
        self.refresh_queue()
        self.refresh_dashboard()

    def apply_theme(self):
        # V0.1.4 keeps the product's blue-white light appearance fixed.
        self.setStyleSheet(build_md3_style("light", "#3568D4"))

    def _build_layout(self) -> None:
        base = QWidget()
        outer = QHBoxLayout(base)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(224)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(16, 18, 16, 18)
        side.setSpacing(8)
        brand = QLabel("BiliMusic")
        brand.setObjectName("Brand")
        side.addWidget(brand)
        brand_sub = QLabel("LIVE MUSIC DESK")
        brand_sub.setObjectName("Eyebrow")
        brand_sub.setContentsMargins(8, 0, 0, 14)
        side.addWidget(brand_sub)
        self.nav = QListWidget()
        self.nav.addItems(["⌂  控制台", "♫  点歌队列", "☷  点歌规则", "◎  账号与平台", "▣  OBS 展示", "≡  运行日志", "⚙  系统设置", "◉  B站消息测试", "⇄  B站开放平台", "♫  歌单管理", "▶  音乐播放器"])
        self.nav.setCurrentRow(0)
        self.nav.currentRowChanged.connect(self._switch_page)
        side.addWidget(self.nav, 1)
        footer_line = QFrame()
        footer_line.setFixedHeight(1)
        footer_line.setStyleSheet("background: palette(mid); border: none;")
        side.addWidget(footer_line)
        foot = QLabel("本地开发版 · V0.4.38")
        foot.setObjectName("Muted")
        foot.setContentsMargins(8, 8, 0, 0)
        side.addWidget(foot)
        outer.addWidget(sidebar)

        self.pages = QStackedWidget()
        self.pages.addWidget(self.dashboard_page())
        self.pages.addWidget(self.queue_page())
        self.pages.addWidget(self.rules_page())
        self.pages.addWidget(self.accounts_page())
        self.pages.addWidget(self.obs_page())
        self.pages.addWidget(self.logs_page())
        self.pages.addWidget(self.system_page())
        self.pages.addWidget(self.bilibili_test_page())
        self.pages.addWidget(self.open_live_page())
        self.pages.addWidget(self.playlists_page())
        self.pages.addWidget(self.player_page())
        outer.addWidget(self.pages, 1)
        self.setCentralWidget(base)

    def _switch_page(self, index: int) -> None:
        self.pages.setCurrentIndex(index)
        if index == 0:
            self.refresh_dashboard()
        elif index == 1:
            self.refresh_queue()
        elif index == 3:
            if self._netease_verified_profile is None and not self._netease_status_checking:
                self.verify_netease_login_status(show_result=False)
        elif index == 5:
            self.refresh_logs()
        elif index == 7:
            self.refresh_queue()
        elif index == 9:
            self.refresh_playlists()
            self.refresh_player_library()
        elif index == 10:
            self.refresh_player_library()

    @staticmethod
    def page_shell(title: str, subtitle: str = ""):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(16)
        heading = QLabel(title)
        heading.setObjectName("PageTitle")
        layout.addWidget(heading)
        if subtitle:
            desc = QLabel(subtitle)
            desc.setObjectName("PageSubtitle")
            desc.setWordWrap(True)
            layout.addWidget(desc)
        return widget, layout

    @staticmethod
    def scroll_page(title: str, subtitle: str = ""):
        page, page_layout = MainWindow.page_shell(title, subtitle)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 2, 8, 8)
        content_layout.setSpacing(16)
        scroll.setWidget(content)
        page_layout.addWidget(scroll, 1)
        return page, content_layout

    @staticmethod
    def card(title: str, value: str, hint: str, tinted: bool = False):
        box = QFrame()
        box.setObjectName("TintCard" if tinted else "Card")
        layout = QVBoxLayout(box)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(7)
        label = QLabel(title)
        label.setObjectName("Muted")
        value_label = QLabel(value)
        value_label.setObjectName("Value")
        hint_label = QLabel(hint)
        hint_label.setObjectName("Muted")
        hint_label.setWordWrap(True)
        layout.addWidget(label)
        layout.addWidget(value_label)
        layout.addWidget(hint_label)
        return box

    @staticmethod
    def section_card(title: str, subtitle: str = ""):
        box = QFrame()
        box.setObjectName("Card")
        layout = QVBoxLayout(box)
        layout.setContentsMargins(18, 16, 18, 18)
        layout.setSpacing(12)
        heading = QLabel(title)
        heading.setObjectName("SectionTitle")
        layout.addWidget(heading)
        if subtitle:
            desc = QLabel(subtitle)
            desc.setObjectName("Muted")
            desc.setWordWrap(True)
            layout.addWidget(desc)
        return box, layout

    def dashboard_page(self):
        widget, layout = self.page_shell("控制台", "BiliMusic V0.4.38 本地运行概览。包含 B站消息模拟与官方开放平台接入预览。")
        cards = QGridLayout()
        cards.setSpacing(14)
        connection_card = self.card("B站连接", "未连接", "开放平台连接预览；本地模拟器始终可用", True)
        self.dashboard_connection_value = connection_card.findChild(QLabel, "Value")
        cards.addWidget(connection_card, 0, 0)
        player_card = self.card("当前播放", "暂无", "本地授权音频播放器")
        self.dashboard_player_value = player_card.findChild(QLabel, "Value")
        cards.addWidget(player_card, 0, 1)
        queue_card = self.card("待播歌曲", str(len(self.queue.list_queue())), "本地 SQLite 队列", True)
        self.dashboard_queue_value = queue_card.findChild(QLabel, "Value")
        cards.addWidget(queue_card, 0, 2)
        layout.addLayout(cards)

        panel, panel_layout = self.section_card("开发进度", "已完成的本地基础能力与尚待接入的外部平台能力。")
        status_rows = [
            (True, "桌面界面与模块化项目结构"),
            (True, "SQLite 数据库与配置持久化"),
            (True, "点歌队列、优先级排序和主播手动调整顺序"),
            (True, "主播手动添加歌曲到待播队列"),
            (True, "本地音频导入与实际播放、音量/进度控制和播放历史"),
            (True, "观众点歌打断自动播放，队列结束后继续播放"),
            (True, "网易云扫码登录、歌单同步与会员账号播放资源解析（第三方本地 API）"),
            (False, "B站官方消息权限及 OBS 歌词叠加层"),
            (False, "B站真实弹幕、粉丝牌、大航海和 SC 消息联调验收"),
            (False, "OBS 浏览器源和正式安装包"),
        ]
        for done, text in status_rows:
            row = QHBoxLayout()
            mark = QLabel("✓" if done else "○")
            mark.setStyleSheet("font-size: 16px; font-weight: 800;")
            mark.setFixedWidth(24)
            mark.setObjectName("Muted" if not done else "")
            label = QLabel(text)
            label.setObjectName("Muted" if not done else "")
            row.addWidget(mark)
            row.addWidget(label, 1)
            panel_layout.addLayout(row)
        layout.addWidget(panel)
        layout.addStretch()
        return widget

    def refresh_dashboard(self):
        if hasattr(self, "dashboard_queue_value"):
            self.dashboard_queue_value.setText(str(len(self.queue.list_queue())))

    def _on_real_connection_state(self, state: ConnectionState, detail: str):
        self.database.log("INFO", "bilibili", f"兼容连接状态：{state.value} - {detail}")

    def _on_open_live_state(self, state: str, detail: str):
        labels = {
            "connecting": "正在连接", "connected": "官方连接已建立",
            "reconnecting": "切换备用节点", "disconnected": "未连接",
            "warning": "警告", "error": "连接失败",
        }
        if hasattr(self, "open_live_status"):
            self.open_live_status.setText(f"{labels.get(state, state)} · {detail}")
        if hasattr(self, "open_live_connect_button"):
            if state == "connected":
                self.open_live_connect_button.setText("断开官方连接")
            elif state in {"disconnected", "error", "warning"}:
                self.open_live_connect_button.setText("连接 B站官方平台")
        if hasattr(self, "dashboard_connection_value"):
            self.dashboard_connection_value.setText("B站已连接" if state == "connected" else "未连接")
        self.database.log("INFO" if state not in {"error", "warning"} else "WARNING", "bilibili_open", f"{labels.get(state, state)}：{detail}")

    def _on_open_live_message(self, message: LiveMessage):
        payload = {
            "message_type": message.message_type, "room_id": message.room_id,
            "uid": message.uid, "username": message.username, "text": message.text,
            "fan_badge_name": message.fan_badge_name,
            "fan_badge_level": message.fan_badge_level,
            "guard_level": message.guard_level, "sc_amount": message.sc_amount,
        }
        result = self.request_pipeline.handle_payload(payload)
        if result.accepted:
            detail = f"已受理：{message.username} 点歌《{message.text}》（歌曲 ID {result.song_id}）"
        elif result.reason:
            detail = f"未受理：{message.username or message.uid} - {result.reason}"
        else:
            detail = f"收到官方消息：{message.message_type}；未识别为点歌指令。"
        self.database.log("INFO", "bilibili_open", detail)
        if hasattr(self, "open_live_result_view"):
            self.open_live_result_view.append(detail)
        self.refresh_queue()
        self.refresh_dashboard()
        self.refresh_logs()

    def _on_simulated_state(self, state: ConnectionState, detail: str):
        if hasattr(self, "sim_status"):
            self.sim_status.setText(f"模拟环境：{self._state_label(state)} · {detail}")
        if hasattr(self, "dashboard_connection_value"):
            self.dashboard_connection_value.setText("模拟已连接" if state == ConnectionState.CONNECTED else "未连接")

    @staticmethod
    def _state_label(state: ConnectionState) -> str:
        return {
            ConnectionState.DISCONNECTED: "未连接",
            ConnectionState.CONNECTING: "连接中",
            ConnectionState.CONNECTED: "已连接",
            ConnectionState.RECONNECTING: "重连中",
            ConnectionState.ERROR: "连接错误",
        }.get(state, str(state.value))

    def _on_simulated_message(self, message: LiveMessage):
        payload = {
            "message_type": message.message_type,
            "room_id": message.room_id,
            "uid": message.uid,
            "username": message.username,
            "text": message.text,
            "fan_badge_name": message.fan_badge_name,
            "fan_badge_level": message.fan_badge_level,
            "guard_level": message.guard_level,
            "sc_amount": message.sc_amount,
        }
        result = self.request_pipeline.handle_payload(payload)
        if result.accepted:
            message_text = f"已受理：{message.username} 点歌《{message.text}》 (歌曲 ID {result.song_id})"
        elif result.reason:
            message_text = f"未受理：{message.username} - {result.reason}"
        else:
            message_text = f"已收到 {message.message_type} 消息，但没有识别到点歌指令。"
        self._append_simulation_result(message_text)
        self.refresh_queue()
        self.refresh_dashboard()
        self.refresh_logs()

    def _append_simulation_result(self, text: str):
        if hasattr(self, "sim_result_view"):
            self.sim_result_view.append(text)
        self.database.log("INFO", "bilibili_sim", text)

    def bilibili_test_page(self):
        widget, layout = self.scroll_page(
            "B站消息测试",
            "本地模拟环境：可验证消息解析、点歌规则和队列联动。模拟页面不会连接真实 B站，也不会使用账号凭证。",
        )
        conn_card, conn_layout = self.section_card("模拟直播间", "输入一个测试直播间号，然后启动本地模拟连接。")
        row = QHBoxLayout()
        self.sim_room_input = QLineEdit("1000")
        self.sim_room_input.setPlaceholderText("直播间号")
        self.sim_room_input.setValidator(QIntValidator(1, 2147483647, self))
        self.sim_connect_button = QPushButton("启动模拟连接")
        self.sim_connect_button.setObjectName("Primary")
        self.sim_connect_button.clicked.connect(self.toggle_simulation_connection)
        row.addWidget(QLabel("测试房间号"))
        row.addWidget(self.sim_room_input, 1)
        row.addWidget(self.sim_connect_button)
        conn_layout.addLayout(row)
        self.sim_status = QLabel("模拟环境：未连接")
        self.sim_status.setObjectName("Muted")
        conn_layout.addWidget(self.sim_status)
        layout.addWidget(conn_card)

        form_card, form_layout = self.section_card("发送模拟消息", "点歌格式：点歌 歌名 歌手；歌手可省略。UID 用于测试个人冷却和次数限制。")
        grid = QGridLayout()
        self.sim_user_name = QLineEdit("测试观众")
        self.sim_user_uid = QLineEdit("10001")
        self.sim_message_type = QComboBox()
        self.sim_message_type.addItem("普通弹幕", "danmaku")
        self.sim_message_type.addItem("SC 付费留言", "sc")
        self.sim_role = QComboBox()
        self.sim_role.addItem("普通观众", 0)
        self.sim_role.addItem("舰长", 3)
        self.sim_role.addItem("提督", 2)
        self.sim_role.addItem("总督", 1)
        self.sim_badge_level = QLineEdit("10")
        self.sim_badge_level.setValidator(QIntValidator(0, 40, self))
        self.sim_sc_amount = QLineEdit("30")
        self.sim_sc_amount.setValidator(QIntValidator(0, 100000, self))
        self.sim_request_text = QLineEdit("点歌 测试歌曲 测试歌手")
        fields = [
            ("用户昵称", self.sim_user_name), ("用户 UID", self.sim_user_uid),
            ("消息类型", self.sim_message_type), ("身份", self.sim_role),
            ("粉丝牌等级", self.sim_badge_level), ("SC 金额（元）", self.sim_sc_amount),
            ("弹幕 / SC 内容", self.sim_request_text),
        ]
        for index, (label, control) in enumerate(fields):
            grid.addWidget(QLabel(label), index, 0)
            grid.addWidget(control, index, 1)
        form_layout.addLayout(grid)
        send_row = QHBoxLayout()
        send_button = QPushButton("发送模拟消息")
        send_button.setObjectName("Primary")
        send_button.clicked.connect(self.send_simulated_message)
        clear_button = QPushButton("清空测试记录")
        clear_button.clicked.connect(lambda: self.sim_result_view.clear())
        send_row.addWidget(send_button)
        send_row.addWidget(clear_button)
        send_row.addStretch()
        form_layout.addLayout(send_row)
        layout.addWidget(form_card)

        result_card, result_layout = self.section_card("处理结果", "这里会显示消息是否被识别、是否通过规则，以及对应的拒绝原因。")
        self.sim_result_view = QTextEdit()
        self.sim_result_view.setReadOnly(True)
        self.sim_result_view.setMinimumHeight(180)
        result_layout.addWidget(self.sim_result_view)
        layout.addWidget(result_card)

        note = QLabel("真实 B站连接：尚未启用。正式连接必须使用经批准的官方接入方式；当前版本不会抓取网页、读取 Cookie 或模拟真实在线状态。")
        note.setObjectName("Muted")
        note.setWordWrap(True)
        layout.addWidget(note)
        layout.addStretch()
        return widget

    def open_live_page(self):
        widget, layout = self.scroll_page(
            "B站开放平台",
            "V0.3.0 官方接入预览：通过开放平台 app/start 获取场次与 WSS 信息，再接收获批的直播消息。",
        )
        info, info_layout = self.section_card(
            "接入前提",
            "需要 B站开放平台已批准的开发者 access_key / access_secret、项目 app_id，以及主播身份码。未获得权限时请继续使用本地模拟测试。",
        )
        info_link = QPushButton("打开 B站直播开放平台")
        info_link.clicked.connect(lambda: QDesktopServices.openUrl(QUrl("https://open-live.bilibili.com/")))
        info_layout.addWidget(info_link, alignment=Qt.AlignmentFlag.AlignLeft)
        layout.addWidget(info)

        form, form_layout = self.section_card(
            "官方接入凭证",
            "凭证只保存在当前 Windows 用户的 DPAPI 加密文件中，不写入 SQLite、普通配置文件或运行日志。",
        )
        grid = QGridLayout()
        self.open_live_app_id = QLineEdit()
        self.open_live_app_id.setPlaceholderText("开放平台项目 ID（int64）")
        self.open_live_access_key = QLineEdit()
        self.open_live_access_key.setPlaceholderText("access_key")
        self.open_live_access_secret = QLineEdit()
        self.open_live_access_secret.setPlaceholderText("access_secret（保存后自动清空输入框）")
        self.open_live_access_secret.setEchoMode(QLineEdit.EchoMode.Password)
        self.open_live_auth_code = QLineEdit()
        self.open_live_auth_code.setPlaceholderText("主播身份码")
        self.open_live_auth_code.setEchoMode(QLineEdit.EchoMode.Password)
        fields = [
            ("项目 app_id", self.open_live_app_id),
            ("access_key", self.open_live_access_key),
            ("access_secret", self.open_live_access_secret),
            ("主播身份码", self.open_live_auth_code),
        ]
        for row_index, (label, field) in enumerate(fields):
            grid.addWidget(QLabel(label), row_index, 0)
            grid.addWidget(field, row_index, 1)
        form_layout.addLayout(grid)

        actions = QHBoxLayout()
        self.open_live_save_button = QPushButton("安全保存凭证")
        self.open_live_save_button.clicked.connect(self.save_open_live_credentials)
        self.open_live_connect_button = QPushButton("连接 B站官方平台")
        self.open_live_connect_button.setObjectName("Primary")
        self.open_live_connect_button.clicked.connect(self.toggle_open_live_connection)
        self.open_live_delete_button = QPushButton("删除本机凭证")
        self.open_live_delete_button.clicked.connect(self.delete_open_live_credentials)
        actions.addWidget(self.open_live_save_button)
        actions.addWidget(self.open_live_connect_button)
        actions.addWidget(self.open_live_delete_button)
        actions.addStretch()
        form_layout.addLayout(actions)
        self.open_live_status = QLabel("官方连接：未连接。此状态不代表已经获得平台权限。")
        self.open_live_status.setObjectName("Muted")
        self.open_live_status.setWordWrap(True)
        form_layout.addWidget(self.open_live_status)
        layout.addWidget(form)

        results, results_layout = self.section_card(
            "官方消息处理结果",
            "只会收到开放平台已为该应用开通的消息类型；未获批的事件不会因为客户端代码存在就自动推送。",
        )
        self.open_live_result_view = QTextEdit()
        self.open_live_result_view.setReadOnly(True)
        self.open_live_result_view.setMinimumHeight(160)
        results_layout.addWidget(self.open_live_result_view)
        layout.addWidget(results)
        note = QLabel(
            "安全提示：不要把 access_key、access_secret 或主播身份码发到聊天、截图或 GitHub。"
            "如平台对开发者认证或年龄资格有要求，应按平台规则由符合资格的账号持有人办理；本软件不提供绕过审核的方式。"
        )
        note.setObjectName("Muted")
        note.setWordWrap(True)
        layout.addWidget(note)
        layout.addStretch()

        # Load only non-secret identifiers into the visible form; the secret stays masked in storage.
        try:
            saved = self.open_live_credential_store.load()
            if saved:
                self.open_live_app_id.setText(saved.get("app_id", ""))
                self.open_live_access_key.setText(saved.get("access_key", ""))
                self.open_live_auth_code.setText(saved.get("auth_code", ""))
                self.open_live_status.setText("检测到本机加密凭证。access_secret 已保留在系统加密存储中。")
        except CredentialStoreError as exc:
            self.open_live_status.setText(str(exc))
        return widget

    def _open_live_form_values(self, keep_existing_secret: bool = True) -> dict[str, str]:
        app_id = self.open_live_app_id.text().strip()
        access_key = self.open_live_access_key.text().strip()
        access_secret = self.open_live_access_secret.text()
        auth_code = self.open_live_auth_code.text().strip()
        if not access_secret and keep_existing_secret:
            saved = self.open_live_credential_store.load()
            access_secret = saved.get("access_secret", "") if saved else ""
        values = {
            "app_id": app_id, "access_key": access_key,
            "access_secret": access_secret, "auth_code": auth_code,
        }
        if not all(values.values()):
            raise ValueError("请填写项目 app_id、access_key、access_secret 和主播身份码。")
        try:
            app_id_num = int(app_id)
        except ValueError:
            raise ValueError("app_id 必须是正整数。") from None
        if not 1 <= app_id_num <= 9_223_372_036_854_775_807:
            raise ValueError("app_id 超出有效 int64 范围。")
        values["app_id"] = str(app_id_num)
        return values

    def save_open_live_credentials(self):
        try:
            values = self._open_live_form_values()
            self.open_live_credential_store.save(values)
            self.open_live_access_secret.clear()
            self.open_live_status.setText("官方凭证已通过 Windows DPAPI 加密保存；尚未验证平台权限。")
            self.database.log("INFO", "bilibili_open", "B站开放平台凭证已加密保存（未记录凭证内容）")
            QMessageBox.information(self, "保存成功", "凭证已加密保存在当前 Windows 用户下。密钥内容未写入日志或数据库。")
        except (ValueError, CredentialStoreError) as exc:
            QMessageBox.warning(self, "无法保存凭证", str(exc))

    def toggle_open_live_connection(self):
        if self.open_live_client.is_running:
            self.open_live_client.disconnect()
            return
        try:
            values = self._open_live_form_values()
            credentials = OpenLiveCredentials(
                app_id=int(values["app_id"]), access_key=values["access_key"],
                access_secret=values["access_secret"], auth_code=values["auth_code"],
            )
            credentials.validate()
            # Persist before starting; never copy secrets into app settings or logs.
            self.open_live_credential_store.save(values)
            self.open_live_access_secret.clear()
            self.open_live_client.connect(credentials)
        except (ValueError, CredentialStoreError, RuntimeError) as exc:
            QMessageBox.warning(self, "无法启动官方连接", str(exc))

    def delete_open_live_credentials(self):
        answer = QMessageBox.question(
            self, "删除本机凭证", "确定删除此 Windows 用户下保存的 B站开放平台加密凭证吗？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        try:
            self.open_live_credential_store.delete()
            self.open_live_access_secret.clear()
            self.open_live_access_key.clear()
            self.open_live_auth_code.clear()
            self.open_live_app_id.clear()
            self.open_live_status.setText("本机加密凭证已删除。")
        except CredentialStoreError as exc:
            QMessageBox.warning(self, "删除失败", str(exc))

    def toggle_simulation_connection(self):
        if self.simulated_client.is_connected:
            self.simulated_manager.disconnect()
            self.sim_connect_button.setText("启动模拟连接")
            return
        try:
            room_id = int(self.sim_room_input.text())
            self.simulation_room_id = room_id
            self.simulated_manager.connect(room_id)
            self.sim_connect_button.setText("断开模拟连接")
            self._append_simulation_result(f"模拟连接已启动，测试房间号：{room_id}")
        except (ValueError, RuntimeError) as exc:
            QMessageBox.warning(self, "模拟连接失败", str(exc))

    def send_simulated_message(self):
        if not self.simulated_client.is_connected:
            QMessageBox.information(self, "尚未连接", "请先启动模拟连接。")
            return
        uid = self.sim_user_uid.text().strip()
        username = self.sim_user_name.text().strip()
        text = self.sim_request_text.text().strip()
        if not uid or not username or not text:
            QMessageBox.information(self, "信息不完整", "请填写用户昵称、UID 和消息内容。")
            return
        try:
            amount = float(self.sim_sc_amount.text() or 0)
            badge_level = int(self.sim_badge_level.text() or 0)
            message = LiveMessage(
                message_type=str(self.sim_message_type.currentData()),
                room_id=self.simulation_room_id,
                uid=uid,
                username=username,
                text=text,
                fan_badge_name="测试粉丝牌",
                fan_badge_level=badge_level,
                guard_level=int(self.sim_role.currentData()),
                sc_amount=amount if self.sim_message_type.currentData() == "sc" else 0,
            )
            self.simulated_client.emit(message)
        except (ValueError, RuntimeError) as exc:
            QMessageBox.warning(self, "发送失败", str(exc))

    def queue_page(self):
        widget, layout = self.page_shell("点歌队列", "管理待播歌曲。主播手动调整顺序后，以主播指定顺序为准。")
        summary = QHBoxLayout()
        summary.setSpacing(12)
        self.queue_count_value = QLabel("0")
        self.queue_count_value.setObjectName("Value")
        count_card, count_layout = self.section_card("待播歌曲")
        count_layout.addWidget(self.queue_count_value)
        self.queue_mode_label = QLabel("当前排序：自动优先级")
        self.queue_mode_label.setObjectName("Muted")
        mode_card, mode_layout = self.section_card("队列排序")
        mode_layout.addWidget(self.queue_mode_label)
        summary.addWidget(count_card, 1)
        summary.addWidget(mode_card, 2)
        layout.addLayout(summary)

        add_card, add_layout = self.section_card("主播手动添加", "添加的歌曲会标记为「主播手动添加」，并进入待播队列。")
        form = QHBoxLayout()
        self.song_title = QLineEdit()
        self.song_title.setPlaceholderText("输入歌曲名称")
        self.song_artist = QLineEdit()
        self.song_artist.setPlaceholderText("歌手（可选）")
        add_button = QPushButton("＋  添加到队列")
        add_button.setObjectName("Primary")
        add_button.clicked.connect(self.add_song)
        form.addWidget(self.song_title, 3)
        form.addWidget(self.song_artist, 2)
        form.addWidget(add_button)
        add_layout.addLayout(form)
        layout.addWidget(add_card)

        table_card, table_layout = self.section_card("待播列表", "选择一首歌曲后，可删除或调整其播放顺序。")
        self.queue_table = ReorderableQueueTable(0, 7, self.persist_drag_order)
        self.queue_table.setHorizontalHeaderLabels(["ID", "序号", "歌曲", "歌手", "点歌人", "来源 / 身份", "优先级"])
        self.queue_table.setColumnHidden(0, True)
        self.queue_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.queue_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.queue_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.queue_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.queue_table.horizontalHeader().setSectionResizeMode(4, QHeaderView.Stretch)
        self.queue_table.horizontalHeader().setSectionResizeMode(5, QHeaderView.ResizeToContents)
        self.queue_table.horizontalHeader().setSectionResizeMode(6, QHeaderView.ResizeToContents)
        self.queue_table.verticalHeader().setVisible(False)
        self.queue_table.verticalHeader().setDefaultSectionSize(42)
        self.queue_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.queue_table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.queue_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.queue_table.setToolTip("按住歌曲行并拖动，可直接调整待播顺序")
        self.queue_table.setAlternatingRowColors(True)
        self.queue_table.setMinimumHeight(250)
        table_layout.addWidget(self.queue_table)
        actions = QHBoxLayout()
        refresh = QPushButton("刷新")
        refresh.clicked.connect(self.refresh_queue)
        delete = QPushButton("删除选中")
        delete.clicked.connect(self.delete_selected)
        delete_all = QPushButton("全部删除")
        delete_all.setObjectName("Tonal")
        delete_all.clicked.connect(self.delete_all_queued)
        up = QPushButton("↑  上移")
        up.setObjectName("Tonal")
        up.clicked.connect(lambda: self.move_selected(-1))
        down = QPushButton("↓  下移")
        down.setObjectName("Tonal")
        down.clicked.connect(lambda: self.move_selected(1))
        for button in (refresh, delete, delete_all, up, down):
            actions.addWidget(button)
        actions.addStretch()
        table_layout.addLayout(actions)
        layout.addWidget(table_card, 1)
        return widget

    def persist_drag_order(self, song_id: int, target_row: int):
        """Persist and render the new order after the native drag loop has ended."""
        try:
            moved = self.queue.move_to_position(song_id, target_row)
            if moved:
                self.refresh_queue()
                self.refresh_dashboard()
                for row in range(self.queue_table.rowCount()):
                    item = self.queue_table.item(row, 0)
                    if item is not None and int(item.data(Qt.ItemDataRole.UserRole)) == song_id:
                        self.queue_table.selectRow(row)
                        break
        except (ValueError, RuntimeError) as exc:
            QMessageBox.warning(self, "排序未保存", str(exc))
            self.refresh_queue()

    def add_song(self):
        title = self.song_title.text().strip()
        if not title:
            QMessageBox.information(self, "提示", "请先输入歌曲名称。")
            return
        try:
            self.queue.enqueue(title, self.song_artist.text().strip(), source="manual", kind="normal")
        except ValueError as exc:
            QMessageBox.warning(self, "无法添加", str(exc))
            return
        self.song_title.clear()
        self.song_artist.clear()
        self.refresh_queue()
        self.refresh_dashboard()
        self.playback.poll()

    def refresh_queue(self):
        if not hasattr(self, "queue_table"):
            return
        songs = self.queue.list_queue()
        self.queue_table.setRowCount(len(songs))
        kind_names = {"normal": "普通", "captain": "舰长", "admiral": "提督", "governor": "总督", "sc": "SC"}
        source_names = {"manual": "主播手动添加", "danmaku": "弹幕点歌", "sc": "SC 点歌"}
        for row_index, song in enumerate(songs):
            source = source_names.get(song.source, song.source or "弹幕点歌")
            identity = kind_names.get(song.kind, song.kind)
            values = [str(song.id), str(row_index + 1), song.title, song.artist or "—",
                      song.requester_name or "—", f"{source} · {identity}", str(song.priority)]
            for col, value in enumerate(values):
                item = QTableWidgetItem(value)
                if col == 0:
                    item.setData(Qt.ItemDataRole.UserRole, song.id)
                if col == 1:
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                self.queue_table.setItem(row_index, col, item)
        self.queue_count_value.setText(str(len(songs)))
        if hasattr(self, "queue_mode_label"):
            manual_mode = bool(self.database.fetchone("SELECT EXISTS(SELECT 1 FROM songs WHERE status='queued' AND manual_order=1) AS enabled")["enabled"])
            self.queue_mode_label.setText("当前排序：主播手动顺序" if manual_mode else "当前排序：自动优先级")

    def selected_song_id(self) -> int | None:
        row = self.queue_table.currentRow()
        if row < 0:
            return None
        item = self.queue_table.item(row, 0)
        return int(item.text()) if item else None

    def delete_selected(self):
        song_id = self.selected_song_id()
        if song_id is None:
            QMessageBox.information(self, "提示", "请先选择一首待播歌曲。")
            return
        song = self.queue.get_song(song_id)
        title = song.title if song else "所选歌曲"
        answer = QMessageBox.question(
            self, "确认删除", f"确定从待播队列中删除《{title}》吗？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        self.queue.remove(song_id)
        self.refresh_queue()
        self.refresh_dashboard()

    def delete_all_queued(self):
        count = len(self.queue.list_queue())
        if count == 0:
            QMessageBox.information(self, "提示", "当前待播队列为空。")
            return
        answer = QMessageBox.question(
            self, "确认清空队列",
            f"确定删除全部 {count} 首待播歌曲吗？\n此操作只清空待播队列，不会删除已播放历史。",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        self.queue.remove_all_queued()
        self.refresh_queue()
        self.refresh_dashboard()

    def move_selected(self, direction: int):
        song_id = self.selected_song_id()
        if song_id is None:
            QMessageBox.information(self, "提示", "请先选择一首待播歌曲。")
            return
        moved = self.queue.move(song_id, direction)
        if not moved:
            QMessageBox.information(self, "无法调整", "该歌曲已在队列边界，无法继续移动。")
        self.refresh_queue()
        for row in range(self.queue_table.rowCount()):
            if int(self.queue_table.item(row, 0).text()) == song_id:
                self.queue_table.selectRow(row)
                break

    def rules_page(self):
        widget, layout = self.scroll_page("点歌规则", "设置会保存在本机数据库。粉丝牌和 SC 的真实校验需要等 B站消息接入后才能生效。")
        basic_card, basic_layout = self.section_card("基础点歌限制", "普通灯牌用户与舰长及以上用户分别计算冷却；SC 点歌不受个人冷却限制。")
        form = QFormLayout()
        form.setHorizontalSpacing(24)
        form.setVerticalSpacing(10)
        self.daily_limit = self._number_field(0, 999)
        self.normal_badge_cd = self._number_field(0, 86400)
        self.captain_cd = self._number_field(0, 86400)
        self.duplicate_cd = self._number_field(0, 10080)
        self.queue_limit = self._number_field(0, 999)
        self.fan_level = self._number_field(0, 40)
        controls = [
            ("每日点歌次数（0 = 不限）", "daily_limit", self.daily_limit),
            ("普通灯牌用户点歌冷却（秒）", "normal_badge_cooldown_seconds", self.normal_badge_cd),
            ("舰长及以上点歌冷却（秒）", "captain_cooldown_seconds", self.captain_cd),
            ("歌曲重复冷却（分钟）", "duplicate_cooldown_minutes", self.duplicate_cd),
            ("每人同时待播上限（0 = 不限）", "queue_limit_per_user", self.queue_limit),
            ("最低粉丝牌等级（0 = 不限制）", "min_fan_badge_level", self.fan_level),
        ]
        for label, key, control in controls:
            fallback = 180 if key == "captain_cooldown_seconds" else control.property("defaultValue")
            control.setText(str(self.settings.get(key, fallback)))
            form.addRow(label, control)
        basic_layout.addLayout(form)
        layout.addWidget(basic_card)

        role_card, role_layout = self.section_card("身份优先级", "数值越大，默认排序越靠前；主播手动调整顺序后以手动顺序为准。")
        roles = self.settings.get("role_priorities", {})
        self.role_controls = {}
        role_grid = QGridLayout()
        role_grid.setHorizontalSpacing(14)
        role_grid.setVerticalSpacing(10)
        for index, (key, label, default) in enumerate((
            ("normal", "普通观众", 10), ("captain", "舰长", 20),
            ("admiral", "提督", 30), ("governor", "总督", 40), ("sc", "SC 基础优先级", 50),
        )):
            field = self._number_field(0, 9999)
            field.setText(str(roles.get(key, default)))
            self.role_controls[key] = field
            cell = QVBoxLayout()
            label_widget = QLabel(label); label_widget.setObjectName("Muted")
            cell.addWidget(label_widget); cell.addWidget(field)
            role_grid.addLayout(cell, index // 3, index % 3)
        role_layout.addLayout(role_grid)
        layout.addWidget(role_card)

        sc_card, sc_layout = self.section_card("SC 金额优先级", "为不同 SC 金额设置优先级档位。SC 点歌不使用普通/舰长个人冷却。")
        self.sc_table = QTableWidget(0, 2)
        self.sc_table.setHorizontalHeaderLabels(["SC 起始金额（元）", "优先级"])
        self.sc_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.sc_table.verticalHeader().setVisible(False)
        self.sc_table.verticalHeader().setDefaultSectionSize(38)
        self.sc_table.setMaximumHeight(210)
        self.sc_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.sc_table.setEditTriggers(QAbstractItemView.DoubleClicked | QAbstractItemView.EditKeyPressed)
        for rule in self.settings.get("sc_priority_rules", []):
            row = self.sc_table.rowCount()
            self.sc_table.insertRow(row)
            self.sc_table.setItem(row, 0, QTableWidgetItem(str(rule.get("min_amount", 0))))
            self.sc_table.setItem(row, 1, QTableWidgetItem(str(rule.get("priority", 50))))
        sc_layout.addWidget(self.sc_table)
        sc_actions = QHBoxLayout()
        add_tier = QPushButton("＋ 新增金额档位")
        add_tier.clicked.connect(self.add_sc_tier)
        remove_tier = QPushButton("删除选中档位")
        remove_tier.clicked.connect(self.remove_sc_tier)
        sc_actions.addWidget(add_tier); sc_actions.addWidget(remove_tier); sc_actions.addStretch()
        sc_layout.addLayout(sc_actions)
        layout.addWidget(sc_card)

        save_row = QHBoxLayout()
        save_row.addStretch()
        save = QPushButton("保存所有规则")
        save.setObjectName("Primary")
        save.clicked.connect(lambda: self.save_rules(controls))
        save.setMinimumWidth(180)
        save_row.addWidget(save)
        layout.addLayout(save_row)
        layout.addStretch()
        return widget

    @staticmethod
    def _number_field(minimum: int, maximum: int) -> QLineEdit:
        field = QLineEdit()
        field.setValidator(QIntValidator(minimum, maximum, field))
        field.setProperty("defaultValue", minimum)
        field.setMaximumHeight(48)
        return field

    def add_sc_tier(self):
        row = self.sc_table.rowCount()
        self.sc_table.insertRow(row)
        self.sc_table.setItem(row, 0, QTableWidgetItem("30"))
        self.sc_table.setItem(row, 1, QTableWidgetItem("50"))

    def remove_sc_tier(self):
        row = self.sc_table.currentRow()
        if row >= 0:
            self.sc_table.removeRow(row)

    def save_rules(self, controls):
        parsed = {}
        try:
            for _, key, control in controls:
                text = control.text().strip()
                if not text:
                    raise ValueError("规则数值不能为空")
                parsed[key] = int(text)
            role_values = {}
            for key, field in self.role_controls.items():
                text = field.text().strip()
                if not text:
                    raise ValueError("身份优先级不能为空")
                role_values[key] = int(text)
            sc_rules = []
            for row in range(self.sc_table.rowCount()):
                amount_item = self.sc_table.item(row, 0)
                priority_item = self.sc_table.item(row, 1)
                if amount_item is None or priority_item is None:
                    raise ValueError("SC 档位存在空白单元格")
                amount = float(amount_item.text().strip())
                priority = int(priority_item.text().strip())
                if amount < 0 or priority < 0:
                    raise ValueError("SC 金额和优先级不能为负数")
                sc_rules.append({"min_amount": amount, "priority": priority})
        except ValueError as exc:
            QMessageBox.warning(self, "规则有误", str(exc))
            return
        for key, value in parsed.items():
            self.settings.set(key, value)
        # Legacy global cooldown is intentionally no longer read by this version.
        self.settings.set("role_priorities", role_values)
        sc_rules.sort(key=lambda item: item["min_amount"])
        self.settings.set("sc_priority_rules", sc_rules)
        self.database.log("INFO", "settings", "点歌规则和优先级配置已保存")
        QMessageBox.information(self, "保存成功", "点歌规则、身份优先级和 SC 档位已保存到本机数据库。")

    def accounts_page(self):
        widget, layout = self.scroll_page(
            "账号与平台", "音乐平台已精简为网易云音乐。账号通过扫码登录，登录凭证由 Windows DPAPI 加密保存在本机。"
        )
        bili, bili_layout = self.section_card(
            "B站开放平台", "需要平台批准的开发者权限、项目和主播身份码；不在此处校验大会员状态。"
        )
        bili_row = QHBoxLayout()
        bili_row.addWidget(QLabel("●  官方连接预览"), 1)
        bili_btn = QPushButton("查看接入设置")
        bili_btn.clicked.connect(lambda: self.nav.setCurrentRow(8))
        bili_row.addWidget(bili_btn)
        bili_layout.addLayout(bili_row)
        layout.addWidget(bili)

        netease, netease_layout = self.section_card(
            "网易云音乐", "使用你自己的网易云账号扫码登录。会员歌曲由账号当前权益决定；BiliMusic 不提供解锁、解灰或音质绕过功能。"
        )
        self.netease_login_status = QLabel(self._netease_login_status_text())
        self.netease_login_status.setObjectName("Muted")
        login_row = QHBoxLayout()
        login_btn = QPushButton("扫码登录 / 重新登录")
        login_btn.setObjectName("Primary")
        login_btn.clicked.connect(self.start_netease_login)
        verify_btn = QPushButton("验证登录状态")
        verify_btn.clicked.connect(lambda: self.verify_netease_login_status(show_result=True))
        logout_btn = QPushButton("退出登录并删除本机凭证")
        logout_btn.clicked.connect(self.logout_netease)
        login_row.addWidget(self.netease_login_status, 1)
        login_row.addWidget(login_btn)
        login_row.addWidget(verify_btn)
        login_row.addWidget(logout_btn)
        netease_layout.addLayout(login_row)
        layout.addWidget(netease)

        note = QLabel(
            "技术说明：网易云部分使用第三方 NeteaseCloudMusicApiEnhanced 本地服务，不是网易云官方 SDK。"
            "它通过本机回环地址提供账号、歌单和播放资源接口；服务仅监听 127.0.0.1，并关闭通用解锁与代理开关。"
            "第三方接口可能因平台调整而失效。直播传播音乐前仍需确认相应版权许可。"
        )
        note.setObjectName("Muted")
        note.setWordWrap(True)
        layout.addWidget(note)
        layout.addStretch()
        return widget

    def obs_page(self):
        widget, layout = self.scroll_page("OBS 展示", "通过本机 HTTP 服务提供浏览器源，不需要云服务器。当前版本尚未启动 OBS 服务。")
        status_card, status_layout = self.section_card("浏览器源状态")
        status = QLabel("○  尚未启用")
        status.setObjectName("Muted")
        status_layout.addWidget(status)
        layout.addWidget(status_card)
        preview, preview_layout = self.section_card("计划展示内容", "接入完成后，可在 OBS 中添加浏览器源展示以下信息。")
        for line in ("当前歌曲与歌手", "点歌人和点歌来源", "下一首待播歌曲", "SC 提示与歌词（视平台授权能力而定）"):
            label = QLabel("•  " + line)
            label.setObjectName("Muted")
            preview_layout.addWidget(label)
        layout.addWidget(preview)
        layout.addStretch()
        return widget

    def logs_page(self):
        widget, layout = self.page_shell("运行日志", "查看本地操作记录，便于排查点歌队列和配置问题。")
        toolbar = QHBoxLayout()
        self.log_search = QLineEdit()
        self.log_search.setPlaceholderText("搜索日志内容…")
        self.log_search.textChanged.connect(self.refresh_logs)
        self.log_level = QComboBox()
        self.log_level.setObjectName("LogLevelFilter")
        self.log_level.setMinimumWidth(150)
        self.log_level.setMinimumHeight(44)
        self.log_level.addItem("全部等级", "all")
        self.log_level.addItem("INFO", "INFO")
        self.log_level.addItem("WARNING", "WARNING")
        self.log_level.addItem("ERROR", "ERROR")
        self.log_level.currentIndexChanged.connect(self.refresh_logs)
        toolbar.addWidget(self.log_search, 1)
        toolbar.addWidget(self.log_level)
        layout.addLayout(toolbar)
        self.log_view = QTextEdit()
        self.log_view.setReadOnly(True)
        layout.addWidget(self.log_view, 1)
        button = QPushButton("刷新日志")
        button.clicked.connect(self.refresh_logs)
        layout.addWidget(button)
        self.refresh_logs()
        return widget

    def refresh_logs(self):
        if not hasattr(self, "log_view"):
            return
        rows = self.database.recent_logs(500)
        query = self.log_search.text().strip().lower() if hasattr(self, "log_search") else ""
        level = self.log_level.currentData() if hasattr(self, "log_level") else "all"
        lines = []
        for row in rows:
            if level != "all" and row["level"] != level:
                continue
            line = f"{row['created_at']}  [{row['level']}] [{row['category']}] {row['message']}"
            if query and query not in line.lower():
                continue
            lines.append(line)
        self.log_view.setPlainText("\n".join(lines) if lines else "没有符合条件的日志。")

    def playlists_page(self):
        widget, layout = self.scroll_page(
            "歌单管理", "仅保留网易云音乐。登录后同步歌单歌曲 ID，并通过账号当前可用的播放资源进行远程流播。"
        )
        info, info_layout = self.section_card("网易云连接状态", "本机 API 服务只监听 127.0.0.1，不会开放到局域网或公网。")
        self.netease_playlist_status = QLabel(self._netease_login_status_text())
        self.netease_playlist_status.setObjectName("Muted")
        info_layout.addWidget(self.netease_playlist_status)
        login_btn = QPushButton("管理网易云账号")
        login_btn.clicked.connect(lambda: self.nav.setCurrentRow(3))
        info_layout.addWidget(login_btn)
        layout.addWidget(info)

        actions, actions_layout = self.section_card("网易云歌单目录")
        row = QHBoxLayout()
        add_btn = QPushButton("添加网易云歌单")
        add_btn.setObjectName("Primary")
        add_btn.clicked.connect(self.add_playlist_dialog)
        remove_btn = QPushButton("删除歌单")
        remove_btn.clicked.connect(self.remove_playlist_dialog)
        active_btn = QPushButton("设为自动播放歌单")
        active_btn.clicked.connect(self.set_active_playlist)
        self.sync_playlist_button = QPushButton("同步所选歌单")
        self.sync_playlist_button.clicked.connect(self.sync_selected_playlist)
        open_btn = QPushButton("在网易云官方页面打开")
        open_btn.clicked.connect(self.open_selected_remote_playlist)
        for button in (add_btn, remove_btn, active_btn, self.sync_playlist_button, open_btn):
            row.addWidget(button)
        actions_layout.addLayout(row)
        self.playlist_table = QTableWidget(0, 5)
        self.playlist_table.setHorizontalHeaderLabels(["歌单名称", "来源链接 / ID", "歌曲数", "播放模式", "同步状态"])
        self.playlist_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.playlist_table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.playlist_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.playlist_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.playlist_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.playlist_table.itemSelectionChanged.connect(self.refresh_playlist_tracks)
        actions_layout.addWidget(self.playlist_table)
        layout.addWidget(actions)

        playlist_options, playlist_options_layout = self.section_card(
            "所选网易云歌单设置", "选择要作为自动播放来源的歌单，并设置该云端歌单的播放顺序。"
        )
        playlist_options_row = QHBoxLayout()
        playlist_options_row.addWidget(QLabel("播放模式"))
        self.netease_playlist_mode_combo = QComboBox()
        self.netease_playlist_mode_combo.addItems(["顺序播放", "列表循环", "随机播放"])
        self.netease_playlist_mode_combo.currentTextChanged.connect(self.update_selected_netease_playlist_mode)
        playlist_options_row.addWidget(self.netease_playlist_mode_combo)
        playlist_options_row.addSpacing(18)
        playlist_options_row.addWidget(QLabel("音质"))
        self.netease_quality_combo = QComboBox()
        for label, value in (("标准", "standard"), ("较高", "higher"), ("极高", "exhigh"),
                             ("无损", "lossless"), ("Hi-Res", "hires")):
            self.netease_quality_combo.addItem(label, value)
        selected_quality = str(self.settings.get("netease_quality", "exhigh"))
        selected_index = self.netease_quality_combo.findData(selected_quality)
        self.netease_quality_combo.setCurrentIndex(max(0, selected_index))
        self.netease_quality_combo.currentIndexChanged.connect(
            lambda _index: self.settings.set("netease_quality", self.netease_quality_combo.currentData())
        )
        playlist_options_row.addWidget(self.netease_quality_combo)
        playlist_options_row.addStretch()
        playlist_options_layout.addLayout(playlist_options_row)
        quality_note = QLabel("若所选音质不可用，会按较低音质逐级尝试；若只返回试听片段则不会播放。")
        quality_note.setObjectName("Muted")
        playlist_options_layout.addWidget(quality_note)
        layout.addWidget(playlist_options)

        tracks, tracks_layout = self.section_card(
            "歌单歌曲", "同步保存歌曲名称、歌手和网易云歌曲 ID；播放时即时向本地 API 请求短时效播放资源，不保存音频地址。"
        )
        self.playlist_track_table = QTableWidget(0, 3)
        self.playlist_track_table.setHorizontalHeaderLabels(["歌曲名称", "歌手", "网易云歌曲 ID"])
        self.playlist_track_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.playlist_track_table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.playlist_track_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.playlist_track_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.playlist_track_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.playlist_track_table.doubleClicked.connect(self.play_selected_netease_track)
        tracks_layout.addWidget(self.playlist_track_table)
        play_track_btn = QPushButton("▶ 播放全部歌曲（当前歌单）")
        play_track_btn.setObjectName("Primary")
        play_track_btn.clicked.connect(self.play_all_selected_playlist)
        tracks_layout.addWidget(play_track_btn)
        layout.addWidget(tracks)

        autoplay, autoplay_layout = self.section_card(
            "自动播放策略", "优先播放已设置的网易云歌单；未设置或歌单无可播歌曲时，退回本地音频库。观众点歌始终优先。"
        )
        self.autoplay_enabled_check = QComboBox()
        self.autoplay_enabled_check.addItems(["关闭自动播放", "启用自动播放"])
        self.autoplay_enabled_check.setCurrentIndex(1 if self.playlists.autoplay_enabled() else 0)
        self.autoplay_enabled_check.currentIndexChanged.connect(lambda i: self.playlists.set_autoplay(i == 1))
        self.playlist_mode_combo = QComboBox()
        self.playlist_mode_combo.addItems(["顺序播放", "列表循环", "随机播放"])
        self.playlist_mode_combo.setCurrentText(self.playlists.local_audio_mode())
        self.playlist_mode_combo.currentTextChanged.connect(self.playlists.set_local_audio_mode)
        autoplay_layout.addWidget(QLabel("自动播放总开关"))
        autoplay_layout.addWidget(self.autoplay_enabled_check)
        autoplay_layout.addWidget(QLabel("本地音频播放模式（网易云歌单使用歌单自身模式）"))
        autoplay_layout.addWidget(self.playlist_mode_combo)
        layout.addWidget(autoplay)

        layout.addStretch()
        self.refresh_playlists()
        self.refresh_player_library()
        return widget

    def _netease_login_status_text(self):
        if self._netease_status_checking:
            return "🟡 网易云账号：正在向服务端验证登录状态…"
        if self._netease_verified_profile:
            nickname, user_id = self._netease_verified_profile
            return f"🟢 网易云账号：已登录 · {nickname}（UID {user_id}）"
        if self._netease_status_error:
            return f"⚠️ 网易云账号：登录状态异常 · {self._netease_status_error}"
        try:
            return ("🟡 网易云账号：已保存本机加密凭证，尚未验证登录状态"
                    if self.music_secret_store.load() else "🔴 网易云账号：未登录")
        except SecretStoreError:
            return "🔴 网易云账号：凭证无法读取，请重新扫码登录"

    def _refresh_netease_status(self):
        value = self._netease_login_status_text()
        for name in ("netease_login_status", "netease_playlist_status"):
            label = getattr(self, name, None)
            if label is not None:
                label.setText(value)

    def verify_netease_login_status(self, show_result: bool = True):
        if self._netease_status_worker is not None and self._netease_status_worker.isRunning():
            return
        try:
            cookie = self.music_secret_store.load()
        except SecretStoreError as exc:
            self._netease_status_error = str(exc)
            self._netease_verified_profile = None
            self._refresh_netease_status()
            if show_result:
                QMessageBox.warning(self, "登录状态验证失败", str(exc))
            return
        if not cookie:
            self._netease_verified_profile = None
            self._netease_status_error = ""
            self._refresh_netease_status()
            if show_result:
                QMessageBox.information(self, "尚未登录", "请先使用网易云音乐 App 扫码登录。")
            return
        if not self._ensure_netease_service():
            self._netease_status_error = "本机网易云 API 服务不可用。"
            self._refresh_netease_status()
            return
        self._netease_status_checking = True
        self._netease_status_error = ""
        self._netease_verified_profile = None
        self._show_netease_status_result = bool(show_result)
        self._refresh_netease_status()
        worker = NeteaseAccountStatusWorker(cookie, self)
        worker.verified.connect(self._on_netease_status_verified)
        worker.failed.connect(self._on_netease_status_failed)
        self._netease_status_worker = worker
        worker.start()

    def _on_netease_status_verified(self, nickname: str, user_id: int):
        self._netease_status_checking = False
        self._netease_status_error = ""
        self._netease_verified_profile = (nickname, user_id)
        self.database.log("INFO", "netease", f"网易云登录状态验证成功：{nickname}（UID {user_id}）。")
        self._refresh_netease_status()
        if self._show_netease_status_result:
            QMessageBox.information(self, "网易云登录成功", f"已确认登录网易云账号：{nickname}（UID {user_id}）。")
        self._show_netease_status_result = False

    def _on_netease_status_failed(self, message: str):
        self._netease_status_checking = False
        self._netease_status_error = message or "网易云未确认登录状态。"
        self._netease_verified_profile = None
        self.database.log("WARNING", "netease", f"网易云登录状态验证失败：{self._netease_status_error}")
        self._refresh_netease_status()
        if self._show_netease_status_result:
            QMessageBox.warning(self, "登录状态未确认", self._netease_status_error + "\n请重新扫码登录，或稍后重试验证。")
        self._show_netease_status_result = False

    def _ensure_netease_service(self):
        try:
            self.netease_service.ensure_running()
            return True
        except NeteaseServiceError as exc:
            QMessageBox.warning(self, "网易云服务不可用", str(exc))
            self.database.log("ERROR", "netease", "本地网易云服务不可用。")
            return False

    def start_netease_login(self):
        if self._netease_login_worker and self._netease_login_worker.isRunning():
            return
        if not self._ensure_netease_service():
            return
        dialog = QDialog(self)
        dialog.setWindowTitle("网易云音乐扫码登录")
        dialog.setModal(True)
        dialog.resize(360, 420)
        layout = QVBoxLayout(dialog)
        image_label = QLabel("正在生成二维码…")
        image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        image_label.setMinimumSize(280, 280)
        status_label = QLabel("正在连接网易云本地服务…")
        status_label.setWordWrap(True)
        status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        cancel_btn = QPushButton("取消")
        cancel_btn.clicked.connect(dialog.reject)
        layout.addWidget(image_label, 1)
        layout.addWidget(status_label)
        layout.addWidget(cancel_btn)

        worker = NeteaseLoginWorker(self)
        worker.qr_ready.connect(lambda raw: self._show_netease_qr(image_label, raw))
        worker.status_changed.connect(status_label.setText)
        worker.authenticated.connect(self._on_netease_login_success)
        worker.failed.connect(lambda message: QMessageBox.warning(dialog, "登录失败", message))
        worker.finished.connect(lambda: cancel_btn.setText("关闭"))
        self._netease_login_worker = worker
        self._netease_login_dialog = dialog
        dialog.finished.connect(lambda _result: worker.cancel() if worker.isRunning() else None)
        worker.start()
        dialog.exec()
        if worker.isRunning():
            worker.cancel()
        self._refresh_netease_status()

    @staticmethod
    def _show_netease_qr(label, raw: bytes):
        image = QImage.fromData(raw)
        if image.isNull():
            label.setText("二维码图片无法显示，请重新尝试。")
            return
        label.setPixmap(QPixmap.fromImage(image).scaled(280, 280, Qt.AspectRatioMode.KeepAspectRatio,
                                                       Qt.TransformationMode.SmoothTransformation))

    def _on_netease_login_success(self, cookie: str):
        try:
            self.music_secret_store.save(cookie)
            self.database.log("INFO", "netease", "网易云扫码授权已确认，登录凭证通过 Windows DPAPI 加密保存；正在验证账号状态。")
            self._netease_verified_profile = None
            self._netease_status_error = ""
            self._refresh_netease_status()
            self.verify_netease_login_status(show_result=True)
        except (ValueError, SecretStoreError) as exc:
            QMessageBox.warning(self, "凭证保存失败", str(exc))

    def logout_netease(self):
        answer = QMessageBox.question(
            self, "退出网易云账号", "确定删除本机保存的网易云登录凭证吗？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        try:
            self.music_secret_store.delete()
            self._netease_verified_profile = None
            self._netease_status_error = ""
            self._refresh_netease_status()
            self.database.log("INFO", "netease", "已删除本机网易云登录凭证。")
        except SecretStoreError as exc:
            QMessageBox.warning(self, "操作失败", str(exc))

    def sync_selected_playlist(self):
        playlist_id = self._selected_playlist_id()
        if playlist_id is None:
            QMessageBox.information(self, "提示", "请先选择一个网易云歌单。")
            return
        if self._playlist_sync_worker is not None and self._playlist_sync_worker.isRunning():
            QMessageBox.information(self, "正在同步", "已有歌单同步任务正在运行，请稍后再试。")
            return
        row = self.playlists.get_playlist(playlist_id)
        if row is None or row["platform"] != "网易云音乐":
            return
        try:
            cookie = self.music_secret_store.load()
            if not cookie:
                QMessageBox.information(self, "需要登录", "请先在「账号与平台」页面扫码登录网易云。")
                return
            if not self._ensure_netease_service():
                return
            self.sync_playlist_button.setEnabled(False)
            self.netease_playlist_status.setText("正在同步网易云歌单…")
            worker = NeteasePlaylistSyncWorker(cookie, row["source_ref"], self)
            self._playlist_sync_worker = worker
            worker.succeeded.connect(lambda remote: self._on_netease_playlist_sync_success(playlist_id, remote))
            worker.failed.connect(lambda message: self._on_netease_playlist_sync_failure(playlist_id, message))
            worker.finished.connect(lambda: self.sync_playlist_button.setEnabled(True))
            worker.start()
        except SecretStoreError as exc:
            QMessageBox.warning(self, "无法读取登录凭证", str(exc))

    def _on_netease_playlist_sync_success(self, playlist_id: int, remote: NeteasePlaylist):
        try:
            count = self.playlists.replace_synced_tracks(playlist_id, remote)
            self.database.log("INFO", "playlist", f"网易云歌单同步成功：{remote.name}，{count} 首歌曲。")
            self.refresh_playlists()
            QMessageBox.information(self, "同步成功", f"已同步《{remote.name}》的 {count} 首歌曲。")
        except Exception as exc:
            self._on_netease_playlist_sync_failure(playlist_id, str(exc))

    def _on_netease_playlist_sync_failure(self, playlist_id: int, message: str):
        self.playlists.set_sync_error(playlist_id, message)
        self.database.log("WARNING", "playlist", f"网易云歌单同步失败：{message}")
        self.refresh_playlists()
        QMessageBox.warning(self, "同步失败", message)

    def open_selected_remote_playlist(self):
        playlist_id = self._selected_playlist_id()
        if playlist_id is None:
            return
        row = self.playlists.get_playlist(playlist_id)
        if row is None:
            return
        ref = (row["source_ref"] or "").strip()
        url = ref if ref.startswith(("https://", "http://")) else f"https://music.163.com/#/playlist?id={ref}"
        QDesktopServices.openUrl(QUrl(url))

    def _start_netease_resolver(self, mode: str, reference_id: int, title: str,
                                artist: str = "", song_id: str = "") -> bool:
        try:
            cookie = self.music_secret_store.load()
            if not cookie:
                return False
            self.netease_service.ensure_running()
        except (SecretStoreError, NeteaseServiceError) as exc:
            self._on_player_state("网易云服务不可用", str(exc))
            return False
        worker_key = (mode, reference_id)
        if worker_key in self._remote_workers:
            return False
        level = str(self.settings.get("netease_quality", "exhigh"))
        worker = NeteaseResolveWorker(cookie, mode, reference_id, title, artist, song_id, level, self)
        self._remote_workers[worker_key] = worker
        worker.resolved.connect(self._on_netease_track_resolved)
        worker.failed.connect(self._on_netease_track_failed)
        worker.finished.connect(lambda key=worker_key: self._remote_workers.pop(key, None))
        worker.start()
        return True

    def _queue_remote_request(self, song_id: int, title: str, artist: str) -> bool:
        return self._start_netease_resolver("request", song_id, title, artist)

    def _autoplay_remote_track(self, track_id: int, song_id: str, title: str, artist: str) -> bool:
        return self._start_netease_resolver("autoplay", track_id, title, artist, song_id)

    def _on_netease_track_resolved(self, mode: str, reference_id: int, url: str,
                                   title: str, artist: str, external_id: str):
        self.playback.start_remote(mode, reference_id, url, title, artist, external_id)

    def _on_netease_track_failed(self, mode: str, reference_id: int, message: str):
        self.playback.remote_failed(mode, reference_id, message)

    def play_all_selected_playlist(self):
        playlist_id = self._selected_playlist_id()
        if playlist_id is None:
            QMessageBox.information(self, "尚未选择歌单", "请先选择一个网易云歌单。")
            return
        tracks = self.playlists.list_tracks(playlist_id)
        playable = [track for track in tracks if track.source_ref and str(track.source_ref).isdigit()]
        if not playable:
            QMessageBox.information(self, "歌单尚未同步", "当前歌单没有可播放的歌曲 ID，请先同步歌单。")
            return
        if not self._ensure_netease_service():
            return
        if not self.playback.play_playlist(playlist_id):
            QMessageBox.warning(self, "无法开始播放", "请检查当前歌单是否存在可播放歌曲。")

    def play_selected_netease_track(self):
        row = self.playlist_track_table.currentRow()
        if row < 0:
            return
        id_item = self.playlist_track_table.item(row, 2)
        title_item = self.playlist_track_table.item(row, 0)
        artist_item = self.playlist_track_table.item(row, 1)
        if id_item is None or title_item is None:
            return
        playlist_id = self._selected_playlist_id()
        playlist_tracks = self.playlists.list_tracks(playlist_id) if playlist_id else []
        if row >= len(playlist_tracks):
            QMessageBox.warning(self, "歌曲信息无效", "请重新同步所选网易云歌单后再试。")
            return
        selected_track = playlist_tracks[row]
        try:
            song_id = str(selected_track.source_ref)
            if not song_id.isdigit():
                raise ValueError
        except ValueError:
            QMessageBox.warning(self, "歌曲 ID 无效", "请先同步所选网易云歌单。")
            return
        if self.playback.current_source == "request":
            QMessageBox.information(self, "观众点歌优先", "观众点歌正在播放，不能被手动试听打断。")
            return
        if not self.playback.prepare_manual_remote(selected_track.id):
            return
        if not self._start_netease_resolver("manual", selected_track.id, title_item.text(),
                                            artist_item.text() if artist_item else "", song_id):
            self.playback.remote_failed("manual", selected_track.id, "网易云账号未登录或本地服务不可用")

    def _selected_playlist_id(self):
        if not hasattr(self, "playlist_table") or not self.playlist_table.selectionModel().selectedRows():
            return None
        item = self.playlist_table.item(self.playlist_table.currentRow(), 0)
        return int(item.data(Qt.UserRole)) if item else None

    def refresh_playlists(self):
        if not hasattr(self, "playlist_table"):
            return
        selected = self._selected_playlist_id()
        rows = self.playlists.list_playlists()
        self.playlist_table.setRowCount(len(rows))
        for r, playlist in enumerate(rows):
            record = self.playlists.get_playlist(playlist.id)
            values = [playlist.name, playlist.source_ref, str(playlist.track_count),
                      playlist.play_mode, record["sync_status"] if record else "未同步"]
            for c, value in enumerate(values):
                item = QTableWidgetItem(value)
                if c == 0: item.setData(Qt.UserRole, playlist.id)
                self.playlist_table.setItem(r, c, item)
            if playlist.id == selected: self.playlist_table.selectRow(r)
        if rows and not self.playlist_table.selectionModel().selectedRows(): self.playlist_table.selectRow(0)
        self.refresh_playlist_tracks()
        self._refresh_netease_status()

    def refresh_playlist_tracks(self):
        if not hasattr(self, "playlist_track_table"):
            return
        playlist_id = self._selected_playlist_id()
        tracks = self.playlists.list_tracks(playlist_id) if playlist_id else []
        self.playlist_track_table.setRowCount(len(tracks))
        for r, track in enumerate(tracks):
            link_or_id = track.source_ref or track.external_url
            for c, value in enumerate([track.title, track.artist, link_or_id]):
                self.playlist_track_table.setItem(r, c, QTableWidgetItem(value))
        playlist = self.playlists.get_playlist(playlist_id) if playlist_id else None
        if hasattr(self, "netease_playlist_mode_combo"):
            self.netease_playlist_mode_combo.blockSignals(True)
            self.netease_playlist_mode_combo.setEnabled(playlist is not None)
            self.netease_playlist_mode_combo.setCurrentText(playlist["play_mode"] if playlist else "顺序播放")
            self.netease_playlist_mode_combo.blockSignals(False)

    def add_playlist_dialog(self):
        name, ok = QInputDialog.getText(self, "添加歌单", "歌单名称：")
        if not ok or not name.strip(): return
        platform = "网易云音乐"
        source, ok = QInputDialog.getText(self, "网易云歌单来源", "网易云歌单分享链接或数字 ID：")
        if not ok or not source.strip(): return
        try:
            self.playlists.add_playlist(name, platform, source)
            self.database.log("INFO", "playlist", f"已添加{platform}歌单：{name}")
            self.refresh_playlists()
        except Exception as exc:
            QMessageBox.warning(self, "添加失败", str(exc))

    def remove_playlist_dialog(self):
        playlist_id = self._selected_playlist_id()
        if playlist_id is None: return
        answer = QMessageBox.question(self, "确认删除", "删除该歌单及其同步的本地元数据？不会影响平台原始歌单。")
        if answer == QMessageBox.Yes:
            self.playlists.remove_playlist(playlist_id); self.refresh_playlists()

    def set_active_playlist(self):
        playlist_id = self._selected_playlist_id()
        if playlist_id is None:
            QMessageBox.information(self, "提示", "请先选择一个歌单。"); return
        self.playlists.set_active(playlist_id)
        QMessageBox.information(self, "设置成功", "已将所选网易云歌单设为自动播放来源。启用自动播放后，软件会按歌单模式获取当前账号可用的歌曲播放资源。")

    def add_playlist_track_dialog(self):
        playlist_id = self._selected_playlist_id()
        if playlist_id is None: return
        title, ok = QInputDialog.getText(self, "添加歌曲", "歌曲名称：")
        if not ok or not title.strip(): return
        artist, ok = QInputDialog.getText(self, "添加歌曲", "歌手（可选）：")
        if not ok: return
        self.playlists.add_track(playlist_id, title, artist); self.refresh_playlists()

    def remove_playlist_track_dialog(self):
        if not self.playlist_track_table.selectionModel().selectedRows(): return
        QMessageBox.information(self, "提示", "云端同步列表是只读元数据快照；请在原平台修改歌单后重新同步。")

    def update_selected_playlist_mode(self, mode):
        self.playlists.set_local_audio_mode(mode)

    def update_selected_netease_playlist_mode(self, mode):
        playlist_id = self._selected_playlist_id()
        if playlist_id is None:
            return
        try:
            self.playlists.set_mode(playlist_id, mode)
            self.refresh_playlists()
        except ValueError as exc:
            QMessageBox.warning(self, "播放模式设置失败", str(exc))

    def player_page(self):
        widget, layout = self.scroll_page(
            "音乐播放器",
            "网易云歌曲通过本地 API 获取临时播放地址并由 Qt Multimedia 远程流播；未登录或歌曲不可播时可回退到本地音频库。"
        )
        now, now_layout = self.section_card("当前播放")
        self.player_status_label = QLabel("等待播放")
        self.player_status_label.setObjectName("Value")
        self.player_detail_label = QLabel("网易云账号登录后，观众点歌会优先在网易云搜索并远程流播；本地音频仍可作为备用曲库。")
        self.player_detail_label.setWordWrap(True); self.player_detail_label.setObjectName("Muted")
        now_layout.addWidget(self.player_status_label); now_layout.addWidget(self.player_detail_label)
        controls = QHBoxLayout()
        play_btn = QPushButton("▶ 播放/继续"); play_btn.setObjectName("Primary"); play_btn.clicked.connect(self.resume_or_start_playback)
        pause_btn = QPushButton("Ⅱ 暂停"); pause_btn.clicked.connect(self.playback.pause)
        next_btn = QPushButton("下一首 / 跳过"); next_btn.clicked.connect(self.playback.skip_current)
        controls.addWidget(play_btn); controls.addWidget(pause_btn); controls.addWidget(next_btn); controls.addStretch()
        now_layout.addLayout(controls)
        volume_row = QHBoxLayout(); volume_row.addWidget(QLabel("音量"))
        self.player_volume_slider = QSlider(Qt.Orientation.Horizontal); self.player_volume_slider.setRange(0, 100); self.player_volume_slider.setValue(70)
        self.player_volume_slider.valueChanged.connect(lambda value: self.playback.set_volume(value / 100))
        self.playback.set_volume(0.7)
        volume_row.addWidget(self.player_volume_slider, 1); now_layout.addLayout(volume_row)
        self.player_position_label = QLabel("00:00 / 00:00"); self.player_position_label.setObjectName("Muted")
        self.player_position_slider = QSlider(Qt.Orientation.Horizontal); self.player_position_slider.setRange(0, 0)
        self.player_position_slider.sliderMoved.connect(self.player_backend.set_position)
        now_layout.addWidget(self.player_position_slider); now_layout.addWidget(self.player_position_label)
        layout.addWidget(now)

        # Lyrics occupy the former local-library position and span the full width.
        lyrics_box, lyrics_layout = self.section_card(
            "歌词", "网易云歌曲自动获取逐句时间轴；播放时会跟随进度自动滚动。"
        )
        self.lyric_status_label = QLabel("播放网易云歌曲后，将在这里显示同步歌词。")
        self.lyric_status_label.setObjectName("Muted")
        self.lyric_status_label.setWordWrap(True)
        lyrics_layout.addWidget(self.lyric_status_label)
        self.lyric_list = QListWidget()
        self.lyric_list.setWordWrap(True)
        self.lyric_list.setMinimumHeight(260)
        self.lyric_list.setSpacing(7)
        lyrics_layout.addWidget(self.lyric_list)
        layout.addWidget(lyrics_box)

        # The local library and recent history are the two parallel lower panels.
        panels = QHBoxLayout()
        panels.setSpacing(16)

        local_library, local_library_layout = self.section_card(
            "本地音频库", "本地音频可作为备用曲库；双击歌曲即可立即播放。"
        )
        local_buttons = QHBoxLayout()
        import_btn = QPushButton("导入音频文件")
        import_btn.setObjectName("Primary")
        import_btn.clicked.connect(self.import_local_audio)
        edit_btn = QPushButton("编辑歌曲信息")
        edit_btn.clicked.connect(self.edit_local_audio)
        remove_btn = QPushButton("移除选中")
        remove_btn.clicked.connect(self.remove_local_audio)
        local_buttons.addWidget(import_btn)
        local_buttons.addWidget(edit_btn)
        local_buttons.addWidget(remove_btn)
        local_buttons.addStretch()
        local_library_layout.addLayout(local_buttons)
        self.local_audio_table = QTableWidget(0, 3)
        self.local_audio_table.setHorizontalHeaderLabels(["歌曲名称", "歌手", "本地文件路径"])
        self.local_audio_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.local_audio_table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.local_audio_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        for column in range(3):
            self.local_audio_table.horizontalHeader().setSectionResizeMode(column, QHeaderView.Stretch)
        self.local_audio_table.doubleClicked.connect(self.play_selected_local_audio)
        self.local_audio_table.setMinimumHeight(300)
        local_library_layout.addWidget(self.local_audio_table)
        panels.addWidget(local_library, 1)

        history_box = QFrame()
        history_box.setObjectName("Card")
        history_layout = QVBoxLayout(history_box)
        history_layout.setContentsMargins(18, 16, 18, 18)
        history_layout.setSpacing(12)
        history_header = QHBoxLayout()
        history_title = QLabel("最近播放记录")
        history_title.setObjectName("SectionTitle")
        clear_history_btn = QPushButton("清空")
        clear_history_btn.setObjectName("TextButton")
        clear_history_btn.clicked.connect(self.clear_playback_history)
        history_header.addWidget(history_title)
        history_header.addStretch()
        history_header.addWidget(clear_history_btn)
        history_layout.addLayout(history_header)
        history_note = QLabel("显示最近播放结果；清空时会同时清理未受保护的应用媒体缓存，不会删除导入的原始音频文件。")
        history_note.setObjectName("Muted")
        history_note.setWordWrap(True)
        history_layout.addWidget(history_note)
        self.playback_history_table = QTableWidget(0, 5)
        self.playback_history_table.setHorizontalHeaderLabels(["歌曲", "歌手", "来源", "结果", "结束时间"])
        self.playback_history_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.playback_history_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.playback_history_table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.playback_history_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.playback_history_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.playback_history_table.setMinimumHeight(300)
        history_layout.addWidget(self.playback_history_table)
        panels.addWidget(history_box, 1)
        layout.addLayout(panels)
        layout.addStretch()
        self.refresh_player_library()
        return widget

    def resume_or_start_playback(self):
        if self.playback.current_source is not None:
            self.playback.resume()
        else:
            self.playback.poll()

    def import_local_audio(self):
        files, _ = QFileDialog.getOpenFileNames(self, "选择本地音频文件", "", "音频文件 (*.mp3 *.wav *.flac *.m4a *.aac *.ogg *.opus *.wma)")
        if not files: return
        count = self.playlists.add_local_audio_files(files)
        self.database.log("INFO", "player", f"已导入 {count} 个本地音频文件")
        self.refresh_player_library()
        QMessageBox.information(self, "导入完成", f"成功导入 {count} 个文件。")

    def edit_local_audio(self):
        if not self.local_audio_table.selectionModel().selectedRows():
            return
        item = self.local_audio_table.item(self.local_audio_table.currentRow(), 0)
        if not item:
            return
        track_id = int(item.data(Qt.UserRole))
        track = next((t for t in self.playlists.list_local_audio_tracks() if t.id == track_id), None)
        if track is None:
            return
        title, ok = QInputDialog.getText(self, "编辑歌曲信息", "歌曲名称：", text=track.title)
        if not ok or not title.strip():
            return
        artist, ok = QInputDialog.getText(self, "编辑歌曲信息", "歌手（可选）：", text=track.artist)
        if not ok:
            return
        try:
            self.playlists.update_local_audio_track(track_id, title, artist)
            self.refresh_player_library()
        except ValueError as exc:
            QMessageBox.warning(self, "保存失败", str(exc))

    def remove_local_audio(self):
        if not self.local_audio_table.selectionModel().selectedRows(): return
        item = self.local_audio_table.item(self.local_audio_table.currentRow(), 0)
        if item:
            self.playlists.remove_local_audio_track(int(item.data(Qt.UserRole)))
            self.refresh_player_library()

    def play_selected_local_audio(self):
        row = self.local_audio_table.currentRow()
        if row < 0: return
        item = self.local_audio_table.item(row, 0)
        if item: self.playback.play_local_track(int(item.data(Qt.UserRole)))

    def refresh_player_library(self):
        if hasattr(self, "local_audio_table"):
            tracks = self.playlists.list_local_audio_tracks()
            self.local_audio_table.setRowCount(len(tracks))
            for row, track in enumerate(tracks):
                for column, value in enumerate([track.title, track.artist, track.file_path]):
                    item = QTableWidgetItem(value)
                    if column == 0:
                        item.setData(Qt.UserRole, track.id)
                    self.local_audio_table.setItem(row, column, item)
        if hasattr(self, "playback_history_table"):
            history = self.playlists.playback_history(100)
            self.playback_history_table.setRowCount(len(history))
            for row, entry in enumerate(history):
                values = [entry["title"], entry["artist"], entry["source"], entry["result"], entry["ended_at"]]
                for column, value in enumerate(values):
                    self.playback_history_table.setItem(row, column, QTableWidgetItem(str(value)))

    def clear_playback_history(self):
        answer = QMessageBox.question(
            self,
            "清空最近播放记录",
            "确定清空全部最近播放记录，并删除应用媒体缓存中未受保护的缓存文件吗？\n\n"
            "不会删除导入的原始本地音频文件；当前受保护的缓存会保留。",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return
        history_count = self.playlists.clear_playback_history()
        cache_count = self.cache_manager.clear_all()
        self.database.log(
            "INFO", "player",
            f"已清空最近播放记录 {history_count} 条，并清理未受保护媒体缓存 {cache_count} 个文件。",
        )
        self.refresh_player_library()
        self._refresh_cache_stats()
        QMessageBox.information(
            self, "清理完成", f"已清空 {history_count} 条播放记录，清理 {cache_count} 个缓存文件。"
        )

    def _render_lyric_rows(self, rows):
        if not hasattr(self, "lyric_list"):
            return
        self.lyric_list.clear()
        self._lyric_rows = list(rows or [])
        self._lyric_active_index = -1
        for row in self._lyric_rows:
            text = str(row.get("text") or "").strip()
            translation = str(row.get("translation") or "").strip()
            display = text if not translation or translation == text else f"{text}\n{translation}"
            item = QListWidgetItem(display)
            item.setData(Qt.UserRole, int(row.get("time_ms") or 0))
            self.lyric_list.addItem(item)

    def _forget_lyric_worker(self, song_id: str, worker):
        if self._lyrics_workers.get(song_id) is worker:
            self._lyrics_workers.pop(song_id, None)

    def _load_current_track_lyrics(self):
        if not hasattr(self, "lyric_list"):
            return
        current = self.playback.current_track
        track = current[0] if current else None
        song_id = str(getattr(track, "external_id", "") or "").strip()
        if not song_id:
            self._lyric_song_id = ""
            self._render_lyric_rows([])
            if self.lyric_status_label:
                self.lyric_status_label.setText("当前播放不是网易云歌曲，暂时没有在线歌词来源。")
            return
        if song_id == self._lyric_song_id and self._lyric_rows:
            return
        self._lyric_song_id = song_id
        self._render_lyric_rows([])
        self.lyric_status_label.setText("正在获取歌词…")
        try:
            cookie = self.music_secret_store.load()
            if not cookie:
                raise SecretStoreError("网易云账号尚未登录。")
            self.netease_service.ensure_running()
        except Exception as exc:
            self.lyric_status_label.setText(f"歌词获取失败：{exc}")
            return
        existing_worker = self._lyrics_workers.get(song_id)
        if existing_worker is not None and existing_worker.isRunning():
            return
        worker = NeteaseLyricsWorker(cookie, song_id, self)
        self._lyrics_worker = worker
        self._lyrics_workers[song_id] = worker
        worker.loaded.connect(self._on_lyrics_loaded)
        worker.failed.connect(self._on_lyrics_failed)
        worker.finished.connect(lambda key=song_id, current_worker=worker: self._forget_lyric_worker(key, current_worker))
        worker.start()

    def _on_lyrics_loaded(self, song_id: str, rows):
        if song_id != self._lyric_song_id:
            return
        self._render_lyric_rows(rows)
        if rows:
            self.lyric_status_label.setText(f"歌词已加载 · {len(rows)} 行 · 随播放进度自动滚动")

    def _on_lyrics_failed(self, song_id: str, message: str):
        if song_id != self._lyric_song_id:
            return
        self._render_lyric_rows([])
        self.lyric_status_label.setText(f"歌词暂不可用：{message}")

    def _update_lyric_cursor(self, position_ms: int):
        if not self._lyric_rows or not hasattr(self, "lyric_list"):
            return
        active = -1
        for index, row in enumerate(self._lyric_rows):
            if int(row.get("time_ms") or 0) <= int(position_ms):
                active = index
            else:
                break
        if active == self._lyric_active_index:
            return
        self._lyric_active_index = active
        if active < 0:
            self.lyric_list.setCurrentRow(-1)
            self.lyric_list.scrollToTop()
            return
        item = self.lyric_list.item(active)
        if item is not None:
            self.lyric_list.setCurrentRow(active)
            self.lyric_list.scrollToItem(item, QAbstractItemView.PositionAtCenter)

    def _on_player_state(self, state: str, detail: str):
        if hasattr(self, "player_status_label"): self.player_status_label.setText(state)
        if hasattr(self, "player_detail_label"): self.player_detail_label.setText(detail)
        if hasattr(self, "dashboard_player_value"):
            self.dashboard_player_value.setText(detail[:22] if state == "正在播放" else "暂无播放")
        if state == "正在播放":
            self._load_current_track_lyrics()
        elif hasattr(self, "lyric_status_label") and state in {"播放完成", "主播手动跳过", "被观众点歌中断", "主播切换歌曲"}:
            self.lyric_status_label.setText("等待下一首歌曲的歌词…")
            self._render_lyric_rows([])
        if hasattr(self, "playback_history_table"):
            self.refresh_player_library()

    def _on_media_ended(self):
        self.playback.on_track_ended()

    def _on_media_error(self, message: str):
        self.playback.handle_error(message)

    def _on_media_position(self, position: int, duration: int):
        if hasattr(self, "player_position_slider"):
            self.player_position_slider.blockSignals(True); self.player_position_slider.setRange(0, max(0, duration)); self.player_position_slider.setValue(min(position, duration)); self.player_position_slider.blockSignals(False)
            self.player_position_label.setText(f"{self._format_ms(position)} / {self._format_ms(duration)}")
        self._update_lyric_cursor(position)

    @staticmethod
    def _format_ms(value: int) -> str:
        seconds = max(0, int(value // 1000)); return f"{seconds // 60:02d}:{seconds % 60:02d}"

    def closeEvent(self, event):
        workers = [worker for worker in self._remote_workers.values() if worker.isRunning()]
        workers.extend(worker for worker in self._lyrics_workers.values() if worker.isRunning())
        login_worker = self._netease_login_worker
        if (self._playlist_sync_worker is not None and self._playlist_sync_worker.isRunning()):
            QMessageBox.information(self, "同步尚未完成", "网易云歌单仍在同步。请等待同步完成后再关闭软件。")
            event.ignore()
            return
        if login_worker is not None and login_worker.isRunning():
            login_worker.cancel()
        for worker in workers:
            worker.requestInterruption()
        # Do not destroy a QThread while its blocking HTTP request is still active.
        for worker in workers + ([login_worker] if login_worker is not None else []):
            if worker is not None and worker.isRunning() and not worker.wait(9000):
                QMessageBox.information(
                    self, "网易云任务仍在运行",
                    "网易云网络请求尚未结束。请稍后再关闭软件，以避免中断中的任务造成异常。",
                )
                event.ignore()
                return
        try:
            self.open_live_client.disconnect(timeout=3.0)
        except Exception:
            pass
        try:
            self.simulated_manager.disconnect()
        except Exception:
            pass
        try:
            self.playback_timer.stop()
            self.player_backend.stop()
        except Exception:
            pass
        self.netease_service.stop()
        super().closeEvent(event)

    def system_page(self):
        widget, layout = self.scroll_page("系统设置", "BiliMusic 固定采用蓝白色 Material Design 3 浅色界面。")
        info_box, info_layout = self.section_card("运行环境", "当前版本的本地运行方式与数据存储说明。")
        for line in (
            "界面主题：蓝白色浅色模式（固定）",
            "软件版本：V0.4.38（歌单整曲播放与自动歌词）",
            "运行模式：Windows 本地桌面版",
            "数据库：SQLite（本机用户数据目录）",
            "云服务器：不需要",
            "B站凭证：仅通过 Windows DPAPI 加密存储，不写入 SQLite 或日志",
        ):
            label = QLabel("•  " + line)
            label.setObjectName("Muted")
            info_layout.addWidget(label)
        layout.addWidget(info_box)

        cache_box, cache_layout = self.section_card("音乐缓存管理", "管理应用显式登记的本地缓存文件；网易云远程音频采用流播，不会写入长期缓存。")
        cache_form = QFormLayout()
        self.cache_size_combo = QComboBox()
        for mb in CacheManager.SIZE_OPTIONS_MB:
            self.cache_size_combo.addItem(f"{mb // 1024} GB" if mb >= 1024 else f"{mb} MB", mb)
        current_size = int(self.settings.get("cache_max_mb", 512))
        self.cache_size_combo.setCurrentIndex(max(0, self.cache_size_combo.findData(current_size)))
        self.cache_interval_spin = QSpinBox(); self.cache_interval_spin.setRange(1, 30); self.cache_interval_spin.setSuffix(" 天")
        self.cache_interval_spin.setValue(int(self.settings.get("cache_cleanup_interval_days", 1)))
        self.cache_retention_spin = QSpinBox(); self.cache_retention_spin.setRange(1, 365); self.cache_retention_spin.setSuffix(" 天")
        self.cache_retention_spin.setValue(int(self.settings.get("cache_retention_days", 7)))
        cache_form.addRow("最大缓存容量", self.cache_size_combo)
        cache_form.addRow("自动检查周期", self.cache_interval_spin)
        cache_form.addRow("未使用保留期限", self.cache_retention_spin)
        cache_layout.addLayout(cache_form)
        self.cache_stats_label = QLabel(); self.cache_stats_label.setObjectName("Muted")
        cache_layout.addWidget(self.cache_stats_label)
        cache_actions = QHBoxLayout()
        save_cache_btn = QPushButton("保存设置"); save_cache_btn.setObjectName("Primary")
        save_cache_btn.clicked.connect(self._save_cache_settings)
        cleanup_cache_btn = QPushButton("立即清理")
        cleanup_cache_btn.clicked.connect(self._cleanup_cache_now)
        clear_cache_btn = QPushButton("清理全部可清理缓存")
        clear_cache_btn.clicked.connect(self._clear_cache)
        cache_actions.addWidget(save_cache_btn); cache_actions.addWidget(cleanup_cache_btn); cache_actions.addWidget(clear_cache_btn)
        cache_layout.addLayout(cache_actions)
        layout.addWidget(cache_box)
        self._refresh_cache_stats()
        layout.addStretch()
        return widget

    def _refresh_cache_stats(self):
        stats = self.cache_manager.stats()
        self.cache_stats_label.setText(f"当前占用：{stats.bytes_used / 1024 / 1024:.1f} MB / {stats.max_bytes / 1024 / 1024:.0f} MB · 文件数：{stats.files}（受保护标记的缓存项目不会被清理；云端流播不占用此缓存）")

    def _save_cache_settings(self):
        try:
            self.cache_manager.configure(max_mb=int(self.cache_size_combo.currentData()), cleanup_interval_days=self.cache_interval_spin.value(), retention_days=self.cache_retention_spin.value())
            self._refresh_cache_stats()
            QMessageBox.information(self, "缓存设置", "缓存设置已保存。")
        except Exception as exc:
            QMessageBox.warning(self, "缓存设置失败", str(exc))

    def _cleanup_cache_now(self):
        removed = self.cache_manager.cleanup_if_due(force=True)
        self._refresh_cache_stats()
        QMessageBox.information(self, "缓存清理", f"已清理 {removed} 个过期或超限缓存文件。")

    def _clear_cache(self):
        answer = QMessageBox.question(self, "清理缓存", "确定清理全部可清理缓存吗？当前播放和待播所需的受保护项目会保留。")
        if answer != QMessageBox.StandardButton.Yes:
            return
        removed = self.cache_manager.clear_all()
        self._refresh_cache_stats()
        QMessageBox.information(self, "缓存清理", f"已清理 {removed} 个缓存文件。")

