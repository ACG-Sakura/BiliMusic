import tempfile
import unittest
from pathlib import Path

from app.core.queue_service import QueueService
from app.core.settings import SettingsStore
from app.storage.database import Database
from app.integrations.bilibili.contracts import LiveMessage, BilibiliClientPlaceholder, IntegrationNotConfigured
from app.integrations.bilibili.connection import ConnectionManager, ConnectionState, SimulatedBilibiliClient
from app.integrations.bilibili.events import parse_live_message, parse_song_request
from app.integrations.bilibili.pipeline import BilibiliEventPipeline
from app.integrations.bilibili.rules import SongRequestHandler


class BilibiliIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self.tmp.name) / "test.db")
        self.db.initialize()
        self.settings = SettingsStore(self.db)
        self.queue = QueueService(self.db, self.settings)
        self.handler = SongRequestHandler(self.queue, self.settings)
        self.pipeline = BilibiliEventPipeline(self.handler, 12345)

    def tearDown(self):
        self.tmp.cleanup()

    def test_parse_danmaku_and_badge(self):
        msg = parse_live_message({"cmd": "DANMU_MSG", "uid": 1, "username": "A", "text": "点歌 夜に駆ける - YOASOBI", "fan_badge": {"name": "测试牌", "level": 5}})
        self.assertEqual(msg.message_type, "danmaku")
        self.assertEqual(msg.fan_badge_level, 5)
        self.assertEqual(parse_song_request(msg.text).artist, "YOASOBI")

    def test_non_request_is_ignored(self):
        result = self.pipeline.handle_payload({"cmd": "DANMU_MSG", "uid": 1, "text": "大家好"})
        self.assertFalse(result.accepted)
        self.assertEqual(self.queue.list_queue(), [])

    def test_normal_request_enters_queue(self):
        result = self.pipeline.handle_payload({"cmd": "DANMU_MSG", "uid": 101, "username": "观众", "text": "点歌 测试歌曲", "fan_badge_level": 3})
        self.assertTrue(result.accepted)
        self.assertEqual(self.queue.get_song(result.song_id).title, "测试歌曲")

    def test_badge_minimum_rejects_normal_user(self):
        result = self.pipeline.handle_payload({"cmd": "DANMU_MSG", "uid": 102, "text": "点歌 测试歌曲", "fan_badge_level": 0})
        self.assertFalse(result.accepted)
        self.assertIn("粉丝牌等级不足", result.reason)

    def test_guard_tier_uses_guard_priority(self):
        result = self.pipeline.handle_payload({"cmd": "DANMU_MSG", "uid": 103, "text": "点歌 舰长歌曲", "guard_level": 3})
        self.assertTrue(result.accepted)
        self.assertEqual(self.queue.get_song(result.song_id).kind, "captain")

    def test_sc_bypasses_personal_cooldown(self):
        payload = {"cmd": "SUPER_CHAT_MESSAGE", "uid": 104, "username": "SC用户", "text": "点歌 SC歌曲", "price": 30}
        first = self.pipeline.handle_payload(payload)
        second = self.pipeline.handle_payload({**payload, "text": "点歌 另一首SC歌曲"})
        self.assertTrue(first.accepted)
        self.assertTrue(second.accepted)

    def test_personal_cooldown_blocks_second_danmaku_request(self):
        payload = {"cmd": "DANMU_MSG", "uid": 105, "text": "点歌 第一首", "fan_badge_level": 2}
        self.assertTrue(self.pipeline.handle_payload(payload).accepted)
        second = self.pipeline.handle_payload({**payload, "text": "点歌 第二首"})
        self.assertFalse(second.accepted)
        self.assertIn("冷却中", second.reason)

    def test_simulator_and_connection_state(self):
        client = SimulatedBilibiliClient()
        received = []
        states = []
        manager = ConnectionManager(client, received.append, lambda state, detail: states.append(state))
        manager.connect(12345)
        client.emit(LiveMessage("danmaku", 12345, uid="1", text="测试"))
        self.assertEqual(len(received), 1)
        self.assertEqual(manager.state, ConnectionState.CONNECTED)
        manager.disconnect()
        self.assertEqual(manager.state, ConnectionState.DISCONNECTED)
        self.assertIn(ConnectionState.CONNECTED, states)

    def test_placeholder_does_not_fake_real_connection(self):
        manager = ConnectionManager(BilibiliClientPlaceholder(), lambda msg: None)
        with self.assertRaises(IntegrationNotConfigured):
            manager.connect(12345)
        self.assertEqual(manager.state, ConnectionState.DISCONNECTED)


if __name__ == "__main__":
    unittest.main()
