# BiliMusic V0.2.0 — Windows 本地桌面开发版

BiliMusic 是面向 B站主播的本地点歌桌面软件。V0.2.0 在 V0.1.4.2 已验收的蓝白色桌面界面、SQLite 数据、点歌队列和拖动排序基础上，加入了**可在桌面程序中实际操作的 B站消息模拟测试页面**。

> 重要：本版本的 B站消息测试是本地模拟，不会连接真实 B站，不会读取 Cookie、Token 或账号密码，也不会显示虚假的真实连接状态。真实接入需等待并遵循 B站批准的官方接入方式及权限。

## V0.2.0 新增内容

- 左侧导航新增「B站消息测试」页面。
- 输入测试房间号并启动/断开本地模拟连接。
- 模拟普通弹幕和 SC 付费留言。
- 配置用户昵称、UID、粉丝牌等级、普通观众/舰长/提督/总督身份及 SC 金额。
- 支持 `点歌 歌名` 和 `点歌 歌名 - 歌手` 格式。
- 模拟消息经过统一解析器、点歌规则处理器并写入原有 SQLite 队列。
- 测试结果显示受理结果、歌曲 ID 或规则拒绝原因；同时写入运行日志。
- 控制台显示本地模拟连接状态。

## 保留的 V0.1.4.2 功能

- 蓝白色 Material Design 3 风格浅色界面。
- SQLite 本地数据持久化。
- 点歌队列、手动添加、删除、上移/下移和鼠标拖动排序。
- 点歌规则、身份优先级和 SC 金额档位配置。
- 本地运行日志。

## 当前限制

- 真实 B站 WebSocket/直播消息连接尚未启用。
- 网易云音乐、QQ 音乐登录和播放尚未接入。
- 自动播放和 OBS 本地浏览器源尚未接入。
- 不提供会员状态识别，不破解会员、不绕过付费限制、不提取受保护音频。

## Windows 运行

需要 Windows 10/11 和 Python 3.11+。解压后运行 `run_windows.bat`，或执行：

```powershell
py -3 -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python main.py
```

## 运行测试

```powershell
py -3 -m pip install -r requirements-dev.txt
py -3 -m pytest -q
```

## Windows 打包

```powershell
build_windows.bat
```

输出位于 `dist\BiliMusic\BiliMusic.exe`。这是未签名的开发构建。

## 安全与平台合规

本版本不保存平台登录凭证。未来的真实连接必须采用经批准的官方接入方式；不得将 Cookie、Token 或密码写入 SQLite、普通 JSON 或日志。音乐播放仅考虑平台明确允许的登录和播放方式。
