# Changelog

## V0.2.0
- Added a dedicated B站消息测试 page to the desktop application.
- Added a local simulated-room connection workflow; simulation is clearly separated from real B站 connectivity.
- Added configurable test messages for danmaku and SC, user UID/name, fan-badge level, guard role, and SC amount.
- Connected simulated messages to the shared parser, request rules, SQLite queue, and runtime logs.
- Dashboard now reports the local simulation state; application title and package metadata identify V0.2.0.
- Real B站 transport remains disabled pending approved access and credentials.

## V0.1.4.2
- Fixed the post-drop blank/stale queue row: custom QDrag now carries a stable song ID without invoking Qt base-class source-row cleanup.
- Defer persistence and QTableWidget refresh until QDrag.exec() returns, then restore selection to the moved song.

## V0.1.4.1
- Fixed drag-and-drop queue ordering by moving songs through stable database IDs instead of Qt's native cell-level InternalMove behavior.
- A drop onto a row now inserts the dragged song at that row's position and persists the complete queue order.
- Added tests for dragging a song to the first/last position and invalid drag targets.

## V0.1.4
- Set the UI to a fixed blue-white light theme.
- Updated cooldown defaults and removed global cooldown.
- Added confirmed queue deletion and drag-and-drop ordering.
