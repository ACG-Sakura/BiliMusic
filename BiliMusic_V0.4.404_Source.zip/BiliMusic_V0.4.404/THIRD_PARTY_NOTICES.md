# Third-party references and notices

## Architecture reference

- `virtual-kori/Bili-Danmu-Songs-For-Netease` — https://github.com/virtual-kori/Bili-Danmu-Songs-For-Netease

BiliMusic V0.4.401 uses this project's documented overall design as a technical reference (local NetEase API service, QR login, search, queue, local playback and optional autoplay). BiliMusic does not copy its source files.

## Bilibili video playback architecture reference

- `7starsseeker/nekofm` — https://github.com/7starsseeker/nekofm
- Upstream license: Apache-2.0.

V0.4.402–V0.4.404 reviewed NekoFM's documented Bilibili video-audio flow: video metadata lookup, WBI-signed DASH playurl resolution, and a loopback stream proxy that injects the Bilibili Referer required for media requests. BiliMusic's Python implementation is independently written and adapted to its existing Qt Multimedia playback architecture; no NekoFM source files are copied. V0.4.404 additionally implements Bilibili's publicly documented web QR-login flow independently; no NekoFM browser-session code is copied. Consult the upstream LICENSE and NOTICE files for the original project's terms and notices.

## OBS overlay architecture reference

- `Enkianssus/AwooMusicBot` — https://github.com/Enkianssus/AwooMusicBot
- `Enkianssus/AwooMusicBot-Overlay-Default` — https://github.com/Enkianssus/AwooMusicBot-Overlay-Default

V0.4.401 reviewed the documented local read-only HTTP + WebSocket pattern and OBS browser-source integration as an architectural reference. BiliMusic's OBS server and front-end files in this release are independently implemented and do not copy the referenced repositories' source files.

## Optional user-provided font asset

The OBS page uses the system font by default. Users may select a local TTF font file from the OBS settings page. The selected font is read from its original local path and served only by the loopback OBS endpoint; it is not copied into, installed by, or redistributed with BiliMusic.

## Runtime dependency

- npm package: `@neteasecloudmusicapienhanced/api` (pinned to `4.41.1` in `netease-api/package.json`)
- Upstream repository: https://github.com/NeteaseCloudMusicApiEnhanced/api-enhanced
- Upstream license: MIT (see the upstream repository's LICENSE file for the exact notice and terms).

The npm package is a community-maintained third-party API implementation, not a NetEase official SDK. BiliMusic launches it as a local service bound to `127.0.0.1` only. The BiliMusic launcher forcibly sets `ENABLE_GENERAL_UNBLOCK=false` and `ENABLE_PROXY=false`. Do not enable those options or expose the local service to other devices.

The package's own license covers its software terms only; it does not grant music copyright, platform API authorization, account entitlements, or permission to publicly transmit music. Users must follow applicable NetEase terms and copyright requirements.

## Other dependencies

Python dependency versions and licenses are declared by their respective PyPI distributions and are installed from `requirements.txt` / `requirements-dev.txt`. Qt / PySide6 is distributed under its applicable Qt licensing terms; consult the official Qt licensing page before redistribution: https://www.qt.io/licensing/.
