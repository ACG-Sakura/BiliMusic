"""Bilibili QR login and Windows DPAPI storage for the video fallback session."""
from __future__ import annotations

import ctypes
import http.cookiejar
import json
import os
from ctypes import wintypes
from pathlib import Path
from platformdirs import user_data_dir
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qsl, quote, urlsplit
from urllib.request import HTTPCookieProcessor, Request, build_opener

from .credential_store import _DataBlob

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")
PASSPORT = "https://passport.bilibili.com"
API = "https://api.bilibili.com"


class BilibiliLoginError(RuntimeError):
    """An authentication or QR-login error from Bilibili."""


class BilibiliLoginClient:
    """Perform Bilibili's official web QR-login flow and capture returned cookies."""

    def __init__(self):
        self.cookie_jar = http.cookiejar.CookieJar()
        self.opener = build_opener(HTTPCookieProcessor(self.cookie_jar))

    def _get_json(self, url: str) -> tuple[dict, object]:
        request = Request(url, headers={
            "User-Agent": UA,
            "Referer": "https://www.bilibili.com/",
            "Accept": "application/json, text/plain, */*",
        })
        try:
            with self.opener.open(request, timeout=15) as response:
                payload = json.loads(response.read(2 * 1024 * 1024).decode("utf-8"))
                return payload, response
        except (HTTPError, URLError, TimeoutError, OSError, ValueError) as exc:
            raise BilibiliLoginError(f"B站登录接口请求失败：{exc}") from exc

    def create_qr(self) -> tuple[str, str]:
        payload, _ = self._get_json(f"{PASSPORT}/x/passport-login/web/qrcode/generate")
        if int(payload.get("code", -1)) != 0:
            raise BilibiliLoginError(
                f"无法生成B站登录二维码：{payload.get('message') or payload.get('code')}"
            )
        data = payload.get("data") or {}
        url = str(data.get("url") or "")
        key = str(data.get("qrcode_key") or "")
        if not url or not key:
            raise BilibiliLoginError("B站没有返回有效的登录二维码信息。")
        return url, key

    def poll(self, qrcode_key: str) -> tuple[str, str]:
        from urllib.parse import urlencode

        query = urlencode({"qrcode_key": qrcode_key})
        payload, _ = self._get_json(f"{PASSPORT}/x/passport-login/web/qrcode/poll?{query}")
        if int(payload.get("code", -1)) != 0:
            raise BilibiliLoginError(
                f"B站登录状态查询失败：{payload.get('message') or payload.get('code')}"
            )
        data = payload.get("data") or {}
        state = int(data.get("code", -1))
        if state == 86101:
            return "waiting", ""
        if state == 86090:
            return "scanned", ""
        if state == 86038:
            return "expired", ""
        if state != 0:
            raise BilibiliLoginError(f"B站扫码登录返回未知状态：{state}")

        # Since 2026-08, Bilibili may return a cross-domain ticket URL and set
        # the actual web cookies only when this URL is followed. The cookie jar
        # captures Set-Cookie headers without exposing them to the UI/logs.
        ticket_url = str(data.get("url") or "").strip()
        if ticket_url:
            self._get_json_or_bytes(ticket_url)

        cookies = {cookie.name: cookie.value for cookie in self.cookie_jar}
        if not cookies.get("SESSDATA") and ticket_url:
            # Backward compatibility with the older QR response that included
            # cookie values in the URL query string.
            query_values = dict(parse_qsl(urlsplit(ticket_url).query, keep_blank_values=True))
            for name in ("SESSDATA", "bili_jct", "DedeUserID", "DedeUserID__ckMd5"):
                if query_values.get(name):
                    cookies[name] = quote(query_values[name], safe="")
        sessdata = cookies.get("SESSDATA", "")
        if not sessdata:
            raise BilibiliLoginError(
                "B站已确认扫码，但没有取得 SESSDATA。请关闭窗口后重新扫码。"
            )
        # Keep the Bilibili session cookies (including device identifiers when
        # present); they are useful for the API's normal risk-control checks.
        cookie = "; ".join(f"{name}={value}" for name, value in cookies.items())
        return "authenticated", cookie

    def _get_json_or_bytes(self, url: str) -> None:
        request = Request(url, headers={
            "User-Agent": UA,
            "Referer": "https://passport.bilibili.com/",
        })
        try:
            with self.opener.open(request, timeout=15) as response:
                # The cross-domain ticket is a redirect/HTML endpoint. Consume
                # a bounded body so the opener processes all Set-Cookie headers.
                response.read(1024 * 1024)
        except (HTTPError, URLError, TimeoutError, OSError) as exc:
            raise BilibiliLoginError(f"B站登录票据确认失败：{exc}") from exc

    @staticmethod
    def verify_cookie(cookie: str) -> str:
        from urllib.request import urlopen
        request = Request(
            f"{API}/x/web-interface/nav",
            headers={"User-Agent": UA, "Referer": "https://www.bilibili.com/", "Cookie": cookie},
        )
        try:
            with urlopen(request, timeout=15) as response:
                payload = json.loads(response.read(2 * 1024 * 1024).decode("utf-8"))
        except Exception as exc:
            raise BilibiliLoginError(f"B站登录状态验证请求失败：{exc}") from exc
        data = payload.get("data") or {}
        if int(payload.get("code", -1)) != 0 or not data.get("isLogin"):
            raise BilibiliLoginError(
                f"B站登录凭证无效或已过期：{payload.get('message') or payload.get('code')}"
            )
        return str(data.get("uname") or "B站账号")


class BilibiliSessionStoreError(RuntimeError):
    pass


class WindowsBilibiliSessionStore:
    """Store the Bilibili web session encrypted with the current Windows user's DPAPI."""

    ENTROPY = b"BiliMusic.Bilibili.VideoSession.v1"

    def __init__(self, path: str | Path | None = None):
        self.path = Path(path) if path else Path(user_data_dir("BiliMusic", "BiliMusic")) / "bilibili-video-session.bin"

    @staticmethod
    def _require_windows() -> None:
        if os.name != "nt":
            raise BilibiliSessionStoreError("B站登录凭证的 DPAPI 安全存储仅支持 Windows。")

    @classmethod
    def _crypt(cls, data: bytes, decrypt: bool) -> bytes:
        cls._require_windows()
        crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        source_buf = ctypes.create_string_buffer(data)
        entropy_buf = ctypes.create_string_buffer(cls.ENTROPY)
        source = _DataBlob(len(data), ctypes.cast(source_buf, ctypes.POINTER(ctypes.c_byte)))
        entropy = _DataBlob(len(cls.ENTROPY), ctypes.cast(entropy_buf, ctypes.POINTER(ctypes.c_byte)))
        output = _DataBlob()
        if decrypt:
            crypt32.CryptUnprotectData.argtypes = [ctypes.POINTER(_DataBlob), ctypes.POINTER(wintypes.LPWSTR), ctypes.POINTER(_DataBlob), wintypes.LPVOID, wintypes.LPVOID, wintypes.DWORD, ctypes.POINTER(_DataBlob)]
            crypt32.CryptUnprotectData.restype = wintypes.BOOL
            ok = crypt32.CryptUnprotectData(ctypes.byref(source), None, ctypes.byref(entropy), None, None, 0, ctypes.byref(output))
        else:
            crypt32.CryptProtectData.argtypes = [ctypes.POINTER(_DataBlob), wintypes.LPCWSTR, ctypes.POINTER(_DataBlob), wintypes.LPVOID, wintypes.LPVOID, wintypes.DWORD, ctypes.POINTER(_DataBlob)]
            crypt32.CryptProtectData.restype = wintypes.BOOL
            ok = crypt32.CryptProtectData(ctypes.byref(source), "BiliMusic Bilibili video session", ctypes.byref(entropy), None, None, 0x1, ctypes.byref(output))
        if not ok:
            raise BilibiliSessionStoreError(f"Windows DPAPI 操作失败（错误码 {ctypes.get_last_error()}）。")
        kernel32.LocalFree.argtypes = [wintypes.HLOCAL]
        kernel32.LocalFree.restype = wintypes.HLOCAL
        try:
            return ctypes.string_at(output.pbData, output.cbData)
        finally:
            kernel32.LocalFree(ctypes.cast(output.pbData, wintypes.HLOCAL))

    def save(self, cookie: str) -> None:
        value = (cookie or "").strip()
        if not value or "SESSDATA=" not in value:
            raise ValueError("B站登录凭证无效：未包含 SESSDATA。请重新扫码登录。")
        encrypted = self._crypt(value.encode("utf-8"), False)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        temporary.write_bytes(encrypted)
        os.replace(temporary, self.path)

    def load(self) -> str | None:
        if not self.path.exists():
            return None
        try:
            return self._crypt(self.path.read_bytes(), True).decode("utf-8")
        except BilibiliSessionStoreError:
            raise
        except Exception as exc:
            raise BilibiliSessionStoreError("无法读取本机B站登录凭证，请重新扫码登录。") from exc

    def delete(self) -> None:
        self.path.unlink(missing_ok=True)
