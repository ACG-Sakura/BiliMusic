from __future__ import annotations

import hashlib
import urllib.parse

from app.integrations.music.bilibili_video import (
    BilibiliVideoClient, MIXIN_TAB, _mixin_key,
)


def test_parse_bilibili_video_refs_and_page_number():
    assert BilibiliVideoClient._parse_ref("BV1xx411c7mD") == ("BV1xx411c7mD", 1)
    assert BilibiliVideoClient._parse_ref("https://www.bilibili.com/video/BV1xx411c7mD?p=3") == ("BV1xx411c7mD", 3)
    assert BilibiliVideoClient._parse_ref("av170001 p2") == ("av170001", 2)


def test_wbi_mixin_key_uses_bilibili_permutation():
    raw = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_"
    expected = "".join(raw[i] for i in MIXIN_TAB)[:32]
    assert _mixin_key("https://i.test/" + raw[:32] + ".png", "https://i.test/" + raw[32:] + ".png") == expected


def test_wbi_url_uses_percent_encoded_spaces_and_sorted_signature(monkeypatch):
    client = BilibiliVideoClient()
    client._key = "test-mixin-key"
    client._key_at = 10**20
    monkeypatch.setattr("app.integrations.music.bilibili_video.time.time", lambda: 1700000000)
    url = client._wbi_url("https://api.bilibili.com/test", {"keyword": "hello world", "page": 1})
    query = urllib.parse.urlsplit(url).query
    assert "keyword=hello%20world" in query
    parsed = dict(urllib.parse.parse_qsl(query))
    signed = "&".join(
        f"{urllib.parse.quote(k)}={urllib.parse.quote(v)}"
        for k, v in sorted({"keyword": "hello world", "page": "1", "wts": "1700000000"}.items())
    )
    assert parsed["w_rid"] == hashlib.md5((signed + "test-mixin-key").encode()).hexdigest()


def test_local_proxy_forwards_range_and_injects_bilibili_referer():
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    from threading import Thread
    from urllib.request import Request, urlopen
    from app.integrations.music.bilibili_video import local_bilibili_stream

    seen = {}

    class Upstream(BaseHTTPRequestHandler):
        def log_message(self, *_args):
            pass
        def do_GET(self):
            seen["referer"] = self.headers.get("Referer")
            seen["range"] = self.headers.get("Range")
            body = b"0123456789"
            if self.headers.get("Range") == "bytes=2-5":
                body = body[2:6]
                self.send_response(206)
                self.send_header("Content-Range", "bytes 2-5/10")
            else:
                self.send_response(200)
            self.send_header("Content-Type", "audio/mp4")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Accept-Ranges", "bytes")
            self.end_headers()
            self.wfile.write(body)

    upstream = ThreadingHTTPServer(("127.0.0.1", 0), Upstream)
    thread = Thread(target=upstream.serve_forever, daemon=True)
    thread.start()
    try:
        local = local_bilibili_stream(f"http://127.0.0.1:{upstream.server_address[1]}/audio")
        req = Request(local, headers={"Range": "bytes=2-5"})
        with urlopen(req, timeout=5) as response:
            assert response.status == 206
            assert response.read() == b"2345"
        assert seen["referer"] == "https://www.bilibili.com/"
        assert seen["range"] == "bytes=2-5"
    finally:
        upstream.shutdown()
        upstream.server_close()


def test_bilibili_api_error_preserves_login_required_code(monkeypatch):
    from app.integrations.music import bilibili_video as module
    from app.integrations.music.bilibili_video import BilibiliApiError

    monkeypatch.setattr(module, "_request", lambda *_a, **_k: '{"code":-101,"message":"账号未登录"}'.encode('utf-8'))
    try:
        module._json("https://api.bilibili.com/test")
    except BilibiliApiError as exc:
        assert exc.code == -101
        assert "账号未登录" in str(exc)
    else:
        raise AssertionError("expected a structured Bilibili login-required error")


def test_bilibili_resolver_skips_login_gated_first_result(monkeypatch):
    from app.integrations.music import bilibili_video as module
    from app.integrations.music.bilibili_video import BilibiliApiError, BilibiliVideoClient

    client = BilibiliVideoClient()
    monkeypatch.setattr(client, "_wbi_url", lambda base, params: base + "?signed=1")
    monkeypatch.setattr(module, "_json", lambda *_a, **_k: {
        "result": [
            {"bvid": "BV0000000001", "title": "first locked result"},
            {"bvid": "BV0000000002", "title": "second public result"},
        ]
    })
    monkeypatch.setattr(client, "_video_info", lambda bvid: {
        "bvid": bvid, "cid": 123, "title": "resolved " + bvid, "artist": "artist",
    })

    attempted = []

    def playurl(bvid, cid):
        attempted.append(bvid)
        if bvid.endswith("1"):
            raise BilibiliApiError(-101, "账号未登录")
        return "https://cdn.example/audio.m4s"

    monkeypatch.setattr(client, "_playurl", playurl)
    stream, title, artist = client.resolve("song", "artist")
    assert attempted == ["BV0000000001", "BV0000000002"]
    assert stream == "https://cdn.example/audio.m4s"
    assert title == "resolved BV0000000002"
    assert artist == "artist"


def test_bilibili_resolver_explains_when_all_candidates_require_login(monkeypatch):
    from app.integrations.music import bilibili_video as module
    from app.integrations.music.bilibili_video import BilibiliApiError, BilibiliVideoClient

    client = BilibiliVideoClient()
    monkeypatch.setattr(client, "_wbi_url", lambda base, params: base + "?signed=1")
    monkeypatch.setattr(module, "_json", lambda *_a, **_k: {
        "result": [{"bvid": f"BV000000000{i}"} for i in range(1, 4)]
    })
    monkeypatch.setattr(client, "_video_info", lambda bvid: {
        "bvid": bvid, "cid": 123, "title": "locked", "artist": "artist",
    })
    monkeypatch.setattr(client, "_playurl", lambda *_a: (_ for _ in ()).throw(
        BilibiliApiError(-101, "账号未登录")
    ))

    try:
        client.resolve("song", "artist")
    except RuntimeError as exc:
        assert "3 个候选视频均要求登录" in str(exc)
        assert "扫码登录B站视频备用源账号" in str(exc)
    else:
        raise AssertionError("expected a clear login-required message")


def test_bilibili_search_login_error_points_to_account_page(monkeypatch):
    from app.integrations.music import bilibili_video as module
    from app.integrations.music.bilibili_video import BilibiliApiError, BilibiliVideoClient

    client = BilibiliVideoClient()
    monkeypatch.setattr(client, "_wbi_url", lambda base, params: base + "?signed=1")
    monkeypatch.setattr(module, "_json", lambda *_a, **_k: (_ for _ in ()).throw(
        BilibiliApiError(-101, "账号未登录")
    ))
    try:
        client.resolve("song", "artist")
    except RuntimeError as exc:
        assert "B站搜索接口要求登录" in str(exc)
        assert "账号与平台" in str(exc)
    else:
        raise AssertionError("expected a clear Bilibili search-login message")
