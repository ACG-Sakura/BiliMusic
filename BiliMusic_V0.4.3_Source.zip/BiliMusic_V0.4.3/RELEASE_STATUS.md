# V0.4.3 Release Status

## Implemented in source
- QQ Music client and UI removed; NetEase Cloud Music is the sole music provider.
- NetEase QR login worker and Windows DPAPI session storage.
- Third-party NetEase local API launcher bound to `127.0.0.1` only.
- General-unblock and proxy modes are forcibly disabled by the bundled launcher.
- Playlist metadata and track IDs are synced into SQLite; temporary media URLs are not persisted.
- Remote stream playback path is connected to the Qt Multimedia backend.
- Audience request queue interrupts autoplay and resumes the active playlist after the request queue empties.
- Failed request / preview-only / unavailable stream paths are marked skipped and advance the queue.
- V0.4.2 cache configuration and generic cache manager retained. NetEase streams are not written into long-term media cache; the cache manager currently does not manage cloud tracks.

## Important dependency boundary
- `@neteasecloudmusicapienhanced/api` is a community-maintained third-party package, not a NetEase official desktop SDK.
- Its API compatibility, account login, stream resolution, and track availability depend on the upstream package and NetEase service behavior.
- This application does not enable generic track-unblock or proxy features and does not decrypt protected media.
- A NetEase membership does not itself establish permission to rebroadcast music in a livestream.

## Verification
- `pytest -q`: 66 passed.
- `python -m compileall -q app tests main.py`: passed.
- `node --check netease-api/server.js`: passed.
- npm dependency installation could not be completed in this environment because the registry request timed out; therefore the local API runtime was not started here.
- PySide6 is not installed in this development environment, so the desktop GUI was not launched.
- No real NetEase account QR login, real member-track playback, Windows EXE build, Windows GUI acceptance, or OBS live test has been performed.
