@echo off
setlocal EnableExtensions
cd /d "%~dp0"

if not exist .venv\Scripts\python.exe (
  echo Please run run_windows.bat once to create the Python virtual environment.
  pause
  exit /b 1
)
call .venv\Scripts\activate.bat

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 22 or later is required to package the local NetEase API service.
  echo Install Node.js 22+, then run this build script again.
  pause
  exit /b 1
)
node -e "if (Number(process.versions.node.split('.')[0]) < 22) process.exit(1)" >nul 2>nul
if errorlevel 1 (
  echo Node.js 22 or later is required to package the local NetEase API service.
  pause
  exit /b 1
)

python -m pip install --upgrade pip
if errorlevel 1 goto :error
pip install -r requirements-dev.txt
if errorlevel 1 goto :error

if not exist netease-api\package.json (
  echo Missing netease-api\package.json. The source archive may be incomplete.
  goto :error
)
pushd netease-api
npm install --omit=dev --no-audit --no-fund
if errorlevel 1 (
  popd
  goto :error
)
popd
if not exist netease-api\node_modules\@neteasecloudmusicapienhanced\api\package.json (
  echo NetEase API dependency was not installed correctly.
  goto :error
)
if not exist netease-api\runtime mkdir netease-api\runtime
for /f "delims=" %%N in ('where node') do if not defined NODE_EXE set "NODE_EXE=%%N"
if not defined NODE_EXE goto :error
copy /y "%NODE_EXE%" "netease-api\runtime\node.exe" >nul
if errorlevel 1 goto :error

pytest -q
if errorlevel 1 goto :error
python -m compileall -q app tests main.py
if errorlevel 1 goto :error
pyinstaller --noconfirm --clean --windowed --onedir --name BiliMusic --collect-all PySide6 --collect-all websockets --add-data "netease-api;netease-api" --add-data "app\integrations\obs\web;app\integrations\obs\web" main.py
if errorlevel 1 goto :error
if not exist "dist\BiliMusic\_internal\netease-api\server.js" (
  echo Bundled NetEase API files were not found under dist\BiliMusic\_internal.
  goto :error
)
if not exist "dist\BiliMusic\_internal\netease-api\runtime\node.exe" (
  echo Bundled Node.js runtime was not found.
  goto :error
)

echo.
echo Build complete: dist\BiliMusic\BiliMusic.exe
echo The local NetEase API and Node runtime are bundled in the output folder.
echo Note: real NetEase login/playback and Windows acceptance must still be tested.
pause
exit /b 0

:error
echo.
echo Build failed. See the error message above.
pause
exit /b 1
