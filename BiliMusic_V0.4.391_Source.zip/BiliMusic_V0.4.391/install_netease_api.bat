@echo off
setlocal
cd /d "%~dp0netease-api"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 22 or later was not found. Install Node.js, then run this script again.
  pause
  exit /b 1
)
node -e "const major=Number(process.versions.node.split('.')[0]); if(major<22) process.exit(1)" >nul 2>nul
if errorlevel 1 (
  echo Node.js 22 or later is required by the current NetEase API package.
  pause
  exit /b 1
)
npm install --omit=dev --no-audit --no-fund
if errorlevel 1 goto :error
echo.
echo NetEase local API dependencies installed.
pause
exit /b 0
:error
echo Dependency installation failed. Check the network and npm output above.
pause
exit /b 1
