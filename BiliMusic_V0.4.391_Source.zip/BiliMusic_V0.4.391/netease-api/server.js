'use strict'

// Local NetEase API bootstrap for BiliMusic.
// The service deliberately listens on 127.0.0.1 only. Features that attempt
// generic track unlocking or third-party proxying are hard-disabled.
const path = require('path')
const packageRoot = path.dirname(
  require.resolve('@neteasecloudmusicapienhanced/api/package.json')
)
const generateConfig = require(path.join(packageRoot, 'generateConfig.js'))
const { serveNcmApi } = require(path.join(packageRoot, 'server.js'))

const port = Number(process.env.BILIMUSIC_NCM_PORT || 3000)
process.env.HOST = '127.0.0.1'
process.env.ENABLE_GENERAL_UNBLOCK = 'false'
process.env.ENABLE_PROXY = 'false'

async function main() {
  // Anonymous token/key bootstrap is used by the API package itself. Login and
  // playback still use the session that the user explicitly authorizes by QR.
  try {
    await generateConfig()
  } catch (error) {
    console.warn('[BiliMusic] NetEase optional initialization failed:',
      error && error.message ? error.message : error)
  }
  await serveNcmApi({ port, host: '127.0.0.1', checkVersion: false })
}

main().catch((error) => {
  console.error('[BiliMusic] NetEase local service failed to start:',
    error && error.message ? error.message : error)
  process.exit(1)
})
