"""Map official Open Platform event envelopes to BiliMusic's common LiveMessage."""
from __future__ import annotations

from typing import Any, Mapping

from app.integrations.bilibili.contracts import LiveMessage


def map_open_live_event(payload: Mapping[str, Any], room_id: int) -> LiveMessage:
    cmd = str(payload.get("cmd") or payload.get("message_type") or "unknown").upper()
    data = payload.get("data") if isinstance(payload.get("data"), Mapping) else {}
    user = data.get("user_info") if isinstance(data.get("user_info"), Mapping) else {}
    # Open Platform identifiers are app-scoped open_id values, not numeric B站 UIDs.
    open_id = data.get("open_id") or user.get("open_id") or data.get("uid") or user.get("uid") or ""
    uname = data.get("uname") or user.get("uname") or data.get("username") or user.get("name") or ""
    badge = data.get("fans_medal") if isinstance(data.get("fans_medal"), Mapping) else {}
    badge_level = data.get("fans_medal_level", badge.get("level", 0))
    badge_name = data.get("fans_medal_name", badge.get("name", ""))

    message_type = {
        "LIVE_OPEN_PLATFORM_DM": "danmaku",
        "LIVE_OPEN_PLATFORM_SUPER_CHAT": "sc",
        "LIVE_OPEN_PLATFORM_GUARD": "guard",
        "LIVE_OPEN_PLATFORM_SEND_GIFT": "gift",
        "LIVE_OPEN_PLATFORM_LIKE": "like",
        "LIVE_OPEN_PLATFORM_LIVE_ROOM_ENTER": "interaction",
        "LIVE_OPEN_PLATFORM_LIVE_START": "live",
        "LIVE_OPEN_PLATFORM_LIVE_END": "preparing",
    }.get(cmd, cmd.lower())

    text = ""
    sc_amount = 0.0
    if message_type == "danmaku":
        text = str(data.get("msg") or data.get("message") or "")
    elif message_type == "sc":
        text = str(data.get("message") or data.get("msg") or "")
        try:
            sc_amount = max(0.0, float(data.get("rmb") or data.get("price") or 0))
        except (TypeError, ValueError):
            sc_amount = 0.0

    try:
        guard_level = int(data.get("guard_level", user.get("guard_level", 0)) or 0)
        badge_level = int(badge_level or 0)
    except (TypeError, ValueError):
        guard_level, badge_level = 0, 0

    return LiveMessage(
        message_type=message_type,
        room_id=int(room_id),
        uid=str(open_id),
        username=str(uname),
        text=text,
        fan_badge_name=str(badge_name or ""),
        fan_badge_level=max(0, badge_level),
        guard_level=guard_level if guard_level in (0, 1, 2, 3) else 0,
        sc_amount=sc_amount,
    )
