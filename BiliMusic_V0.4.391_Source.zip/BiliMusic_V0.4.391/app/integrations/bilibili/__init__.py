"""Bilibili integration boundary."""
