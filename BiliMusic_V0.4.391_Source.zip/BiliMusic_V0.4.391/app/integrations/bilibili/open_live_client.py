"""Background-thread transport for the official Bilibili Open Live stream."""
from __future__ import annotations

import json
import threading
import time
from typing import Callable

import websocket

from app.integrations.bilibili.contracts import LiveMessage
from app.integrations.bilibili.open_live_api import (
    BilibiliOpenLiveApi, OpenLiveCredentials, OpenLiveSession,
)
from app.integrations.bilibili.open_live_events import map_open_live_event
from app.integrations.bilibili.open_live_protocol import (
    OP_AUTH, OP_AUTH_REPLY, OP_HEARTBEAT, OP_MESSAGE,
    decode_json_body, pack_packet, unpack_packets,
)

StateCallback = Callable[[str, str], None]
MessageCallback = Callable[[LiveMessage], None]


class OfficialBilibiliOpenLiveClient:
    """Starts/stops official Open Platform sessions without blocking the Qt UI."""

    def __init__(self, on_message: MessageCallback, on_state: StateCallback):
        self.on_message = on_message
        self.on_state = on_state
        self._stop = threading.Event()
        self._heartbeat_stop = threading.Event()
        self._heartbeat_thread: threading.Thread | None = None
        self._thread: threading.Thread | None = None
        self._socket = None
        self._api: BilibiliOpenLiveApi | None = None
        self._session: OpenLiveSession | None = None
        self._lock = threading.RLock()
        self._connected = False
        self._connecting = False

    @property
    def is_connected(self) -> bool:
        with self._lock:
            return self._connected

    @property
    def is_running(self) -> bool:
        with self._lock:
            return self._connecting or self._connected

    def connect(self, credentials: OpenLiveCredentials) -> None:
        credentials.validate()
        with self._lock:
            if self._thread and self._thread.is_alive():
                raise RuntimeError("B站官方连接正在运行")
            self._stop.clear()
            self._heartbeat_stop.clear()
            self._connected = False
            self._connecting = True
            self.on_state("connecting", "正在请求 B站开放平台启动会话")
            self._thread = threading.Thread(
                target=self._run, args=(credentials,), name="BiliMusic-OpenLive", daemon=True,
            )
            self._thread.start()

    def disconnect(self, timeout: float = 5.0) -> None:
        self._stop.set()
        with self._lock:
            current_socket = self._socket
            thread = self._thread
        if current_socket is not None:
            try:
                current_socket.close()
            except Exception:
                pass
        if thread and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=max(0.1, timeout))
        with self._lock:
            self._connected = False
            self._connecting = False
        self.on_state("disconnected", "已请求断开 B站官方连接")

    def _run(self, credentials: OpenLiveCredentials) -> None:
        session = None
        api = BilibiliOpenLiveApi(credentials)
        self._api = api
        try:
            session = api.start()
            self._session = session
            self.on_state("connecting", f"已取得会话，正在连接直播间 {session.room_id}")
            self._heartbeat_thread = threading.Thread(
                target=self._project_heartbeat_loop, args=(api, session),
                name="BiliMusic-OpenLive-Heartbeat", daemon=True,
            )
            self._heartbeat_thread.start()
            errors: list[str] = []
            for url in session.websocket_urls:
                if self._stop.is_set():
                    break
                try:
                    self._run_socket(url, session)
                    if self._stop.is_set():
                        break
                    errors.append("长连接意外结束")
                except Exception as exc:
                    # Error text is sanitized by avoiding raw headers/auth_body.
                    errors.append(str(exc)[:180])
                    self.on_state("reconnecting", "当前长连接不可用，尝试官方返回的备用节点")
            if not self._stop.is_set():
                raise RuntimeError("；".join(errors) or "所有官方长连接节点均不可用")
        except Exception as exc:
            self.on_state("error", str(exc))
        finally:
            self._heartbeat_stop.set()
            heartbeat_thread = self._heartbeat_thread
            if heartbeat_thread and heartbeat_thread.is_alive() and heartbeat_thread is not threading.current_thread():
                heartbeat_thread.join(timeout=1.5)
            self._heartbeat_thread = None
            with self._lock:
                self._connected = False
                self._connecting = False
                self._socket = None
            if session is not None:
                try:
                    api.end(session.app_id, session.game_id)
                except Exception as exc:
                    self.on_state("warning", f"关闭官方会话失败：{exc}")
            self._session = None
            if self._stop.is_set():
                self.on_state("disconnected", "官方会话已停止")

    def _project_heartbeat_loop(self, api: BilibiliOpenLiveApi, session: OpenLiveSession) -> None:
        # The project heartbeat runs separately so a slow HTTP request cannot delay
        # the websocket's 30-second transport heartbeat.
        while not self._heartbeat_stop.wait(20.0):
            if self._stop.is_set():
                return
            try:
                api.heartbeat(session.game_id)
            except Exception as exc:
                self.on_state("warning", f"项目心跳失败，正在安全结束连接：{exc}")
                self._stop.set()
                with self._lock:
                    sock = self._socket
                if sock is not None:
                    try:
                        sock.close()
                    except Exception:
                        pass
                return

    def _run_socket(self, url: str, session: OpenLiveSession) -> None:
        ws = websocket.create_connection(url, timeout=1.0, enable_multithread=True)
        with self._lock:
            self._socket = ws
        try:
            ws.send_binary(pack_packet(OP_AUTH, session.auth_body, version=0))
            auth_deadline = time.monotonic() + 12.0
            last_ws_heartbeat = time.monotonic()
            authenticated = False
            while not self._stop.is_set():
                now = time.monotonic()
                if now - last_ws_heartbeat >= 20:
                    ws.send_binary(pack_packet(OP_HEARTBEAT, b"", version=0))
                    last_ws_heartbeat = now
                try:
                    raw = ws.recv()
                except websocket.WebSocketTimeoutException:
                    if not authenticated and time.monotonic() > auth_deadline:
                        raise RuntimeError("等待 B站长连接鉴权响应超时")
                    continue
                if raw is None:
                    raise RuntimeError("B站长连接已关闭")
                if isinstance(raw, str):
                    raw = raw.encode("utf-8")
                for packet in unpack_packets(bytes(raw)):
                    if packet.operation == OP_AUTH_REPLY:
                        reply = decode_json_body(packet) if packet.body else {"code": 0}
                        if int(reply.get("code", 0)) != 0:
                            raise RuntimeError(f"B站长连接鉴权失败：{reply.get('message', reply.get('code'))}")
                        if not authenticated:
                            authenticated = True
                            with self._lock:
                                self._connected = True
                                self._connecting = False
                            self.on_state("connected", f"已连接官方直播间 {session.room_id}")
                    elif packet.operation == OP_MESSAGE:
                        event = decode_json_body(packet)
                        message = map_open_live_event(event, session.room_id)
                        self.on_message(message)

        finally:
            with self._lock:
                self._socket = None
                self._connected = False
            try:
                ws.close()
            except Exception:
                pass
