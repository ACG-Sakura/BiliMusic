"""Windows DPAPI-backed storage for Bilibili Open Platform credentials."""
from __future__ import annotations

import ctypes
import json
import os
from ctypes import wintypes
from pathlib import Path
from typing import Mapping

from platformdirs import user_data_dir


class CredentialStoreError(RuntimeError):
    pass


class _DataBlob(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]


def _json_bytes(credentials: Mapping[str, str]) -> bytes:
    allowed = {"app_id", "access_key", "access_secret", "auth_code"}
    if set(credentials) != allowed:
        raise ValueError("凭证字段不完整或包含未知字段")
    return json.dumps(dict(credentials), ensure_ascii=False, separators=(",", ":")).encode("utf-8")


class WindowsCredentialStore:
    """Encrypt the full credential object with the current Windows user's DPAPI."""

    ENTROPY = b"BiliMusic.OpenLive.Credentials.v1"

    def __init__(self, path: str | Path | None = None):
        self.path = Path(path) if path else Path(user_data_dir("BiliMusic", "BiliMusic")) / "openlive.bin"

    @staticmethod
    def _require_windows() -> None:
        if os.name != "nt":
            raise CredentialStoreError("官方凭证安全存储仅在 Windows 上可用；本机模拟测试不受影响")

    @classmethod
    def _protect(cls, clear: bytes) -> bytes:
        cls._require_windows()
        crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        crypt32.CryptProtectData.argtypes = [ctypes.POINTER(_DataBlob), wintypes.LPCWSTR,
            ctypes.POINTER(_DataBlob), wintypes.LPVOID, wintypes.LPVOID, wintypes.DWORD,
            ctypes.POINTER(_DataBlob)]
        crypt32.CryptProtectData.restype = wintypes.BOOL
        kernel32.LocalFree.argtypes = [wintypes.HLOCAL]
        kernel32.LocalFree.restype = wintypes.HLOCAL
        source_buf = ctypes.create_string_buffer(clear)
        entropy_buf = ctypes.create_string_buffer(cls.ENTROPY)
        source = _DataBlob(len(clear), ctypes.cast(source_buf, ctypes.POINTER(ctypes.c_byte)))
        entropy = _DataBlob(len(cls.ENTROPY), ctypes.cast(entropy_buf, ctypes.POINTER(ctypes.c_byte)))
        output = _DataBlob()
        if not crypt32.CryptProtectData(
            ctypes.byref(source), "BiliMusic OpenLive credentials", ctypes.byref(entropy),
            None, None, 0x1, ctypes.byref(output),
        ):
            raise CredentialStoreError(f"Windows 凭据加密失败（错误码 {ctypes.get_last_error()}）")
        try:
            return ctypes.string_at(output.pbData, output.cbData)
        finally:
            kernel32.LocalFree(ctypes.cast(output.pbData, wintypes.HLOCAL))

    @classmethod
    def _unprotect(cls, encrypted: bytes) -> bytes:
        cls._require_windows()
        crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        crypt32.CryptUnprotectData.argtypes = [ctypes.POINTER(_DataBlob),
            ctypes.POINTER(wintypes.LPWSTR), ctypes.POINTER(_DataBlob), wintypes.LPVOID,
            wintypes.LPVOID, wintypes.DWORD, ctypes.POINTER(_DataBlob)]
        crypt32.CryptUnprotectData.restype = wintypes.BOOL
        kernel32.LocalFree.argtypes = [wintypes.HLOCAL]
        kernel32.LocalFree.restype = wintypes.HLOCAL
        source_buf = ctypes.create_string_buffer(encrypted)
        entropy_buf = ctypes.create_string_buffer(cls.ENTROPY)
        source = _DataBlob(len(encrypted), ctypes.cast(source_buf, ctypes.POINTER(ctypes.c_byte)))
        entropy = _DataBlob(len(cls.ENTROPY), ctypes.cast(entropy_buf, ctypes.POINTER(ctypes.c_byte)))
        output = _DataBlob()
        if not crypt32.CryptUnprotectData(
            ctypes.byref(source), None, ctypes.byref(entropy), None, None, 0x1, ctypes.byref(output),
        ):
            raise CredentialStoreError(f"Windows 凭据解密失败（错误码 {ctypes.get_last_error()}）")
        try:
            return ctypes.string_at(output.pbData, output.cbData)
        finally:
            kernel32.LocalFree(ctypes.cast(output.pbData, wintypes.HLOCAL))

    def save(self, credentials: Mapping[str, str]) -> None:
        encrypted = self._protect(_json_bytes(credentials))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        temporary.write_bytes(encrypted)
        os.replace(temporary, self.path)

    def load(self) -> dict[str, str] | None:
        if not self.path.exists():
            return None
        try:
            value = json.loads(self._unprotect(self.path.read_bytes()).decode("utf-8"))
        except CredentialStoreError:
            raise
        except Exception as exc:
            raise CredentialStoreError("无法读取已保存的官方凭证；请重新保存") from exc
        if not isinstance(value, dict):
            raise CredentialStoreError("本地凭证文件格式不正确")
        return {key: str(value.get(key, "")) for key in ("app_id", "access_key", "access_secret", "auth_code")}

    def delete(self) -> None:
        try:
            self.path.unlink(missing_ok=True)
        except OSError as exc:
            raise CredentialStoreError("无法删除本地加密凭证") from exc
