"""Glue between incoming live events and the existing queue/rule services."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from app.integrations.bilibili.events import parse_live_message
from app.integrations.bilibili.rules import RequestRejected, SongRequestHandler


@dataclass(frozen=True, slots=True)
class EventResult:
    message_type: str
    accepted: bool
    song_id: int | None = None
    reason: str = ""


class BilibiliEventPipeline:
    def __init__(self, handler: SongRequestHandler, default_room_id: int = 0):
        self.handler = handler
        self.default_room_id = int(default_room_id)

    def handle_payload(self, payload: Mapping[str, Any]) -> EventResult:
        message = parse_live_message(payload, self.default_room_id)
        try:
            song_id = self.handler.handle(message)
            return EventResult(message.message_type, song_id is not None, song_id)
        except RequestRejected as exc:
            self.handler.queue.database.log("WARNING", "bilibili", f"点歌被规则拒绝：{exc}")
            return EventResult(message.message_type, False, None, str(exc))
        except Exception as exc:
            self.handler.queue.database.log("ERROR", "bilibili", f"处理直播消息失败：{exc}")
            return EventResult(message.message_type, False, None, "消息处理异常，请查看运行日志")
