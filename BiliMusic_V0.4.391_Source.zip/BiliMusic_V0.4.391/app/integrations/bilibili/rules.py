"""Song-request policy layer shared by simulated and future authorized events."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from app.core.queue_service import QueueService
from app.core.settings import SettingsStore
from app.integrations.bilibili.contracts import LiveMessage
from app.integrations.bilibili.events import parse_song_request


class RequestRejected(ValueError):
    pass


class SongRequestHandler:
    def __init__(self, queue: QueueService, settings: SettingsStore):
        self.queue = queue
        self.settings = settings

    def handle(self, message: LiveMessage) -> int | None:
        if message.message_type not in {"danmaku", "sc"}:
            return None
        parsed = parse_song_request(message.text, str(self.settings.get("request_command", "点歌")))
        if parsed is None:
            return None
        if not message.uid:
            raise RequestRejected("缺少用户 UID，无法执行个人点歌规则")
        kind = self._kind(message)
        self._validate(message, parsed.title, kind)
        song_id = self.queue.enqueue(
            parsed.title, parsed.artist, message.username or f"用户 {message.uid}",
            message.uid, source="bilibili_sc" if message.message_type == "sc" else "bilibili",
            kind=kind, sc_amount=message.sc_amount,
        )
        self.queue.database.log("INFO", "bilibili", f"{message.username or message.uid} 点歌成功：{parsed.title}")
        return song_id

    @staticmethod
    def _kind(message: LiveMessage) -> str:
        if message.message_type == "sc":
            return "sc"
        # Bilibili guard level: 1 governor, 2 admiral, 3 captain.
        return {1: "governor", 2: "admiral", 3: "captain"}.get(message.guard_level, "normal")

    def _validate(self, message: LiveMessage, title: str, kind: str) -> None:
        db = self.queue.database
        is_sc = message.message_type == "sc"
        if not is_sc:
            minimum = int(self.settings.get("min_fan_badge_level", 1))
            if message.fan_badge_level < minimum and kind == "normal":
                raise RequestRejected(f"粉丝牌等级不足，至少需要 {minimum} 级")
        queue_limit = int(self.settings.get("queue_limit_per_user", 2))
        queued = db.fetchone("SELECT COUNT(*) AS n FROM songs WHERE requester_uid=? AND status IN ('queued','playing')", (message.uid,))["n"]
        if queued >= queue_limit:
            raise RequestRejected("已达到个人待播歌曲上限")
        duplicate_minutes = max(0, int(self.settings.get("duplicate_cooldown_minutes", 60)))
        if duplicate_minutes:
            cutoff = (datetime.now(timezone.utc) - timedelta(minutes=duplicate_minutes)).isoformat(timespec="milliseconds").replace("+00:00", "Z")
            duplicate = db.fetchone("SELECT 1 FROM songs WHERE lower(title)=lower(?) AND created_at>=? AND status!='cancelled' LIMIT 1", (title, cutoff))
            if duplicate:
                raise RequestRejected("这首歌曲仍在重复点歌冷却时间内")
        if is_sc:
            return
        cooldown_key = "captain_cooldown_seconds" if kind in {"captain", "admiral", "governor"} else "normal_badge_cooldown_seconds"
        cooldown = max(0, int(self.settings.get(cooldown_key, 180 if cooldown_key.startswith("captain") else 300)))
        daily_limit = max(0, int(self.settings.get("daily_limit", 2)))
        now = datetime.now(timezone.utc)
        day_start = now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat(timespec="milliseconds").replace("+00:00", "Z")
        if daily_limit:
            count = db.fetchone("SELECT COUNT(*) AS n FROM songs WHERE requester_uid=? AND source='bilibili' AND created_at>=? AND status!='cancelled'", (message.uid, day_start))["n"]
            if count >= daily_limit:
                raise RequestRejected("今日点歌次数已用完")
        if cooldown:
            last = db.fetchone("SELECT created_at FROM songs WHERE requester_uid=? AND source='bilibili' AND created_at>=? AND status!='cancelled' ORDER BY created_at DESC LIMIT 1", (message.uid, (now - timedelta(seconds=cooldown)).isoformat(timespec="milliseconds").replace("+00:00", "Z")))
            if last:
                raise RequestRejected(f"个人冷却中，请等待（冷却 {cooldown} 秒）")
