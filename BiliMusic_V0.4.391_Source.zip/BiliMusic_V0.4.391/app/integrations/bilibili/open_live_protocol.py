"""Binary websocket framing used by the Bilibili live Open Platform stream."""
from __future__ import annotations

import json
import struct
import zlib
from dataclasses import dataclass
from typing import Iterator

HEADER_SIZE = 16
MAX_PACKET_SIZE = 8 * 1024 * 1024
OP_HEARTBEAT = 2
OP_HEARTBEAT_REPLY = 3
OP_MESSAGE = 5
OP_AUTH = 7
OP_AUTH_REPLY = 8


class ProtocolError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class OpenLivePacket:
    version: int
    operation: int
    sequence: int
    body: bytes


def pack_packet(operation: int, body: bytes = b"", version: int = 0, sequence: int = 1) -> bytes:
    body = bytes(body)
    length = HEADER_SIZE + len(body)
    if length > MAX_PACKET_SIZE:
        raise ProtocolError("发送的数据包过大")
    return struct.pack(">IHHII", length, HEADER_SIZE, int(version), int(operation), int(sequence)) + body


def unpack_packets(data: bytes, _depth: int = 0) -> Iterator[OpenLivePacket]:
    """Decode one or more packets; version 2 payloads are zlib-compressed packets."""
    if _depth > 4:
        raise ProtocolError("协议压缩嵌套层数超出限制")
    offset = 0
    while offset < len(data):
        if len(data) - offset < HEADER_SIZE:
            raise ProtocolError("数据包头不完整")
        packet_len, header_len, version, operation, sequence = struct.unpack(">IHHII", data[offset:offset + HEADER_SIZE])
        if header_len < HEADER_SIZE or packet_len < header_len or packet_len > MAX_PACKET_SIZE:
            raise ProtocolError("数据包长度字段无效")
        end = offset + packet_len
        if end > len(data):
            raise ProtocolError("数据包内容不完整")
        body = data[offset + header_len:end]
        if version == 2:
            try:
                decompressor = zlib.decompressobj()
                inflated = decompressor.decompress(body, MAX_PACKET_SIZE + 1)
                if len(inflated) > MAX_PACKET_SIZE or decompressor.unconsumed_tail or not decompressor.eof:
                    raise ProtocolError("解压后的服务端消息超出大小限制或不完整")
            except zlib.error as exc:
                raise ProtocolError("无法解压服务端消息") from exc
            yield from unpack_packets(inflated, _depth + 1)
        elif version in (0, 1):
            yield OpenLivePacket(version, operation, sequence, body)
        else:
            raise ProtocolError(f"暂不支持服务端压缩版本 {version}")
        offset = end


def decode_json_body(packet: OpenLivePacket) -> dict:
    try:
        value = json.loads(packet.body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ProtocolError("服务端消息不是有效 JSON") from exc
    if not isinstance(value, dict):
        raise ProtocolError("服务端消息 JSON 根节点不是对象")
    return value
