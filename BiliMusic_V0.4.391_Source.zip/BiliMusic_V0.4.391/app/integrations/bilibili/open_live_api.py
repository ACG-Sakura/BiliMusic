"""Official Bilibili Live Open Platform REST client.

Implements the documented /v2/app/start, /v2/app/heartbeat and /v2/app/end
lifecycle. Credentials are supplied at runtime and must not be logged.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import time
from dataclasses import dataclass
from typing import Any, Callable
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


DEFAULT_API_BASE = "https://live-open.biliapi.com"


class OpenLiveApiError(RuntimeError):
    """A sanitized Open Platform API or transport error."""


@dataclass(frozen=True, slots=True)
class OpenLiveCredentials:
    app_id: int
    access_key: str
    access_secret: str
    auth_code: str

    def validate(self) -> None:
        if not (1 <= int(self.app_id) <= 9_223_372_036_854_775_807):
            raise ValueError("app_id 必须是有效的正 int64 项目 ID")
        if not self.access_key.strip():
            raise ValueError("access_key 不能为空")
        if not self.access_secret:
            raise ValueError("access_secret 不能为空")
        if not self.auth_code.strip():
            raise ValueError("主播身份码不能为空")


@dataclass(frozen=True, slots=True)
class OpenLiveSession:
    app_id: int
    game_id: str
    room_id: int
    websocket_urls: tuple[str, ...]
    auth_body: bytes
    anchor_name: str = ""
    anchor_uid: str = ""


class BilibiliOpenLiveApi:
    """Small, injectable REST client for the official Open Platform API."""

    def __init__(
        self,
        credentials: OpenLiveCredentials,
        api_base: str = DEFAULT_API_BASE,
        timeout: float = 10.0,
        opener: Callable[..., Any] | None = None,
    ) -> None:
        self.credentials = credentials
        self.api_base = api_base.rstrip("/")
        self.timeout = timeout
        self._opener = opener or urlopen

    def _signed_headers(self, body: bytes) -> dict[str, str]:
        """Create the Open Platform HMAC-SHA256 request headers.

        The signature input is the newline-joined, key-sorted x-bili-* header
        map. The MD5 header is computed over the exact transmitted body bytes.
        """
        timestamp = str(int(time.time()))
        headers = {
            "x-bili-accesskeyid": self.credentials.access_key,
            "x-bili-content-md5": hashlib.md5(body).hexdigest(),
            "x-bili-signature-method": "HMAC-SHA256",
            "x-bili-signature-nonce": secrets.token_hex(16),
            "x-bili-signature-version": "1.0",
            "x-bili-timestamp": timestamp,
        }
        canonical = "\n".join(f"{key}:{headers[key]}" for key in sorted(headers))
        signature = hmac.new(
            self.credentials.access_secret.encode("utf-8"),
            canonical.encode("utf-8"), hashlib.sha256,
        ).hexdigest()
        return {
            **headers,
            "Authorization": signature,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def _post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        request = Request(
            f"{self.api_base}{path}", data=body,
            headers=self._signed_headers(body), method="POST",
        )
        try:
            response = self._opener(request, timeout=self.timeout)
            try:
                raw = response.read()
            finally:
                close = getattr(response, "close", None)
                if callable(close):
                    close()
            result = json.loads(raw.decode("utf-8"))
        except HTTPError as exc:
            # Do not include request headers or credential-bearing data in errors.
            raise OpenLiveApiError(f"B站开放平台 HTTP 错误：{exc.code}") from None
        except (URLError, TimeoutError, OSError) as exc:
            raise OpenLiveApiError(f"无法连接 B站开放平台：{type(exc).__name__}") from None
        except (UnicodeDecodeError, json.JSONDecodeError, AttributeError, TypeError):
            raise OpenLiveApiError("B站开放平台返回了无法识别的数据") from None
        if not isinstance(result, dict):
            raise OpenLiveApiError("B站开放平台返回格式不正确")
        code = result.get("code")
        if code != 0:
            message = str(result.get("message") or "未知错误")[:160]
            raise OpenLiveApiError(f"B站开放平台返回错误 {code}：{message}")
        data = result.get("data")
        if not isinstance(data, dict):
            raise OpenLiveApiError("B站开放平台响应缺少 data 对象")
        return data

    def start(self) -> OpenLiveSession:
        self.credentials.validate()
        data = self._post("/v2/app/start", {
            "code": self.credentials.auth_code,
            "app_id": int(self.credentials.app_id),
        })
        game_info = data.get("game_info") or {}
        ws_info = data.get("websocket_info") or {}
        anchor = data.get("anchor_info") or {}
        game_id = str(game_info.get("game_id") or "")
        urls = ws_info.get("wss_link") or []
        auth_body = ws_info.get("auth_body")
        if not game_id or not isinstance(urls, list) or not urls or not auth_body:
            raise OpenLiveApiError("启动响应缺少 game_id、WSS 地址或 auth_body")
        if isinstance(auth_body, str):
            auth_bytes = auth_body.encode("utf-8")
        else:
            auth_bytes = json.dumps(auth_body, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        room_id = int(anchor.get("room_id") or 0)
        if room_id <= 0:
            raise OpenLiveApiError("启动响应未返回有效直播间号")
        valid_urls = tuple(str(url) for url in urls if str(url).startswith("wss://"))
        if not valid_urls:
            raise OpenLiveApiError("启动响应没有可用的 WSS 地址")
        return OpenLiveSession(
            app_id=int(self.credentials.app_id), game_id=game_id,
            room_id=room_id, websocket_urls=valid_urls, auth_body=auth_bytes,
            anchor_name=str(anchor.get("uname") or ""),
            anchor_uid=str(anchor.get("uid") or ""),
        )

    def heartbeat(self, game_id: str) -> None:
        self._post("/v2/app/heartbeat", {"game_id": str(game_id)})

    def end(self, app_id: int, game_id: str) -> None:
        self._post("/v2/app/end", {"app_id": int(app_id), "game_id": str(game_id)})
