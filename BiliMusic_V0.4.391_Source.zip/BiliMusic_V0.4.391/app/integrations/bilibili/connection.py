"""Connection lifecycle and deterministic local event simulator."""
from __future__ import annotations

from enum import Enum
from threading import RLock
from typing import Callable

from app.integrations.bilibili.contracts import BilibiliClient, LiveMessage, IntegrationNotConfigured


class ConnectionState(str, Enum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    RECONNECTING = "reconnecting"
    ERROR = "error"


class ConnectionManager:
    """Owns client lifecycle; placeholder clients never report a false connection."""
    def __init__(self, client: BilibiliClient, on_message: Callable[[LiveMessage], None], on_state: Callable[[ConnectionState, str], None] | None = None):
        self.client, self.on_message = client, on_message
        self.on_state = on_state or (lambda state, detail: None)
        self.state = ConnectionState.DISCONNECTED
        self._lock = RLock()

    def connect(self, room_id: int) -> None:
        if int(room_id) <= 0:
            raise ValueError("直播间号必须是正整数")
        with self._lock:
            if self.state in {ConnectionState.CONNECTING, ConnectionState.CONNECTED}:
                return
            self._set(ConnectionState.CONNECTING, "正在建立连接")
            try:
                self.client.connect(int(room_id), self.on_message)
                if not self.client.is_connected:
                    self._set(ConnectionState.ERROR, "连接器未确认连接成功")
                    return
                self._set(ConnectionState.CONNECTED, "连接成功")
            except IntegrationNotConfigured as exc:
                self._set(ConnectionState.DISCONNECTED, str(exc))
                raise
            except Exception as exc:
                self._set(ConnectionState.ERROR, str(exc))
                raise

    def disconnect(self) -> None:
        with self._lock:
            try:
                self.client.disconnect()
            finally:
                self._set(ConnectionState.DISCONNECTED, "已断开连接")

    def _set(self, state: ConnectionState, detail: str) -> None:
        self.state = state
        self.on_state(state, detail)


class SimulatedBilibiliClient:
    """Local-only simulator. It never contacts Bilibili or sends credentials."""
    def __init__(self):
        self._connected = False
        self._callback: Callable[[LiveMessage], None] | None = None
        self.room_id = 0

    @property
    def is_connected(self) -> bool:
        return self._connected

    def connect(self, room_id: int, on_message: Callable[[LiveMessage], None]) -> None:
        self.room_id, self._callback, self._connected = int(room_id), on_message, True

    def emit(self, message: LiveMessage) -> None:
        if not self._connected or self._callback is None:
            raise RuntimeError("模拟器尚未连接")
        if message.room_id not in (0, self.room_id):
            raise ValueError("模拟消息的直播间号与当前模拟连接不一致")
        normalized = message if message.room_id else LiveMessage(
            message.message_type, self.room_id, message.uid, message.username, message.text,
            message.fan_badge_name, message.fan_badge_level, message.guard_level, message.sc_amount,
        )
        self._callback(normalized)

    def disconnect(self) -> None:
        self._connected, self._callback = False, None
