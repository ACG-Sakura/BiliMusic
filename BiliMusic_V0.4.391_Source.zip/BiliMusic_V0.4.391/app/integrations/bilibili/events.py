"""Adapter-neutral Bilibili live event parsing and song-request handling.

The parser accepts normalized dictionaries. A production adapter must map only
messages documented and authorized for the application's Bilibili access.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from app.integrations.bilibili.contracts import LiveMessage


ALIASES = {
    "DANMU_MSG": "danmaku",
    "DANMAKU": "danmaku",
    "SUPER_CHAT_MESSAGE": "sc",
    "SC": "sc",
    "GUARD_BUY": "guard",
    "GUARD": "guard",
    "LIVE": "live",
    "PREPARING": "preparing",
    "INTERACT_WORD": "interaction",
    "SEND_GIFT": "gift",
}


def parse_live_message(payload: Mapping[str, Any], default_room_id: int = 0) -> LiveMessage:
    """Convert a normalized event mapping into the stable internal message."""
    raw_type = str(payload.get("message_type", payload.get("cmd", "unknown"))).upper()
    message_type = ALIASES.get(raw_type, raw_type.lower())
    user = payload.get("user") if isinstance(payload.get("user"), Mapping) else {}
    badge = payload.get("fan_badge") if isinstance(payload.get("fan_badge"), Mapping) else {}
    room_id = int(payload.get("room_id") or default_room_id or 0)
    uid = payload.get("uid", user.get("uid", ""))
    username = payload.get("username", user.get("name", ""))
    text = payload.get("text", payload.get("message", ""))
    amount = payload.get("sc_amount", payload.get("price", 0))
    try:
        amount = float(amount or 0)
    except (TypeError, ValueError):
        amount = 0.0
    try:
        badge_level = int(payload.get("fan_badge_level", badge.get("level", 0)) or 0)
        guard_level = int(payload.get("guard_level", user.get("guard_level", 0)) or 0)
    except (TypeError, ValueError):
        badge_level, guard_level = 0, 0
    return LiveMessage(
        message_type=message_type, room_id=room_id, uid=str(uid or ""),
        username=str(username or ""), text=str(text or ""),
        fan_badge_name=str(payload.get("fan_badge_name", badge.get("name", "")) or ""),
        fan_badge_level=max(0, badge_level), guard_level=guard_level,
        sc_amount=max(0.0, amount),
    )


@dataclass(frozen=True, slots=True)
class RequestParseResult:
    title: str
    artist: str = ""


def parse_song_request(text: str, prefix: str = "点歌") -> RequestParseResult | None:
    """Parse `点歌 歌名` or `点歌 歌名 歌手` (artist is optional).

    The first whitespace-delimited token after the command is the song title;
    the remaining text, if any, is treated as the artist name.
    """
    content = (text or "").strip()
    if not content.startswith(prefix):
        return None
    # The command must be followed by whitespace; e.g. 点歌手 is not a request.
    if len(content) <= len(prefix) or not content[len(prefix)].isspace():
        return None
    content = content[len(prefix):].strip()
    if not content:
        return None
    parts = content.split(None, 1)
    title = parts[0].strip()
    artist = parts[1].strip() if len(parts) > 1 else ""
    return RequestParseResult(title, artist) if title else None
