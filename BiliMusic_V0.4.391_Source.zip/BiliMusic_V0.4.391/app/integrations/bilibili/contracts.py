"""Stable interfaces for the future Bilibili adapter.

No unofficial endpoint, QR login flow, or account-status assertion is implemented here.
The production adapter must be built against an allowed and documented access path.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, Callable


@dataclass(frozen=True, slots=True)
class LiveMessage:
    message_type: str
    room_id: int
    uid: str = ""
    username: str = ""
    text: str = ""
    fan_badge_name: str = ""
    fan_badge_level: int = 0
    guard_level: int = 0  # 0=none, 1=总督, 2=提督, 3=舰长 (adapter must normalize)
    sc_amount: float = 0.0


class BilibiliClient(Protocol):
    def connect(self, room_id: int, on_message: Callable[[LiveMessage], None]) -> None: ...
    def disconnect(self) -> None: ...
    @property
    def is_connected(self) -> bool: ...


class IntegrationNotConfigured(RuntimeError):
    pass


class BilibiliClientPlaceholder:
    """Explicit placeholder so the UI cannot pretend a real connection exists."""
    @property
    def is_connected(self) -> bool:
        return False

    def connect(self, room_id: int, on_message: Callable[[LiveMessage], None]) -> None:
        raise IntegrationNotConfigured(
            "B站连接器尚未接入。需要先确认可用的官方/合规接入方式及权限。"
        )

    def disconnect(self) -> None:
        return None
