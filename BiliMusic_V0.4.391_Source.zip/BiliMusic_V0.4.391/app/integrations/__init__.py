"""External platform adapters."""
