"""Music provider contract.

Concrete providers must disclose whether they use an official SDK or a community
API wrapper, must not bypass account entitlements, and must protect session secrets
instead of persisting them in SQLite or plain-text settings files.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True, slots=True)
class Track:
    provider: str
    track_id: str
    title: str
    artist: str = ""
    duration_seconds: int | None = None


class MusicProvider(Protocol):
    provider_name: str

    def login(self) -> None: ...
    def logout(self) -> None: ...
    def is_authenticated(self) -> bool: ...
    def search(self, keyword: str) -> list[Track]: ...
    def play(self, track: Track) -> None: ...
    def pause(self) -> None: ...
    def resume(self) -> None: ...
    def stop(self) -> None: ...


class ProviderNotConfigured(RuntimeError):
    pass
