"""Lifecycle manager for the bundled, loopback-only NetEase API service."""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

from app.integrations.music.netease import NeteaseApiClient


class NeteaseServiceError(RuntimeError):
    pass


class NeteaseServiceManager:
    def __init__(self, project_root: str | Path | None = None, port: int = 3000):
        self.project_root = Path(project_root).resolve() if project_root else self._default_root()
        self.port = int(port)
        self.process: subprocess.Popen | None = None

    @staticmethod
    def _default_root() -> Path:
        if getattr(sys, "frozen", False):
            meipass = Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
            candidate = meipass / "netease-api"
            if candidate.exists():
                return candidate
            return Path(sys.executable).parent / "netease-api"
        return Path(__file__).resolve().parents[3] / "netease-api"

    def _node_executable(self) -> str | None:
        candidates = [self.project_root / "runtime" / "node.exe", self.project_root / "runtime" / "node"]
        for candidate in candidates:
            if candidate.is_file():
                return str(candidate)
        return shutil.which("node")

    def ensure_running(self, timeout: float = 12.0) -> None:
        base_url = f"http://127.0.0.1:{self.port}"
        client = NeteaseApiClient(base_url, timeout=2)
        if client.ping():
            return
        server = self.project_root / "server.js"
        modules = self.project_root / "node_modules" / "@neteasecloudmusicapienhanced" / "api"
        node = self._node_executable()
        if not server.is_file() or not modules.is_dir() or not node:
            raise NeteaseServiceError(
                "网易云本地服务尚未安装。请在源码目录运行 install_netease_api.bat，"
                "或使用包含本地服务运行时的 Windows 构建包。"
            )
        env = os.environ.copy()
        env.update({
            "BILIMUSIC_NCM_PORT": str(self.port),
            "HOST": "127.0.0.1",
            "PORT": str(self.port),
            "ENABLE_GENERAL_UNBLOCK": "false",
            "ENABLE_PROXY": "false",
        })
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
        self.process = subprocess.Popen(
            [node, str(server)], cwd=str(self.project_root), env=env,
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=creationflags,
        )
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self.process.poll() is not None:
                self.process = None
                raise NeteaseServiceError("网易云本地服务启动后立即退出。请检查 Node.js 运行时和依赖安装。")
            if client.ping():
                return
            time.sleep(0.25)
        self.stop()
        raise NeteaseServiceError("网易云本地服务启动超时。")

    def stop(self) -> None:
        process, self.process = self.process, None
        if process is None or process.poll() is not None:
            return
        process.terminate()
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=2)
