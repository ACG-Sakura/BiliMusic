"""Music provider integration exports."""

from .netease import NeteaseApiClient, NeteaseError, NeteasePlaylist, NeteaseTrack
from .secret_store import WindowsMusicSecretStore, SecretStoreError

__all__ = [
    "NeteaseApiClient", "NeteaseError", "NeteasePlaylist", "NeteaseTrack",
    "WindowsMusicSecretStore", "SecretStoreError",
]
