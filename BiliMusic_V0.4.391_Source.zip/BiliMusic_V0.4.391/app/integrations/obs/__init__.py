"""Local OBS overlay integration."""

from .server import OBSOverlayServer

__all__ = ["OBSOverlayServer"]
