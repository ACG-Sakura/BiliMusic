from __future__ import annotations

from datetime import datetime, timezone
from typing import Any


def build_obs_state(queue, playback, display: dict[str, Any] | None = None) -> dict[str, Any]:
    """Build a safe, read-only snapshot for the OBS queue overlay."""
    current_song = queue.current_playing()
    current = None
    active = playback.current_track
    if active is not None:
        track, source_label, requester_name = active
        is_request = playback.current_source == "request"
        if requester_name:
            display_requester = requester_name
        elif current_song is not None and is_request:
            display_requester = current_song.requester_name
        elif playback.current_source == "autoplay":
            display_requester = "歌单播放"
        else:
            display_requester = "主播播放"
        current = {
            "id": str(current_song.id) if current_song else "current",
            "title": str(getattr(track, "title", "未知歌曲")),
            "artist": str(getattr(track, "artist", "")),
            "requesterName": str(display_requester),
            "source": str(source_label or ""),
        }
    elif current_song is not None and getattr(playback, "_pending_remote", None) == ("request", current_song.id):
        # A remote request may be resolving before the media backend starts.
        current = {
            "id": str(current_song.id),
            "title": current_song.title,
            "artist": current_song.artist,
            "requesterName": current_song.requester_name,
            "source": current_song.source,
        }

    queue_items = [
        {
            "id": str(song.id),
            "title": song.title,
            "artist": song.artist,
            "requesterName": song.requester_name,
            "source": song.source,
        }
        for song in queue.list_queue()
    ]
    return {
        "schemaVersion": 1,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "current": current,
        "queue": queue_items,
        "queueLength": len(queue_items),
        "display": display or {},
    }
