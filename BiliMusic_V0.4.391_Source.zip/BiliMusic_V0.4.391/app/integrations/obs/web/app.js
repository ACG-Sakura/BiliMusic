(function () {
  'use strict';
  const root = document.getElementById('overlay');
  const currentLine = document.getElementById('current-line');
  const queueTrack = document.getElementById('queue-track');
  const queueCount = document.getElementById('queue-count');
  const connectionState = document.getElementById('connection-state');
  let socket = null;
  let reconnectTimer = null;
  let pollTimer = null;
  let reconnectDelay = 1000;
  let queueRows = [];
  let queueOffset = 0;
  let scrollTimer = null;
  let lastQueueSignature = '';
  let lastCurrentSignature = '';

  function text(value, fallback) {
    if (value === null || value === undefined || String(value).trim() === '') return fallback || '';
    return String(value);
  }
  function songLine(song) {
    return [text(song.title, '未知歌曲'), text(song.artist, ''), song.requesterName ? '@' + song.requesterName : ''].filter(Boolean).join('　');
  }
  function makeMarquee(line, className) {
    const holder = document.createElement('div');
    holder.className = 'marquee';
    const first = document.createElement('span');
    first.className = 'marquee-text';
    first.textContent = line;
    const copy = document.createElement('span');
    copy.className = 'marquee-copy';
    copy.textContent = line;
    holder.append(first, copy);
    if (className) holder.dataset.kind = className;
    requestAnimationFrame(() => {
      const overflow = Math.max(0, first.scrollWidth - holder.parentElement.clientWidth);
      const travel = first.scrollWidth;
      copy.style.display = overflow > 4 ? 'inline-block' : 'none';
      if (overflow > 4) {
        holder.classList.add('is-scrolling');
        holder.style.setProperty('--marquee-distance', travel + 'px');
        holder.style.setProperty('--marquee-duration', Math.max(7, travel / 38) + 's');
      } else {
        holder.classList.remove('is-scrolling');
      }
    });
    return holder;
  }
  function renderCurrent(song) {
    const signature = song ? JSON.stringify([song.id, song.title, song.artist, song.requesterName]) : 'idle';
    if (signature === lastCurrentSignature) return;
    lastCurrentSignature = signature;
    currentLine.replaceChildren();
    const line = song ? songLine(song) : '等待播放';
    currentLine.append(makeMarquee(line, 'current'));
  }
  function renderQueue(songs) {
    const signature = JSON.stringify(songs.map(song => [song.id, song.title, song.artist, song.requesterName]));
    queueCount.textContent = songs.length + ' 首待播';
    if (signature === lastQueueSignature) return;
    lastQueueSignature = signature;
    queueRows = songs;
    queueOffset = 0;
    if (scrollTimer) window.clearInterval(scrollTimer);
    queueTrack.style.transition = 'none';
    queueTrack.style.transform = 'translateY(0)';
    queueTrack.replaceChildren();
    if (!songs.length) {
      const empty = document.createElement('div');
      empty.className = 'queue-row empty-row';
      empty.textContent = '暂无待播歌曲';
      queueTrack.append(empty);
      return;
    }
    const ordered = songs.slice();
    // Extra copies let the viewport animate past the final item before resetting.
    const visibleItems = ordered.length > 3 ? ordered.concat(ordered.slice(0, 3)) : ordered;
    visibleItems.forEach((song, index) => {
      const row = document.createElement('div');
      row.className = 'queue-row';
      const number = document.createElement('span');
      number.className = 'queue-index';
      number.textContent = String((index % ordered.length) + 1).padStart(2, '0');
      const copy = document.createElement('div');
      copy.className = 'queue-song';
      copy.append(makeMarquee(songLine(song), 'queue'));
      row.append(number, copy);
      queueTrack.append(row);
    });
    requestAnimationFrame(() => { queueTrack.style.transition = ''; });
    if (songs.length > 3) {
      scrollTimer = window.setInterval(() => {
        queueOffset += 1;
        queueTrack.style.transform = 'translateY(' + (-queueOffset * 38) + 'px)';
        if (queueOffset >= songs.length) {
          window.setTimeout(() => {
            queueTrack.style.transition = 'none';
            queueOffset = 0;
            queueTrack.style.transform = 'translateY(0)';
            requestAnimationFrame(() => requestAnimationFrame(() => { queueTrack.style.transition = ''; }));
          }, 760);
        }
      }, 3200);
    }
  }
  function applyStyle(style) {
    if (!style || typeof style !== 'object') return;
    root.dataset.background = style.background === 'translucent' ? 'translucent' : 'transparent';
    root.dataset.align = ['left', 'center', 'right'].includes(style.alignment) ? style.alignment : 'left';
    const safeColor = (value, fallback) => /^#[0-9a-fA-F]{6}$/.test(String(value || '')) ? value : fallback;
    root.style.setProperty('--current-color', safeColor(style.currentColor, '#f7faff'));
    root.style.setProperty('--queue-color', safeColor(style.queueColor, '#e7efff'));
    root.style.setProperty('--font-size', Math.max(16, Math.min(56, Number(style.fontSize) || 28)) + 'px');
    const opacity = Math.max(.1, Math.min(.95, Number(style.opacity) || .72));
    root.style.setProperty('--panel-bg', 'rgba(14,25,43,' + opacity + ')');
  }
  function renderState(state) {
    if (!state || typeof state !== 'object') return;
    renderCurrent(state.current || null);
    renderQueue(Array.isArray(state.queue) ? state.queue : []);
    applyStyle(state.display || {});
    root.dataset.offline = 'false';
    connectionState.textContent = 'BiliMusic 已连接';
  }
  function setOffline() {
    root.dataset.offline = 'true';
    connectionState.textContent = '等待连接 BiliMusic 本地服务';
  }
  function poll() {
    fetch('/api/v1/state', { cache: 'no-store' })
      .then(response => { if (!response.ok) throw new Error('HTTP ' + response.status); return response.json(); })
      .then(renderState).catch(setOffline);
  }
  function startPolling() {
    if (pollTimer) return;
    poll();
    pollTimer = window.setInterval(poll, 1000);
  }
  function reconnect() {
    if (reconnectTimer) return;
    reconnectTimer = window.setTimeout(() => { reconnectTimer = null; connect(); }, reconnectDelay);
    reconnectDelay = Math.min(15000, reconnectDelay * 2);
  }
  function connect() {
    if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) return;
    try { socket = new WebSocket('ws://' + window.location.host + '/ws'); }
    catch (_error) { startPolling(); reconnect(); return; }
    socket.addEventListener('open', () => {
      reconnectDelay = 1000;
      if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
      poll();
    });
    socket.addEventListener('message', event => {
      try {
        const message = JSON.parse(event.data);
        renderState(message && message.type === 'state' ? message.data : message);
      } catch (_error) { /* Ignore malformed messages. */ }
    });
    socket.addEventListener('close', () => { socket = null; startPolling(); reconnect(); });
    socket.addEventListener('error', () => { try { socket.close(); } catch (_error) {} });
  }
  window.addEventListener('resize', () => { lastQueueSignature = ''; poll(); });
  window.addEventListener('pagehide', () => {
    if (pollTimer) clearInterval(pollTimer);
    if (reconnectTimer) clearTimeout(reconnectTimer);
    if (scrollTimer) clearInterval(scrollTimer);
    if (socket) socket.close();
  });
  connect();
  // HTTP is started immediately too, ensuring that a blocked WebSocket never leaves a blank source.
  poll();
}());
