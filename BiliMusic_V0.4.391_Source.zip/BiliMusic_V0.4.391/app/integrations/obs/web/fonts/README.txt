Optional user-provided OBS overlay font.

To use a locally licensed copy of the font named "超级花伦丸85.ttf", place it in this folder as:
  super-hualunwan-85.ttf

The source archive intentionally doesn't include font binaries. If the file is present before running build_windows.bat or the GitHub Actions build, PyInstaller will bundle it with the OBS web assets. Otherwise the page falls back to Microsoft YaHei / the system sans-serif font.
