"""BiliMusic application package."""
