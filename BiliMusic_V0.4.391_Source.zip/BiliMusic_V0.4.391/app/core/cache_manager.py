"""Bounded cache storage for explicitly authorized media resources.

The cache manager never discovers or downloads platform media. Callers may cache
only files they are permitted to store (for example, user-selected local files or
resources supplied by a documented provider authorization flow).
"""
from __future__ import annotations

import shutil
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from uuid import uuid4

from platformdirs import user_cache_dir


@dataclass(frozen=True, slots=True)
class CacheStats:
    bytes_used: int
    max_bytes: int
    files: int


class CacheManager:
    SIZE_OPTIONS_MB = (256, 512, 1024, 2048)

    def __init__(self, database, cache_dir: str | Path | None = None):
        self.db = database
        self.cache_dir = Path(cache_dir) if cache_dir else Path(user_cache_dir("BiliMusic", "BiliMusic")) / "media"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        with self.db.session() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS media_cache (
                    cache_key TEXT PRIMARY KEY,
                    file_path TEXT NOT NULL UNIQUE,
                    size_bytes INTEGER NOT NULL,
                    last_used_at TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    protected INTEGER NOT NULL DEFAULT 0
                );
                CREATE INDEX IF NOT EXISTS idx_media_cache_lru ON media_cache(last_used_at);
            """)
        self._seed_setting("cache_max_mb", 512)
        self._seed_setting("cache_cleanup_interval_days", 1)
        self._seed_setting("cache_retention_days", 7)
        self._seed_setting("cache_last_cleanup_at", "")

    def _seed_setting(self, key, value):
        self.db.execute("INSERT OR IGNORE INTO settings(key,value_json) VALUES(?,?)", (key, __import__('json').dumps(value)))

    def _setting(self, key, default):
        row = self.db.fetchone("SELECT value_json FROM settings WHERE key=?", (key,))
        if not row:
            return default
        import json
        try:
            return json.loads(row["value_json"])
        except (ValueError, TypeError):
            return default

    def _set_setting(self, key, value):
        import json
        self.db.execute("INSERT INTO settings(key,value_json) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json", (key, json.dumps(value)))

    @property
    def max_bytes(self) -> int:
        return int(self._setting("cache_max_mb", 512)) * 1024 * 1024

    def configure(self, *, max_mb: int | None = None, cleanup_interval_days: int | None = None, retention_days: int | None = None):
        if max_mb is not None:
            if max_mb not in self.SIZE_OPTIONS_MB:
                raise ValueError("缓存容量只能设置为 256、512、1024 或 2048 MB。")
            self._set_setting("cache_max_mb", max_mb)
        if cleanup_interval_days is not None:
            if not 1 <= int(cleanup_interval_days) <= 30:
                raise ValueError("清理周期必须在 1 到 30 天之间。")
            self._set_setting("cache_cleanup_interval_days", int(cleanup_interval_days))
        if retention_days is not None:
            if not 1 <= int(retention_days) <= 365:
                raise ValueError("缓存保留期限必须在 1 到 365 天之间。")
            self._set_setting("cache_retention_days", int(retention_days))
        self.enforce_limit()

    def register_file(self, cache_key: str, source_path: str | Path, *, protected: bool = False) -> Path:
        """Copy a permitted source file into cache and register it by stable key."""
        source = Path(source_path).expanduser().resolve()
        if not source.is_file():
            raise FileNotFoundError(source)
        key = (cache_key or "").strip()
        if not key:
            raise ValueError("缓存标识不能为空。")
        suffix = source.suffix[:16]
        target = self.cache_dir / f"{uuid4().hex}{suffix}"
        shutil.copy2(source, target)
        now = self._now()
        with self.db.session() as conn:
            old = conn.execute("SELECT file_path FROM media_cache WHERE cache_key=?", (key,)).fetchone()
            conn.execute("INSERT INTO media_cache(cache_key,file_path,size_bytes,last_used_at,created_at,protected) VALUES(?,?,?,?,?,?) ON CONFLICT(cache_key) DO UPDATE SET file_path=excluded.file_path,size_bytes=excluded.size_bytes,last_used_at=excluded.last_used_at,created_at=excluded.created_at,protected=excluded.protected", (key, str(target), target.stat().st_size, now, now, int(protected)))
        if old:
            self._unlink(Path(old["file_path"]))
        self.enforce_limit()
        return target

    def get(self, cache_key: str, *, protect: bool | None = None) -> Path | None:
        row = self.db.fetchone("SELECT * FROM media_cache WHERE cache_key=?", (cache_key,))
        if not row:
            return None
        path = Path(row["file_path"])
        if not path.is_file():
            self.db.execute("DELETE FROM media_cache WHERE cache_key=?", (cache_key,))
            return None
        with self.db.session() as conn:
            if protect is None:
                conn.execute("UPDATE media_cache SET last_used_at=? WHERE cache_key=?", (self._now(), cache_key))
            else:
                conn.execute("UPDATE media_cache SET last_used_at=?,protected=? WHERE cache_key=?", (self._now(), int(protect), cache_key))
        return path

    def protect_keys(self, keys: set[str]):
        with self.db.session() as conn:
            conn.execute("UPDATE media_cache SET protected=0")
            for key in keys:
                conn.execute("UPDATE media_cache SET protected=1 WHERE cache_key=?", (key,))

    def stats(self) -> CacheStats:
        row = self.db.fetchone("SELECT COALESCE(SUM(size_bytes),0) AS n, COUNT(*) AS c FROM media_cache")
        return CacheStats(int(row["n"]), self.max_bytes, int(row["c"]))

    def cleanup_if_due(self, now: datetime | None = None, *, force: bool = False) -> int:
        now = now or datetime.now(timezone.utc)
        last = self._setting("cache_last_cleanup_at", "")
        if last and not force:
            try:
                previous = datetime.fromisoformat(last)
                if now - previous < timedelta(days=int(self._setting("cache_cleanup_interval_days", 1))):
                    return 0
            except ValueError:
                pass
        removed = self.cleanup_expired(now=now)
        removed += self.enforce_limit()
        self._set_setting("cache_last_cleanup_at", now.astimezone(timezone.utc).isoformat(timespec="seconds"))
        return removed

    def cleanup_expired(self, now: datetime | None = None) -> int:
        now = now or datetime.now(timezone.utc)
        cutoff = (now - timedelta(days=int(self._setting("cache_retention_days", 7)))).isoformat(timespec="seconds")
        rows = self.db.fetchall("SELECT cache_key,file_path FROM media_cache WHERE protected=0 AND last_used_at<?", (cutoff,))
        return sum(1 for row in rows if self._delete_row(row["cache_key"], row["file_path"]))

    def enforce_limit(self) -> int:
        stats = self.stats()
        if stats.bytes_used <= stats.max_bytes:
            return 0
        target_bytes = int(stats.max_bytes * 0.70)
        rows = self.db.fetchall("SELECT cache_key,file_path,size_bytes FROM media_cache WHERE protected=0 ORDER BY last_used_at ASC,created_at ASC")
        used = stats.bytes_used
        removed = 0
        for row in rows:
            if used <= target_bytes:
                break
            if self._delete_row(row["cache_key"], row["file_path"]):
                used -= int(row["size_bytes"])
                removed += 1
        return removed

    def clear_all(self) -> int:
        """Clear disposable cache while preserving currently protected entries."""
        rows = self.db.fetchall("SELECT cache_key,file_path FROM media_cache WHERE protected=0")
        removed = 0
        for row in rows:
            if self._delete_row(row["cache_key"], row["file_path"]):
                removed += 1
        return removed

    def _delete_row(self, key, file_path, allow_protected=False):
        row = self.db.fetchone("SELECT protected FROM media_cache WHERE cache_key=?", (key,))
        if not row or (row["protected"] and not allow_protected):
            return False
        self._unlink(Path(file_path))
        self.db.execute("DELETE FROM media_cache WHERE cache_key=?", (key,))
        return True

    @staticmethod
    def _unlink(path: Path):
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass

    @staticmethod
    def _now():
        return datetime.now(timezone.utc).isoformat(timespec="seconds")
