from __future__ import annotations

import json
from typing import Any

from app.core.models import DEFAULT_SETTINGS
from app.storage.database import Database


class SettingsStore:
    def __init__(self, database: Database):
        self.database = database
        self._seed_defaults()

    def _seed_defaults(self) -> None:
        with self.database.session() as conn:
            for key, value in DEFAULT_SETTINGS.items():
                # Preserve an existing V0.1.3 personal cooldown when renaming it
                # to the ordinary fan-badge tier. Captain+ starts at 180 seconds.
                if key == "normal_badge_cooldown_seconds":
                    existing = conn.execute(
                        "SELECT value_json FROM settings WHERE key='user_cooldown_seconds'"
                    ).fetchone()
                    if existing is not None:
                        try:
                            value = int(json.loads(existing["value_json"]))
                        except (TypeError, ValueError, json.JSONDecodeError):
                            pass
                conn.execute(
                    "INSERT OR IGNORE INTO settings(key, value_json) VALUES (?, ?)",
                    (key, json.dumps(value, ensure_ascii=False)),
                )

    def get(self, key: str, default: Any = None) -> Any:
        row = self.database.fetchone("SELECT value_json FROM settings WHERE key=?", (key,))
        if row is None:
            return default
        try:
            return json.loads(row["value_json"])
        except (TypeError, json.JSONDecodeError):
            return default

    def set(self, key: str, value: Any) -> None:
        encoded = json.dumps(value, ensure_ascii=False)
        self.database.execute(
            "INSERT INTO settings(key, value_json) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json",
            (key, encoded),
        )

    def all(self) -> dict[str, Any]:
        rows = self.database.fetchall("SELECT key, value_json FROM settings ORDER BY key")
        result: dict[str, Any] = {}
        for row in rows:
            try:
                result[row["key"]] = json.loads(row["value_json"])
            except json.JSONDecodeError:
                result[row["key"]] = None
        return result
