from __future__ import annotations

from collections.abc import Iterable, Mapping

from app.core.models import DEFAULT_ROLE_PRIORITIES


def resolve_priority(
    kind: str,
    sc_amount: float = 0,
    sc_rules: Iterable[Mapping[str, int | float]] | None = None,
    role_priorities: Mapping[str, int] | None = None,
) -> int:
    """Resolve a queue priority. Higher number means earlier playback.

    SC rules are inclusive lower bounds. For example, a 50 CNY SC matches
    min_amount=50 and receives that rule's priority. The highest qualifying
    threshold wins. Unmatched SC uses the configured base SC role priority.
    """
    roles = dict(DEFAULT_ROLE_PRIORITIES)
    if role_priorities:
        roles.update({str(key): int(value) for key, value in role_priorities.items()})
    if kind != "sc":
        return int(roles.get(kind, roles.get("normal", 10)))

    matched_priority = int(roles.get("sc", 50))
    valid_rules: list[tuple[float, int]] = []
    for rule in sc_rules or ():
        try:
            threshold = float(rule["min_amount"])
            priority = int(rule["priority"])
        except (KeyError, TypeError, ValueError):
            continue
        if threshold >= 0:
            valid_rules.append((threshold, priority))
    for threshold, priority in sorted(valid_rules):
        if float(sc_amount) >= threshold:
            matched_priority = priority
    return matched_priority
