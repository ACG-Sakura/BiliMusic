"""Core business logic, independent from the GUI."""
