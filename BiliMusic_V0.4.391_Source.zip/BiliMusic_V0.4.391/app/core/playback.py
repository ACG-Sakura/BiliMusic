"""Playback scheduler for local audio and NetEase remote streams."""
from __future__ import annotations

import random
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Protocol


class AudioBackend(Protocol):
    def play_file(self, path: str) -> None: ...
    def play_url(self, url: str) -> None: ...
    def pause(self) -> None: ...
    def resume(self) -> None: ...
    def stop(self) -> None: ...
    def set_volume(self, value: float) -> None: ...


@dataclass(frozen=True, slots=True)
class RemoteTrack:
    title: str
    artist: str
    file_path: str
    external_id: str = ""


class PlaybackCoordinator:
    """Audience requests interrupt autoplay; audience requests never interrupt each other."""

    def __init__(self, queue, playlists, backend: AudioBackend,
                 on_state: Callable[[str, str], None] | None = None,
                 on_remote_request: Callable[[int, str, str], bool] | None = None,
                 on_remote_playlist: Callable[[int, str, str, str], bool] | None = None):
        self.queue = queue
        self.playlists = playlists
        self.backend = backend
        self.on_state = on_state or (lambda _state, _detail: None)
        self.on_remote_request = on_remote_request
        self.on_remote_playlist = on_remote_playlist
        self.current_source: str | None = None
        self.current_track = None
        self.current_started_at = ""
        self._auto_order: list[int] = []
        self._auto_pos = 0
        self._autoplay_last_id: int | None = None
        self._inside_callback = False
        self._pending_remote: tuple[str, int] | None = None
        self._playlist_order: list[int] = []
        self._playlist_pos = 0
        self._playlist_id: int | None = None
        self._playlist_failed_ids: set[int] = set()
        self._playlist_playback_requested = False

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat(timespec="seconds")

    def poll(self) -> None:
        queued = self.queue.list_queue()
        if queued:
            if self._pending_remote and self._pending_remote[0] in {"autoplay", "manual"}:
                # A new viewer request preempts a not-yet-resolved non-request track.
                self._pending_remote = None
            elif self._pending_remote and self._pending_remote[0] == "request":
                return
            if self.current_source in {"autoplay", "manual"}:
                self._stop_active("被观众点歌中断")
            if self.current_source is None:
                self._start_next_request()
            return
        if self._pending_remote is not None:
            return
        if self.current_source is None and self.playlists.autoplay_enabled():
            self._start_next_autoplay()

    def _start_next_request(self) -> None:
        queued = self.queue.list_queue()
        if not queued:
            if self.playlists.autoplay_enabled():
                self._start_next_autoplay()
            return
        self.queue.mark_playing(queued[0].id)
        self._start_request_id(queued[0].id)

    def _start_request_id(self, song_id: int) -> None:
        """Resolve a queue row; prefer the NetEase account stream when configured."""
        current_id: int | None = song_id
        while current_id is not None:
            song = self.queue.get_song(current_id)
            if song is None:
                current_id = None
                break
            if self.on_remote_request is not None:
                self._pending_remote = ("request", current_id)
                self.on_state("正在搜索网易云", f"正在为观众点歌查找《{song.title}》。")
                if self.on_remote_request(current_id, song.title, song.artist):
                    return
                self._pending_remote = None
            local = self.playlists.find_local_audio(song.title, song.artist)
            if local is None:
                self.playlists.record_playback(song.title, song.artist, "观众点歌", song.requester_name,
                                               "网易云未能解析且本地音频库没有匹配文件，已跳过", "", self._now(), self._now())
                self.on_state("未找到音频", f"《{song.title}》无法从网易云获取播放资源，且本地音频库没有匹配文件，已跳过。")
                current_id = self.queue.finish_current(skipped=True)
                continue
            self._start_file(local, "观众点歌", song.requester_name)
            if self.current_source == "request":
                return
            current_id = self.queue.finish_current(skipped=True)
        self.current_source = None
        self.current_track = None
        if self.playlists.autoplay_enabled():
            self._start_next_autoplay()

    def _start_file(self, track, source: str, requester_name: str = "") -> None:
        path = Path(track.file_path)
        if not path.is_file():
            self.on_state("文件不存在", str(path))
            return
        try:
            self.backend.play_file(str(path))
        except Exception as exc:
            self.on_state("播放失败", str(exc))
            return
        self.current_source = "request" if source == "观众点歌" else "autoplay"
        self.current_track = (track, source, requester_name)
        self.current_started_at = self._now()
        self.on_state("正在播放", f"{track.title} — {track.artist or '未知歌手'}")

    def start_remote(self, mode: str, reference_id: int, url: str, title: str,
                     artist: str = "", external_id: str = "") -> bool:
        """Start a resolved NetEase stream on the UI/audio thread if it is current."""
        if self._pending_remote != (mode, reference_id):
            return False  # Stale worker result after a skip or higher-priority request.
        source = "观众点歌" if mode == "request" else ("主播手动播放" if mode == "manual" else "自动播放")
        requester = ""
        if mode == "request":
            song = self.queue.get_song(reference_id)
            if song is None:
                self._pending_remote = None
                return False
            requester = song.requester_name
        try:
            self.backend.play_url(url)
        except Exception as exc:
            self.remote_failed(mode, reference_id, str(exc))
            return False
        self._pending_remote = None
        track = RemoteTrack(title, artist, url, external_id)
        self.current_source = mode
        self.current_track = (track, source, requester)
        self.current_started_at = self._now()
        if mode == "autoplay":
            self._playlist_failed_ids.clear()
        self.on_state("正在播放", f"{title} — {artist or '未知歌手'}（网易云）")
        return True

    def remote_failed(self, mode: str, reference_id: int, message: str) -> None:
        if self._pending_remote != (mode, reference_id):
            return
        self._pending_remote = None
        self.on_state("网易云播放失败", f"{message}，已跳过当前歌曲。")
        if mode == "request":
            song = self.queue.get_song(reference_id)
            if song:
                self.playlists.record_playback(song.title, song.artist, "观众点歌", song.requester_name,
                                               f"网易云解析失败：{message}", "", self._now(), self._now())
            next_id = self.queue.finish_current(skipped=True)
            if next_id is not None:
                self._start_request_id(next_id)
            else:
                self._start_next_autoplay()
            return
        if mode in {"autoplay", "manual"}:
            self._playlist_failed_ids.add(reference_id)
        # A viewer request always wins, including when a manual preview or the
        # last active playlist track fails before the periodic queue poll runs.
        if self.queue.list_queue():
            self._start_next_request()
            return
        if mode == "autoplay":
            _active_id, _mode, tracks = self.playlists.active_playlist_tracks()
            if tracks and len(self._playlist_failed_ids) >= len(tracks):
                self.on_state("自动播放等待中", "当前网易云歌单中的歌曲均无法解析，请检查账号登录状态或歌单可用性。")
                return
        self._start_next_autoplay()

    def _next_playlist_track(self):
        active_id, mode, tracks = self.playlists.active_playlist_tracks()
        if not active_id or not tracks:
            return None
        if self._playlist_id != active_id:
            self._playlist_id = active_id
            self._playlist_order = [track.id for track in tracks]
            self._playlist_pos = 0
            self._playlist_failed_ids.clear()
        candidates = [track for track in tracks if track.id not in self._playlist_failed_ids and track.source_ref]
        if not candidates:
            return None
        if mode == "随机播放":
            available = [track for track in candidates if track.id != self._autoplay_last_id] or candidates
            return random.choice(available)
        lookup = {track.id: track for track in tracks}
        while self._playlist_pos < len(self._playlist_order):
            track_id = self._playlist_order[self._playlist_pos]
            self._playlist_pos += 1
            track = lookup.get(track_id)
            if track and track.source_ref and track.id not in self._playlist_failed_ids:
                return track
        if mode == "列表循环":
            self._playlist_pos = 0
            return self._next_playlist_track()
        return None

    def _next_autoplay_track(self):
        tracks = self.playlists.list_local_audio_tracks()
        if not tracks:
            return None
        mode = self.playlists.local_audio_mode()
        if mode == "随机播放":
            choices = [t for t in tracks if t.id != self._autoplay_last_id] or tracks
            track = random.choice(choices)
        else:
            if not self._auto_order:
                self._auto_order = [t.id for t in tracks]
                self._auto_pos = 0
            if self._auto_pos >= len(self._auto_order):
                if mode == "顺序播放":
                    return None
                self._auto_pos = 0
            target_id = self._auto_order[self._auto_pos]
            self._auto_pos += 1
            track = next((t for t in tracks if t.id == target_id), None)
        return track

    def play_playlist(self, playlist_id: int) -> bool:
        """Play every synced track in a selected NetEase playlist.

        The explicit playlist request is independent of the global idle-autoplay
        switch. Audience requests keep priority and are served before the playlist
        resumes. The selected playlist's sequence/loop/random mode is respected.
        """
        row = self.playlists.get_playlist(playlist_id)
        if row is None or row["platform"] != "网易云音乐":
            self.on_state("无法播放歌单", "所选网易云歌单不存在。")
            return False
        tracks = self.playlists.list_tracks(playlist_id)
        playable = [track for track in tracks if track.source_ref and str(track.source_ref).isdigit()]
        if not playable:
            self.on_state("歌单没有可播放歌曲", "请先同步当前网易云歌单，再尝试播放全部歌曲。")
            return False

        # Do not interrupt a currently playing/resolving audience request. Mark
        # the requested playlist now; it starts when the request queue drains.
        request_is_active = self.current_source == "request" or (
            self._pending_remote is not None and self._pending_remote[0] == "request"
        )
        self.playlists.set_active(playlist_id)
        self._playlist_playback_requested = True
        self._playlist_id = None
        self._playlist_order = []
        self._playlist_pos = 0
        self._playlist_failed_ids.clear()
        if request_is_active:
            self.on_state("歌单已加入播放计划", "当前观众点歌结束后，将从所选歌单第一首开始播放。")
            return True
        self._pending_remote = None
        if self.current_source is not None:
            self._stop_active("主播开始播放整张歌单")
        if self.queue.list_queue():
            self._start_next_request()
        else:
            self._start_next_autoplay()
        return True

    def _start_next_autoplay(self) -> None:
        if not (self.playlists.autoplay_enabled() or self._playlist_playback_requested) or self.current_source is not None or self._pending_remote:
            return
        cloud_track = self._next_playlist_track()
        if cloud_track is not None and self.on_remote_playlist is not None:
            self._pending_remote = ("autoplay", cloud_track.id)
            self._autoplay_last_id = cloud_track.id
            self.on_state("正在准备网易云自动播放", f"正在解析《{cloud_track.title}》。")
            if self.on_remote_playlist(cloud_track.id, cloud_track.source_ref, cloud_track.title, cloud_track.artist):
                return
            self._pending_remote = None
            if self._playlist_playback_requested and not self.playlists.autoplay_enabled():
                self._playlist_playback_requested = False
                self.on_state("无法启动歌单播放", "网易云账号未登录或本机 API 服务不可用，请检查账号与平台设置。")
                return
        if cloud_track is None and self._playlist_playback_requested and not self.playlists.autoplay_enabled():
            self._playlist_playback_requested = False
            self.on_state("歌单播放完成", "当前歌单中的歌曲已全部播放完毕。")
            return
        track = self._next_autoplay_track()
        if track is None:
            if cloud_track is None:
                self.on_state("等待音频", "自动播放已开启，但没有可播放的网易云歌单或本地音频。")
            else:
                self.on_state("等待网易云账号", "已选择网易云自动播放歌单，但当前没有可用的账号会话或本地服务。请先登录网易云并检查本机 API 服务。")
            return
        attempts = len(self.playlists.list_local_audio_tracks())
        while attempts and track is not None and not Path(track.file_path).is_file():
            self.on_state("文件不存在", f"已跳过：{track.file_path}")
            self._autoplay_last_id = track.id
            track = self._next_autoplay_track()
            attempts -= 1
        if track is None or not Path(track.file_path).is_file():
            self.on_state("等待音频", "本地音频库中没有可播放的文件。")
            return
        self._autoplay_last_id = track.id
        self._start_file(track, "自动播放")

    def on_track_ended(self) -> None:
        if self.current_source is None:
            return
        source = self.current_source
        self._finish_current("播放完成")
        self.current_source = None
        self.current_track = None
        if source == "request":
            next_id = self.queue.finish_current(skipped=False)
            if next_id is not None:
                self._start_request_id(next_id)
            else:
                self._start_next_autoplay()
        else:
            self._start_next_request()
            if self.current_source is None and self._pending_remote is None:
                self._start_next_autoplay()

    def prepare_manual_remote(self, reference_id: int) -> bool:
        """Prepare a single-track preview without interrupting an audience request."""
        if self.current_source == "request" or (self._pending_remote and self._pending_remote[0] == "request"):
            self.on_state("当前有观众点歌", "观众点歌正在播放或解析，不能用手动播放打断。")
            return False
        if self.current_source is not None:
            self._stop_active("主播切换歌曲")
        else:
            self.current_source = None
            self.current_track = None
        self._playlist_playback_requested = False
        self._pending_remote = ("manual", reference_id)
        return True

    def play_local_track(self, track_id: int) -> bool:
        track = next((t for t in self.playlists.list_local_audio_tracks() if t.id == track_id), None)
        if track is None or not Path(track.file_path).is_file():
            self.on_state("文件不存在", "所选本地音频文件不存在。")
            return False
        if self.current_source == "request" or (self._pending_remote and self._pending_remote[0] == "request"):
            self.on_state("当前有观众点歌", "观众点歌正在播放或解析，不能用手动播放打断。")
            return False
        if self.current_source:
            self._stop_active("主播切换歌曲")
        self._playlist_playback_requested = False
        self._pending_remote = None
        self.current_source = None
        self.current_track = None
        self._start_file(track, "主播手动播放")
        return self.current_source is not None

    def skip_current(self) -> None:
        if self._pending_remote:
            mode, reference_id = self._pending_remote
            self._pending_remote = None
            self.on_state("已跳过", "已取消等待中的网易云歌曲解析。")
            if mode == "request":
                next_id = self.queue.finish_current(skipped=True)
                if next_id is not None:
                    self._start_request_id(next_id)
                else:
                    self._start_next_autoplay()
            else:
                if mode == "autoplay":
                    self._playlist_failed_ids.add(reference_id)
                self._start_next_request()
                if self.current_source is None and self._pending_remote is None:
                    self._start_next_autoplay()
            return
        if self.current_source is None:
            self.poll()
            return
        source = self.current_source
        # Detach logical playback state before stopping the Qt player. QMediaPlayer
        # may emit mediaStatusChanged while stop() is running; that callback must
        # not be treated as a natural end and advance the queue a second time.
        self._stop_active("主播手动跳过")
        if source == "request":
            next_id = self.queue.finish_current(skipped=True)
            if next_id is not None:
                self._start_request_id(next_id)
            else:
                self._start_next_autoplay()
        else:
            self._start_next_request()
            if self.current_source is None and self._pending_remote is None:
                self._start_next_autoplay()

    def handle_error(self, message: str) -> None:
        if self.current_source is None:
            self.on_state("播放错误", message)
            return
        source = self.current_source
        if source in {"autoplay", "manual"} and self.current_track:
            track = self.current_track[0]
            external_id = getattr(track, "external_id", "")
            if external_id:
                _active_id, _mode, playlist_tracks = self.playlists.active_playlist_tracks()
                failed = next((item.id for item in playlist_tracks if item.source_ref == external_id), None)
                if failed is not None:
                    self._playlist_failed_ids.add(failed)
        self._stop_active(f"播放错误：{message}")
        if source == "request":
            next_id = self.queue.finish_current(skipped=True)
            if next_id is not None:
                self._start_request_id(next_id)
            else:
                self._start_next_autoplay()
        else:
            self._start_next_request()
            if self.current_source is None and self._pending_remote is None:
                self._start_next_autoplay()

    def pause(self) -> None:
        self.backend.pause()

    def resume(self) -> None:
        self.backend.resume()

    def set_volume(self, value: float) -> None:
        self.backend.set_volume(max(0.0, min(1.0, float(value))))

    def _stop_active(self, result: str) -> None:
        """Finish and detach the current track before stopping the audio backend.

        Qt Multimedia can emit status notifications as a side effect of stop().
        Clearing the coordinator state first makes any re-entrant completion
        callback harmless and ensures QueueService.finish_current() is invoked
        exactly once by the caller.
        """
        self._finish_current(result)
        self.current_source = None
        self.current_track = None
        self.current_started_at = ""
        self.backend.stop()

    def _finish_current(self, result: str) -> None:
        if not self.current_track:
            return
        track, source, requester = self.current_track
        media_path = "" if isinstance(track, RemoteTrack) else track.file_path
        self.playlists.record_playback(track.title, track.artist, source, requester, result,
                                       media_path, self.current_started_at or self._now(), self._now())
        self.on_state(result, f"{track.title} — {track.artist or '未知歌手'}")
