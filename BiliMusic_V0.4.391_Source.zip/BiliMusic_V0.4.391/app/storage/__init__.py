"""Local persistence layer."""
