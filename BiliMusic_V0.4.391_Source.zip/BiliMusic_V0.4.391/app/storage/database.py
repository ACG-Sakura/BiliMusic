from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

from platformdirs import user_data_dir

APP_DATA_DIR = Path(user_data_dir("BiliMusic", "BiliMusic"))
DEFAULT_DB_PATH = APP_DATA_DIR / "bilimusic.db"


class Database:
    """Local SQLite repository. Account secrets must never be stored in this database."""

    def __init__(self, path: str | Path | None = None):
        self.path = Path(path) if path else DEFAULT_DB_PATH
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def connect(self) -> sqlite3.Connection:
        """Create a SQLite connection. Callers must close it explicitly."""
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA journal_mode = WAL")
        return conn

    @contextmanager
    def session(self) -> Iterator[sqlite3.Connection]:
        """Provide a transaction-scoped connection that is always closed.

        sqlite3.Connection's built-in context manager commits/rolls back but does
        not close the connection. Explicitly closing it is important on Windows,
        where TemporaryDirectory cleanup and app data replacement can otherwise
        fail with WinError 32 while SQLite still holds the database file.
        """
        conn = self.connect()
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def initialize(self) -> None:
        with self.session() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS songs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    artist TEXT NOT NULL DEFAULT '',
                    requester_name TEXT NOT NULL DEFAULT '',
                    requester_uid TEXT NOT NULL DEFAULT '',
                    source TEXT NOT NULL DEFAULT 'manual',
                    priority INTEGER NOT NULL DEFAULT 10,
                    kind TEXT NOT NULL DEFAULT 'normal',
                    status TEXT NOT NULL DEFAULT 'queued',
                    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
                    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
                );
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS event_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    level TEXT NOT NULL DEFAULT 'INFO',
                    category TEXT NOT NULL DEFAULT 'app',
                    message TEXT NOT NULL,
                    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
                );
                """
            )
            # Lightweight migration keeps an existing V0.1 database usable.
            song_columns = {row["name"] for row in conn.execute("PRAGMA table_info(songs)")}
            migrations = {
                "requester_name": "TEXT NOT NULL DEFAULT ''",
                "requester_uid": "TEXT NOT NULL DEFAULT ''",
                "priority": "INTEGER NOT NULL DEFAULT 10",
                "position": "INTEGER NOT NULL DEFAULT 0",
                "manual_order": "INTEGER NOT NULL DEFAULT 0",
                "kind": "TEXT NOT NULL DEFAULT 'normal'",
                "status": "TEXT NOT NULL DEFAULT 'queued'",
                "updated_at": "TEXT NOT NULL DEFAULT ''",
            }
            added_position = "position" not in song_columns
            for column_name, definition in migrations.items():
                if column_name not in song_columns:
                    conn.execute(f"ALTER TABLE songs ADD COLUMN {column_name} {definition}")
            if "requester" in song_columns and "requester_name" not in song_columns:
                conn.execute("UPDATE songs SET requester_name=COALESCE(requester, '')")
            conn.execute("UPDATE songs SET updated_at=created_at WHERE updated_at='' AND created_at IS NOT NULL")
            if added_position:
                priority_groups = conn.execute(
                    "SELECT DISTINCT priority, status FROM songs ORDER BY priority DESC, status"
                ).fetchall()
                for group in priority_groups:
                    rows = conn.execute(
                        "SELECT id FROM songs WHERE priority=? AND status=? ORDER BY created_at, id",
                        (group["priority"], group["status"]),
                    ).fetchall()
                    for pos, song_row in enumerate(rows):
                        conn.execute("UPDATE songs SET position=? WHERE id=?", (pos, song_row["id"]))
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_songs_status_priority "
                "ON songs(status, priority DESC, position ASC, created_at ASC, id ASC)"
            )

    def execute(self, sql: str, params: tuple[Any, ...] = ()) -> int:
        with self.session() as conn:
            cur = conn.execute(sql, params)
            return int(cur.lastrowid or 0)

    def fetchall(self, sql: str, params: tuple[Any, ...] = ()) -> list[sqlite3.Row]:
        with self.session() as conn:
            return list(conn.execute(sql, params).fetchall())

    def fetchone(self, sql: str, params: tuple[Any, ...] = ()) -> sqlite3.Row | None:
        with self.session() as conn:
            return conn.execute(sql, params).fetchone()

    def log(self, level: str, category: str, message: str) -> None:
        self.execute(
            "INSERT INTO event_logs(level, category, message) VALUES (?, ?, ?)",
            (level.upper(), category, message),
        )

    def recent_logs(self, limit: int = 100) -> list[sqlite3.Row]:
        return self.fetchall(
            "SELECT * FROM event_logs ORDER BY id DESC LIMIT ?", (max(1, min(limit, 1000)),)
        )
