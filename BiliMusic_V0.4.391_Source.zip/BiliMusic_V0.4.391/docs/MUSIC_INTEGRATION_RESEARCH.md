# Music integration design notes — V0.4.391

Research checked on 2026-11-23. The implementation deliberately separates the reference project's architecture from platform authorization claims.

## Architecture reference

The user-selected reference project, `virtual-kori/Bili-Danmu-Songs-For-Netease`, describes this local pipeline:

`Bilibili danmaku -> command parsing -> NetEase search -> queue -> local player`

It runs a NetEase API service on the same machine, uses a QR login flow, resolves a playable resource when the track is about to play, and uses a local media player. BiliMusic independently implements this pattern in Python / PySide6 and retains its own SQLite queue, settings, cache manager, and UI.

Reference: https://github.com/virtual-kori/Bili-Danmu-Songs-For-Netease

## Third-party API dependency

BiliMusic's local service wrapper depends on `@neteasecloudmusicapienhanced/api` version `4.41.1`. It is community-maintained and is not a NetEase official desktop SDK. Its endpoints and login/session behavior may change without notice. The BiliMusic launcher binds only to `127.0.0.1` and explicitly disables the package's generic-unblock and proxy switches.

Reference: https://github.com/NeteaseCloudMusicApiEnhanced/api-enhanced

## Playback semantics

- QR login is performed by the user through the NetEase mobile app.
- The account session is stored using Windows DPAPI and passed to the loopback API through an HTTP Cookie header, never placed in the URL query string.
- BiliMusic asks for the normal song playback resource using the account's current session and selected quality level.
- Missing URLs and preview-only resources are rejected. No generic unblock mode, proxy fallback, DRM decryption, or alternative source fallback is enabled.
- Temporary stream URLs are held in memory for the active playback and are not saved into the playback history or long-term media cache.

## Limitations and permissions

A working member account does not guarantee every song or quality is available to a third-party client. Regional availability, account state, licensing restrictions, upstream changes, and third-party API compatibility can all affect playback. Personal listening rights do not automatically grant livestream retransmission rights; users must separately confirm rights for OBS / livestream use.
