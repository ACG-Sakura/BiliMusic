# B站直播接入可行性记录（2026-11-21）

## 已从官方文档确认的事项

官方入口：
- 直播开放平台快速开始：<https://open-live.bilibili.com/document/849b924b-b421-8586-3e5e-765a72ec3840>
- 直播开放平台常见问题：<https://open-live.bilibili.com/document/5dffc297-6fd2-41ff-bd45-6e8b89e2a68e>
- 直播开放平台：<https://open-live.bilibili.com/>

截至记录日期，官方文档说明：

1. 直播创作者服务中心和开放平台鉴权逻辑相互独立，开发者需要单独入驻并申请开放平台开发者权限。
2. 入驻审核通过后，`access_key` 和 `access_secret` 会通过邮件发放。密钥用于官方请求签名，应当严格保密。
3. 直播消息长连接存在 `client` 与 `server` 两种模式：`client` 是一个房间一条长连接，`server` 是一条长连接接收已授权的多个房间消息。文档称开发者默认为 `client` 模式，且同一接入方暂不支持两种模式共存。
4. 通过长连接可接收的消息类型需要提前向 B站运营申请；没有申请的消息类型不会被推送。
5. 官方快速开始对 Web 开发者描述了自建服务端接入方式；其他开发者可以使用官方 API，或联系平台获得支持。因此，Windows 单机能否直接采用 client 模式、是否需要某个本地服务组件，以及具体申请类型，需要结合应用形态向平台确认。
6. 官方 `app/start` 流程使用主播身份码启动项目，并返回长连接信息、场次信息和主播信息。它可用于确认某个直播间会话的主播上下文，但不能据此推断它同时提供 B站大会员到期状态。

## 对 BiliMusic 架构的影响

- 当前设计继续采用纯 Windows 本地架构；优先研究官方 `client` 模式和官方支持的桌面/其他开发者接入路径。
- 不预先引入云服务器。若平台对某种接入形态明确要求远端服务端，再评估本地方案是否可替代；未确认前不改变“本地版”目标。
- `BilibiliClient` 接口已独立于 UI 和队列业务，后续可以在不改动点歌核心的前提下替换接入适配器。
- 消息适配层需要统一映射弹幕、礼物/大航海、SC、用户 open_id/UID 可用字段，以及消息去重标识。不同字段以最终获批的消息类型文档为准。
- 开放平台密钥不能硬编码或提交到 Git；后续应由用户在本机安全配置，并使用 Windows Credential Manager 或同等级系统凭据存储。

## 尚未确认、不能作出承诺的事项

### B站大会员资格校验

本轮查阅的直播开放平台接入文档没有证明第三方直播应用能通过获批接口读取账号的大会员有效状态和到期时间。B站登录、主播身份码、直播间主播信息和大会员资格是不同概念，不能混为一谈。BiliMusic 的“非大会员不可使用”门槛在找到明确、允许使用的校验接口之前，不能标记为已实现。

### 本地单机接入

官方文档描述了 `client/server` 模式，但没有在快速开始页面中完整说明普通 Windows 桌面工具使用 client 模式的全部注册、授权与运行条件。实施前需要确认：

- 个人开发者能否以当前产品类型申请并获批。
- `DANMU_MSG`、礼物/大航海、SC 等具体消息类型是否可申请。
- Windows 桌面端能否直接持有 client 长连接，还是需要本机辅助服务。
- 主播身份码是否可由主播在 BiliMusic 内安全录入，是否存在产品形态要求。

## 下一步执行清单

1. 先确认用户是否具备申请 B站开放平台开发者资质的条件，并由用户本人在官方页面完成申请。
2. 向 B站确认 Windows 单机工具的 client 模式接入路径和可申请消息类型。
3. 收到正式文档/权限后，开发实际适配器并加入消息样本回放测试。
4. 单独确认大会员状态校验的合法接口；若不存在，就必须调整“必须大会员”的产品门槛，不能使用未授权接口或伪装状态。

## V0.3.0 implementation notes (2026-11-22)

The V0.3.0 preview adds a local official-API connector implementation:

- `/v2/app/start` obtains `game_id`, `wss_link`, `auth_body` and anchor context.
- `/v2/app/heartbeat` is scheduled at the documented 20-second cadence after connection setup.
- `/v2/app/end` is called as part of the orderly shutdown path.
- The websocket protocol layer sends an AUTH packet, processes AUTH_REPLY and message packets, and sends transport heartbeats.
- Open Platform event envelopes are mapped to the existing `LiveMessage` model. Where an Open Platform `open_id` is available it is used as the app-scoped requester key; it is not represented as a numeric Bilibili UID.
- Credentials are encrypted with Windows DPAPI for the current Windows user.

This is still an integration preview. The project has not been tested against an approved Bilibili application and real credentials. The exact HMAC request signature and websocket payload handling must be verified in Bilibili's developer test environment against the current official demo/specification before treating this connector as production-ready. A Windows local desktop client's eligibility for client-mode WSS also remains subject to Bilibili's confirmation.

Official documentation used for lifecycle decisions:
- Quick start: <https://open-live.bilibili.com/document/849b924b-b421-8586-3e5e-765a72ec3840>
- Official API: <https://open-live.bilibili.com/document/eba8e2e1-847d-e908-2e5c-7a1ec7d9266f>
- FAQ: <https://open-live.bilibili.com/document/5dffc297-6fd2-41ff-bd45-6e8b89e2a68e>
