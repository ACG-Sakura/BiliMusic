import hashlib
import hmac
import json
import struct
import zlib
from unittest.mock import patch

import pytest

from app.integrations.bilibili.open_live_api import (
    BilibiliOpenLiveApi,
    OpenLiveApiError,
    OpenLiveCredentials,
)
from app.integrations.bilibili.open_live_events import map_open_live_event
from app.integrations.bilibili.open_live_protocol import (
    OP_AUTH,
    OP_MESSAGE,
    ProtocolError,
    pack_packet,
    unpack_packets,
    decode_json_body,
)
from app.integrations.bilibili.credential_store import _json_bytes, CredentialStoreError, WindowsCredentialStore


class FakeResponse:
    def __init__(self, payload):
        self.payload = json.dumps(payload).encode("utf-8")

    def read(self):
        return self.payload

    def close(self):
        pass


def _creds():
    return OpenLiveCredentials(
        app_id=1234567890123,
        access_key="test-access-key",
        access_secret="test-access-secret",
        auth_code="test-anchor-code",
    )


def test_credentials_validate_requires_all_fields_and_int64():
    _creds().validate()
    with pytest.raises(ValueError):
        OpenLiveCredentials(0, "key", "secret", "code").validate()
    with pytest.raises(ValueError):
        OpenLiveCredentials(1, "", "secret", "code").validate()
    with pytest.raises(ValueError):
        OpenLiveCredentials(1, "key", "secret", "").validate()


def test_signed_headers_use_body_md5_and_sorted_hmac():
    api = BilibiliOpenLiveApi(_creds())
    body = b'{"hello":"world"}'
    with patch("app.integrations.bilibili.open_live_api.time.time", return_value=1700000000), \
         patch("app.integrations.bilibili.open_live_api.secrets.token_hex", return_value="nonce-fixed"):
        headers = api._signed_headers(body)
    assert headers["x-bili-content-md5"] == hashlib.md5(body).hexdigest()
    signed = {k: v for k, v in headers.items() if k.startswith("x-bili-")}
    canonical = "\n".join(f"{key}:{signed[key]}" for key in sorted(signed))
    expected = hmac.new(b"test-access-secret", canonical.encode(), hashlib.sha256).hexdigest()
    assert headers["Authorization"] == expected
    assert headers["x-bili-timestamp"] == "1700000000"


def test_start_parses_official_session_and_wss_fallbacks():
    seen = []
    response = {
        "code": 0,
        "message": "ok",
        "data": {
            "game_info": {"game_id": "game-1"},
            "websocket_info": {
                "auth_body": '{"key":"redacted-test-auth"}',
                "wss_link": ["wss://one.example/ws", "wss://two.example/ws"],
            },
            "anchor_info": {"room_id": 778899, "uname": "主播", "uid": 100},
        },
    }

    def fake_opener(request, timeout):
        seen.append((request, timeout, request.data))
        return FakeResponse(response)

    api = BilibiliOpenLiveApi(_creds(), opener=fake_opener)
    session = api.start()
    assert session.game_id == "game-1"
    assert session.room_id == 778899
    assert session.websocket_urls == ("wss://one.example/ws", "wss://two.example/ws")
    assert session.auth_body == b'{"key":"redacted-test-auth"}'
    assert session.anchor_name == "主播"
    sent = json.loads(seen[0][2].decode("utf-8"))
    assert sent == {"code": "test-anchor-code", "app_id": 1234567890123}
    assert "/v2/app/start" in seen[0][0].full_url


def test_start_rejects_missing_ws_or_room_fields():
    response = {"code": 0, "data": {"game_info": {"game_id": "g"}, "websocket_info": {}, "anchor_info": {}}}
    api = BilibiliOpenLiveApi(_creds(), opener=lambda *_a, **_k: FakeResponse(response))
    with pytest.raises(OpenLiveApiError, match="启动响应缺少"):
        api.start()


def test_api_nonzero_result_is_reported_without_credentials():
    response = {"code": 5002, "message": "invalid app"}
    api = BilibiliOpenLiveApi(_creds(), opener=lambda *_a, **_k: FakeResponse(response))
    with pytest.raises(OpenLiveApiError, match="5002") as error:
        api.heartbeat("game")
    assert "test-access-secret" not in str(error.value)


def test_pack_and_unpack_auth_packet_round_trip():
    packed = pack_packet(OP_AUTH, b'{"auth":true}')
    packet, = list(unpack_packets(packed))
    assert packet.operation == OP_AUTH
    assert packet.body == b'{"auth":true}'


def test_unpack_multiple_packets_and_zlib_nested_packet():
    event_bytes = json.dumps({"cmd": "LIVE_OPEN_PLATFORM_DM", "data": {"msg": "hi"}}).encode()
    inner = pack_packet(OP_MESSAGE, event_bytes)
    compressed = struct.pack(">IHHII", 16 + len(zlib.compress(inner)), 16, 2, OP_MESSAGE, 1) + zlib.compress(inner)
    packets = list(unpack_packets(pack_packet(OP_AUTH, b"x") + compressed))
    assert len(packets) == 2
    assert packets[1].operation == OP_MESSAGE
    assert decode_json_body(packets[1])["cmd"] == "LIVE_OPEN_PLATFORM_DM"


def test_unpack_rejects_incomplete_or_malformed_packet():
    with pytest.raises(ProtocolError):
        list(unpack_packets(b"short"))
    with pytest.raises(ProtocolError):
        list(unpack_packets(struct.pack(">IHHII", 10, 16, 0, 5, 1)))


def test_map_official_danmaku_uses_app_scoped_open_id():
    message = map_open_live_event({
        "cmd": "LIVE_OPEN_PLATFORM_DM",
        "data": {
            "open_id": "open-id-abc", "uname": "观众", "msg": "点歌 晴天 周杰伦",
            "fans_medal_level": 8, "fans_medal_name": "测试牌",
        },
    }, room_id=778899)
    assert message.message_type == "danmaku"
    assert message.uid == "open-id-abc"
    assert message.room_id == 778899
    assert message.text == "点歌 晴天 周杰伦"
    assert message.fan_badge_level == 8


def test_map_official_sc_and_guard_events():
    sc = map_open_live_event({
        "cmd": "LIVE_OPEN_PLATFORM_SUPER_CHAT",
        "data": {"open_id": "open-sc", "uname": "SC观众", "message": "点歌 测试曲", "rmb": 30},
    }, 1)
    assert sc.message_type == "sc"
    assert sc.sc_amount == 30
    assert sc.text == "点歌 测试曲"

    guard = map_open_live_event({
        "cmd": "LIVE_OPEN_PLATFORM_GUARD",
        "data": {"user_info": {"open_id": "open-guard", "uname": "舰长用户"}, "guard_level": 3},
    }, 1)
    assert guard.message_type == "guard"
    assert guard.guard_level == 3


def test_credential_json_has_only_expected_fields_and_dpapi_is_windows_only(tmp_path):
    credentials = {
        "app_id": "123", "access_key": "key", "access_secret": "secret", "auth_code": "code",
    }
    assert json.loads(_json_bytes(credentials)) == credentials
    with pytest.raises(ValueError):
        _json_bytes({**credentials, "extra": "not-allowed"})
    store = WindowsCredentialStore(tmp_path / "secure.bin")
    if __import__("os").name != "nt":
        with pytest.raises(CredentialStoreError):
            store.save(credentials)
    else:
        store.save(credentials)
        encrypted = store.path.read_bytes()
        assert b"test-access-secret" not in encrypted
        assert store.load() == credentials
        store.delete()
        assert not store.path.exists()


def test_heartbeat_and_end_use_documented_payloads():
    seen = []

    def fake_opener(request, timeout):
        seen.append((request.full_url, json.loads(request.data.decode("utf-8"))))
        return FakeResponse({"code": 0, "message": "ok", "data": {}})

    api = BilibiliOpenLiveApi(_creds(), opener=fake_opener)
    api.heartbeat("session-x")
    api.end(9876543210, "session-x")
    assert seen == [
        ("https://live-open.biliapi.com/v2/app/heartbeat", {"game_id": "session-x"}),
        ("https://live-open.biliapi.com/v2/app/end", {"app_id": 9876543210, "game_id": "session-x"}),
    ]


def test_background_client_socket_auth_and_event_dispatch(monkeypatch):
    from app.integrations.bilibili.open_live_api import OpenLiveSession
    from app.integrations.bilibili.open_live_client import OfficialBilibiliOpenLiveClient

    class FakeSocket:
        def __init__(self, stop_event):
            self.sent = []
            self.stop_event = stop_event
            self.closed = False
            self.receive_count = 0

        def send_binary(self, data):
            self.sent.append(data)

        def recv(self):
            self.receive_count += 1
            if self.receive_count == 1:
                return pack_packet(8, b'{"code":0}')
            if self.receive_count == 2:
                msg = json.dumps({
                    "cmd": "LIVE_OPEN_PLATFORM_DM",
                    "data": {"open_id": "oid-1", "uname": "测试观众", "msg": "点歌 云与海"},
                }).encode("utf-8")
                self.stop_event.set()
                return pack_packet(OP_MESSAGE, msg)
            return None

        def close(self):
            self.closed = True

    callbacks = []
    states = []
    client = OfficialBilibiliOpenLiveClient(callbacks.append, lambda s, d: states.append((s, d)))
    sock = FakeSocket(client._stop)
    monkeypatch.setattr("app.integrations.bilibili.open_live_client.websocket.create_connection", lambda *a, **k: sock)
    session = OpenLiveSession(
        app_id=1, game_id="g-1", room_id=7788,
        websocket_urls=("wss://unit.test/ws",), auth_body=b'{"auth":true}',
    )
    class FakeApi:
        def heartbeat(self, game_id):
            raise AssertionError("No heartbeat expected in the short protocol test")
    client._run_socket("wss://unit.test/ws", session)
    assert sock.sent[0] == pack_packet(OP_AUTH, b'{"auth":true}')
    assert any(state == "connected" for state, _ in states)
    assert callbacks[0].uid == "oid-1"
    assert callbacks[0].text == "点歌 云与海"
    assert sock.closed
