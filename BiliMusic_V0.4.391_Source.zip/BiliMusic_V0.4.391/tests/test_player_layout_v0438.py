from pathlib import Path


def test_player_page_layout_is_lyrics_then_parallel_local_library_and_history():
    source = Path(__file__).parents[1] / "app" / "ui" / "main_window.py"
    code = source.read_text(encoding="utf-8")
    player_page = code.split("    def player_page(self):", 1)[1].split("    def resume_or_start_playback", 1)[0]

    lyrics_pos = player_page.index('"歌词"')
    local_pos = player_page.index('"本地音频库"')
    history_pos = player_page.index('"最近播放记录"')
    assert lyrics_pos < local_pos < history_pos
    assert "panels.addWidget(local_library, 1)" in player_page
    assert "panels.addWidget(history_box, 1)" in player_page
    assert "layout.addLayout(panels)" in player_page


def test_playlist_management_no_longer_contains_local_audio_library_panel():
    source = Path(__file__).parents[1] / "app" / "ui" / "main_window.py"
    code = source.read_text(encoding="utf-8")
    playlist_page = code.split("    def playlists_page(self):", 1)[1].split("    def _netease_login_status_text", 1)[0]
    assert '"本地备用音频库"' not in playlist_page
    assert '"本地音频库"' not in playlist_page
