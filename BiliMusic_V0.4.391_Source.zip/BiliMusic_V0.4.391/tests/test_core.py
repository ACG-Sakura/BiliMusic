import tempfile
import unittest
from pathlib import Path

from app.core.queue_service import QueueService
from app.core.priority import resolve_priority
from app.core.settings import SettingsStore
from app.storage.database import Database


class BiliMusicCoreTests(unittest.TestCase):
    def setUp(self):
        self.tempdir = tempfile.TemporaryDirectory()
        self.db = Database(Path(self.tempdir.name) / "test.db")
        self.db.initialize()
        self.queue = QueueService(self.db)
        self.settings = SettingsStore(self.db)

    def tearDown(self):
        self.tempdir.cleanup()

    def test_priority_order_and_fifo(self):
        normal_1 = self.queue.enqueue("普通歌1")
        normal_2 = self.queue.enqueue("普通歌2")
        captain = self.queue.enqueue("舰长歌", kind="captain")
        sc = self.queue.enqueue("SC歌", kind="sc", priority=75)
        ids = [song.id for song in self.queue.list_queue()]
        self.assertEqual(ids, [sc, captain, normal_1, normal_2])

    def test_move_within_same_priority(self):
        first = self.queue.enqueue("第一首")
        second = self.queue.enqueue("第二首")
        third = self.queue.enqueue("第三首")
        self.assertTrue(self.queue.move(third, -1))
        self.assertEqual([s.id for s in self.queue.list_queue()], [first, third, second])

    def test_host_can_override_priority_order_across_bands(self):
        normal = self.queue.enqueue("普通歌")
        captain = self.queue.enqueue("舰长歌", kind="captain")
        self.assertTrue(self.queue.move(normal, -1))
        self.assertEqual([s.id for s in self.queue.list_queue()], [normal, captain])

    def test_new_song_appends_after_host_manual_reorder(self):
        first = self.queue.enqueue("第一首")
        second = self.queue.enqueue("第二首")
        captain = self.queue.enqueue("舰长歌曲", kind="captain")
        self.queue.reorder([first, second, captain])
        later_sc = self.queue.enqueue("后来添加的 SC", kind="sc", priority=999)
        self.assertEqual([s.id for s in self.queue.list_queue()], [first, second, captain, later_sc])

    def test_move_to_position_drag_second_song_to_first(self):
        first = self.queue.enqueue("第一首")
        second = self.queue.enqueue("第二首")
        third = self.queue.enqueue("第三首")
        self.assertTrue(self.queue.move_to_position(second, 0))
        self.assertEqual([s.id for s in self.queue.list_queue()], [second, first, third])

    def test_move_to_position_drag_first_song_to_last(self):
        first = self.queue.enqueue("第一首")
        second = self.queue.enqueue("第二首")
        third = self.queue.enqueue("第三首")
        self.assertTrue(self.queue.move_to_position(first, 2))
        self.assertEqual([s.id for s in self.queue.list_queue()], [second, third, first])

    def test_move_to_position_rejects_invalid_song_or_row(self):
        first = self.queue.enqueue("第一首")
        self.assertFalse(self.queue.move_to_position(99999, 0))
        self.assertFalse(self.queue.move_to_position(first, 5))
        self.assertEqual([s.id for s in self.queue.list_queue()], [first])

    def test_reorder_requires_exact_queue_members(self):
        first = self.queue.enqueue("第一首")
        self.queue.enqueue("第二首")
        with self.assertRaises(ValueError):
            self.queue.reorder([first, first])

    def test_remove_only_queued_song(self):
        song_id = self.queue.enqueue("待删除")
        self.assertTrue(self.queue.remove(song_id))
        self.assertFalse(self.queue.remove(song_id))
        self.assertEqual(self.queue.list_queue(), [])

    def test_remove_all_queued_preserves_non_queued_history(self):
        first = self.queue.enqueue("待删除一")
        second = self.queue.enqueue("待删除二")
        self.queue.mark_playing(first)
        removed = self.queue.remove_all_queued()
        self.assertEqual(removed, 1)
        self.assertEqual(self.queue.list_queue(), [])
        self.assertEqual(self.db.fetchone("SELECT status FROM songs WHERE id=?", (first,))["status"], "playing")
        self.assertEqual(self.db.fetchone("SELECT status FROM songs WHERE id=?", (second,))["status"], "cancelled")

    def test_new_cooldown_defaults_and_legacy_migration(self):
        self.assertEqual(self.settings.get("captain_cooldown_seconds"), 180)
        self.assertEqual(self.settings.get("normal_badge_cooldown_seconds"), 300)
        self.settings.set("user_cooldown_seconds", 420)
        self.db.execute("DELETE FROM settings WHERE key='normal_badge_cooldown_seconds'")
        migrated = SettingsStore(self.db)
        self.assertEqual(migrated.get("normal_badge_cooldown_seconds"), 420)
        self.assertEqual(migrated.get("captain_cooldown_seconds"), 180)

    def test_sc_priority_uses_highest_eligible_amount_tier(self):
        rules = [
            {"min_amount": 30, "priority": 50},
            {"min_amount": 50, "priority": 60},
            {"min_amount": 100, "priority": 70},
        ]
        self.assertEqual(resolve_priority("sc", 20, rules), 50)
        self.assertEqual(resolve_priority("sc", 50, rules), 60)
        self.assertEqual(resolve_priority("sc", 150, rules), 70)
        self.assertEqual(resolve_priority("captain"), 20)

    def test_settings_are_persistent(self):
        self.settings.set("daily_limit", 7)
        new_store = SettingsStore(self.db)
        self.assertEqual(new_store.get("daily_limit"), 7)

    def test_queue_reads_custom_sc_rules_from_settings(self):
        self.settings.set("sc_priority_rules", [
            {"min_amount": 10, "priority": 90},
            {"min_amount": 100, "priority": 120},
        ])
        configured_queue = QueueService(self.db, self.settings)
        normal_id = configured_queue.enqueue("普通")
        sc_id = configured_queue.enqueue("SC歌曲", kind="sc", sc_amount=30)
        self.assertEqual([s.id for s in configured_queue.list_queue()], [sc_id, normal_id])
        self.assertEqual(configured_queue.get_song(sc_id).priority, 90)

    def test_blank_song_rejected(self):
        with self.assertRaises(ValueError):
            self.queue.enqueue("  ")

    def test_database_migrates_old_v01_schema(self):
        old_path = Path(self.tempdir.name) / "old.db"
        import sqlite3
        conn = sqlite3.connect(old_path)
        conn.execute("""CREATE TABLE songs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            artist TEXT DEFAULT '',
            requester TEXT DEFAULT '',
            source TEXT DEFAULT '',
            position INTEGER NOT NULL DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )""")
        conn.execute("INSERT INTO songs(title, requester) VALUES ('旧版本歌曲', '旧版本点歌人')")
        conn.commit()
        conn.close()
        migrated = Database(old_path)
        migrated.initialize()
        columns = {row["name"] for row in migrated.fetchall("PRAGMA table_info(songs)")}
        self.assertIn("priority", columns)
        self.assertIn("requester_uid", columns)
        migrated_song = migrated.fetchone("SELECT requester_name FROM songs WHERE title='旧版本歌曲'")
        self.assertEqual(migrated_song["requester_name"], "旧版本点歌人")


if __name__ == "__main__":
    unittest.main()
