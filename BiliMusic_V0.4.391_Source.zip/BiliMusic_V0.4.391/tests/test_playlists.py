from app.storage.database import Database
from app.core.playlists import PlaylistService


def make_service(tmp_path):
    db = Database(tmp_path / "test.db")
    db.initialize()
    return db, PlaylistService(db)


def test_add_and_list_playlists(tmp_path):
    db, service = make_service(tmp_path)
    pid = service.add_playlist("通勤歌单", "网易云音乐", "https://music.163.com/playlist?id=123")
    rows = service.list_playlists()
    assert len(rows) == 1
    assert rows[0].id == pid
    assert rows[0].platform == "网易云音乐"
    assert rows[0].track_count == 0


def test_tracks_and_delete_cascade(tmp_path):
    db, service = make_service(tmp_path)
    pid = service.add_playlist("收藏", "网易云音乐", "987")
    service.add_track(pid, "晴天", "周杰伦")
    service.add_track(pid, "起风了")
    assert [x.title for x in service.list_tracks(pid)] == ["晴天", "起风了"]
    service.remove_playlist(pid)
    assert service.list_playlists() == []
    assert service.list_tracks(pid) == []


def test_playlist_mode_active_and_autoplay_persist(tmp_path):
    db, service = make_service(tmp_path)
    pid = service.add_playlist("循环", "网易云音乐")
    service.set_mode(pid, "列表循环")
    service.set_active(pid)
    service.set_autoplay(True)
    assert service.active_playlist_id() == pid
    assert service.list_playlists()[0].play_mode == "列表循环"
    assert service.autoplay_enabled() is True
    service.set_autoplay(False)
    assert service.autoplay_enabled() is False


def test_reject_invalid_platform_and_empty_title(tmp_path):
    db, service = make_service(tmp_path)
    try:
        service.add_playlist("x", "unknown")
        assert False, "invalid platform accepted"
    except ValueError:
        pass
    pid = service.add_playlist("x", "网易云音乐")
    try:
        service.add_track(pid, "   ")
        assert False, "empty track accepted"
    except ValueError:
        pass
