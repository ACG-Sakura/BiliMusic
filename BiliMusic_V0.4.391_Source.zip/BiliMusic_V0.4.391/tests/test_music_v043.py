from __future__ import annotations

import json
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import pytest

from app.core.playback import PlaybackCoordinator
from app.core.playlists import PlaylistService
from app.core.queue_service import QueueService
from app.integrations.music.netease import (
    NeteaseApiClient,
    NeteaseError,
    NeteasePlaylist,
    NeteaseTrack,
    parse_netease_playlist_id,
)
from app.storage.database import Database


class FakeBackend:
    def __init__(self):
        self.played = []
        self.played_urls = []
        self.stopped = 0
        self.paused = 0
        self.resumed = 0
        self.volume = 1.0
        self.on_stop = None

    def play_file(self, path):
        self.played.append(path)

    def play_url(self, url):
        self.played_urls.append(url)

    def pause(self): self.paused += 1
    def resume(self): self.resumed += 1
    def stop(self):
        self.stopped += 1
        if self.on_stop is not None:
            self.on_stop()
    def set_volume(self, value): self.volume = value


def make_services(tmp_path):
    db = Database(tmp_path / "test.db")
    db.initialize()
    playlists = PlaylistService(db)
    queue = QueueService(db)
    return db, playlists, queue


class FakeHeaders:
    def __init__(self, values=None):
        self.values = values or []

    def get_all(self, name):
        return self.values if name.lower() == "set-cookie" else []


class FakeResponse:
    def __init__(self, payload, headers=None):
        self.payload = payload
        self.headers = FakeHeaders(headers)

    def __enter__(self): return self
    def __exit__(self, *_): return False
    def read(self, _limit): return json.dumps(self.payload).encode("utf-8")


def test_local_audio_import_dedupe_and_title_matching(tmp_path):
    _db, service, _queue = make_services(tmp_path)
    audio = tmp_path / "晴天.mp3"
    audio.write_bytes(b"dummy test fixture")
    assert service.add_local_audio_files([audio, audio]) == 1
    tracks = service.list_local_audio_tracks()
    assert len(tracks) == 1
    assert tracks[0].title == "晴天"
    assert service.find_local_audio(" 晴天 ") == tracks[0]


def test_point_request_interrupts_local_autoplay_and_continues(tmp_path):
    _db, playlists, queue = make_services(tmp_path)
    first = tmp_path / "自动一.mp3"
    second = tmp_path / "晴天.mp3"
    first.write_bytes(b"a")
    second.write_bytes(b"b")
    playlists.add_local_audio_files([first, second])
    playlists.set_local_audio_mode("列表循环")
    playlists.set_autoplay(True)
    backend = FakeBackend()
    coordinator = PlaybackCoordinator(queue, playlists, backend)

    coordinator.poll()
    assert Path(backend.played[-1]).name == "自动一.mp3"
    assert coordinator.current_source == "autoplay"

    queue.enqueue("晴天", requester_name="观众A", source="danmaku")
    coordinator.poll()
    assert backend.stopped == 1
    assert Path(backend.played[-1]).name == "晴天.mp3"
    assert coordinator.current_source == "request"

    coordinator.on_track_ended()
    assert coordinator.current_source == "autoplay"
    assert Path(backend.played[-1]).name == "晴天.mp3"


def test_unmatched_request_is_skipped_and_autoplay_can_continue(tmp_path):
    db, playlists, queue = make_services(tmp_path)
    track = tmp_path / "本地歌曲.mp3"
    track.write_bytes(b"a")
    playlists.add_local_audio_files([track])
    playlists.set_autoplay(True)
    backend = FakeBackend()
    coordinator = PlaybackCoordinator(queue, playlists, backend)
    bad_id = queue.enqueue("曲库没有这首", requester_name="观众B", source="danmaku")

    coordinator.poll()

    status = db.fetchone("SELECT status FROM songs WHERE id=?", (bad_id,))["status"]
    assert status == "skipped"
    assert coordinator.current_source == "autoplay"
    assert Path(backend.played[-1]).name == "本地歌曲.mp3"


def test_playback_history_written(tmp_path):
    _db, playlists, _queue = make_services(tmp_path)
    playlists.record_playback("晴天", "周杰伦", "自动播放", "", "播放完成", "/music/qingtian.mp3", "start", "end")
    rows = playlists.playback_history()
    assert len(rows) == 1
    assert rows[0]["result"] == "播放完成"


def test_netease_playlist_id_parser_accepts_ids_and_share_urls():
    assert parse_netease_playlist_id("123456") == "123456"
    assert parse_netease_playlist_id("https://music.163.com/playlist?id=123456") == "123456"
    assert parse_netease_playlist_id("https://music.163.com/#/playlist?id=123456") == "123456"
    assert parse_netease_playlist_id("https://music.163.com/playlist/123456") == "123456"
    with pytest.raises(ValueError):
        parse_netease_playlist_id("not a playlist")


def test_netease_api_client_refuses_non_loopback_service():
    with pytest.raises(ValueError):
        NeteaseApiClient("https://example.com")
    with pytest.raises(ValueError):
        NeteaseApiClient("http://192.0.2.1:3000")


def test_netease_search_uses_cookie_header_not_query_string():
    requests = []

    def opener(request, timeout):
        requests.append(request)
        return FakeResponse({"code": 200, "result": {"songs": [
            {"id": 123, "name": "晴天", "ar": [{"name": "周杰伦"}],
             "al": {"name": "叶惠美"}, "dt": 269000, "fee": 1}
        ]}})

    client = NeteaseApiClient(cookie="MUSIC_U=secret; __csrf=token", opener=opener)
    songs = client.search("晴天", limit=5)
    assert len(songs) == 1
    assert songs[0].external_id == "123"
    assert songs[0].title == "晴天"
    assert songs[0].artist == "周杰伦"
    assert songs[0].fee == 1
    assert requests[0].get_header("Cookie") == "MUSIC_U=secret; __csrf=token"
    assert "secret" not in requests[0].full_url
    assert parse_qs(urlparse(requests[0].full_url).query)["keywords"] == ["晴天"]


def test_netease_qr_login_extracts_set_cookie_from_success_response():
    replies = [
        FakeResponse({"code": 200, "data": {"unikey": "qr-key"}}),
        FakeResponse({"code": 200, "data": {"qrimg": "data:image/png;base64,aGVsbG8="}}),
        FakeResponse({"code": 803, "message": "授权登录成功"}, [
            "MUSIC_U=member-session; Path=/; HttpOnly",
            "__csrf=csrf-value; Path=/; HttpOnly",
        ]),
    ]

    def opener(_request, timeout):
        return replies.pop(0)

    client = NeteaseApiClient(opener=opener)
    qr = client.qr_login_create()
    assert qr.key == "qr-key"
    assert NeteaseApiClient.decode_qr_image(qr.image_data_uri) == b"hello"
    result = client.qr_login_check(qr.key)
    assert result.code == 803
    assert "MUSIC_U=member-session" in result.cookie
    assert "__csrf=csrf-value" in result.cookie


def test_netease_playlist_fetches_all_pages():
    requests = []

    def opener(request, timeout):
        requests.append(request)
        parsed = urlparse(request.full_url)
        query = parse_qs(parsed.query)
        if parsed.path == "/playlist/detail":
            return FakeResponse({"code": 200, "playlist": {
                "id": 777, "name": "我的歌单", "description": "通勤", "coverImgUrl": "https://img.test/a.jpg",
                "trackCount": 3,
            }})
        offset = int(query["offset"][0])
        if offset == 0:
            songs = [
                {"id": 1, "name": "晴天", "ar": [{"name": "周杰伦"}]},
                {"id": 2, "name": "稻香", "ar": [{"name": "周杰伦"}]},
            ]
        else:
            songs = [{"id": 3, "name": "七里香", "ar": [{"name": "周杰伦"}]}]
        return FakeResponse({"code": 200, "songs": songs})

    client = NeteaseApiClient(opener=opener)
    playlist = client.fetch_playlist("https://music.163.com/playlist?id=777", page_size=2)
    assert playlist.name == "我的歌单"
    assert [track.title for track in playlist.tracks] == ["晴天", "稻香", "七里香"]
    page_offsets = [parse_qs(urlparse(r.full_url).query).get("offset", [None])[0]
                    for r in requests if urlparse(r.full_url).path == "/playlist/track/all"]
    assert page_offsets == ["0", "2"]


def test_netease_song_url_rejects_preview_and_invalid_url():
    def preview(_request, timeout):
        return FakeResponse({"code": 200, "data": [{
            "url": "https://media.test/preview.mp3", "freeTrialInfo": {"start": 0, "end": 30000}
        }]})

    with pytest.raises(NeteaseError, match="试听片段"):
        NeteaseApiClient(opener=preview).song_url(123)

    def invalid(_request, timeout):
        return FakeResponse({"code": 200, "data": [{"url": None}]})

    with pytest.raises(NeteaseError):
        NeteaseApiClient(opener=invalid).song_url(123)


def test_synced_netease_playlist_replaces_metadata_snapshot(tmp_path):
    _db, service, _queue = make_services(tmp_path)
    playlist_id = service.add_playlist("old", "网易云音乐", "123")
    service.add_track(playlist_id, "manual old")
    remote = NeteasePlaylist(
        "123", "已同步歌单", "说明", "https://img.example/cover.jpg", 1,
        (NeteaseTrack("163-id", "晴天", "周杰伦", "叶惠美", 269000, 1),),
    )
    service.replace_synced_tracks(playlist_id, remote)
    rows = service.list_tracks(playlist_id)
    assert len(rows) == 1
    assert rows[0].title == "晴天"
    assert rows[0].source_ref == "163-id"
    assert service.get_playlist(playlist_id)["name"] == "已同步歌单"


def test_v040_legacy_qq_rows_are_preserved_but_hidden(tmp_path):
    import sqlite3
    db_path = tmp_path / "legacy-v040.db"
    conn = sqlite3.connect(db_path)
    conn.execute("""CREATE TABLE playlists (
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
        platform TEXT NOT NULL CHECK(platform IN ('网易云音乐','QQ音乐')),
        source_ref TEXT NOT NULL DEFAULT '', play_mode TEXT NOT NULL DEFAULT '顺序播放',
        enabled INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )""")
    conn.execute("""CREATE TABLE playlist_tracks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        playlist_id INTEGER NOT NULL REFERENCES playlists(id) ON DELETE CASCADE,
        title TEXT NOT NULL, artist TEXT NOT NULL DEFAULT '',
        source_ref TEXT NOT NULL DEFAULT '', position INTEGER NOT NULL DEFAULT 0,
        UNIQUE(playlist_id, position)
    )""")
    conn.execute("INSERT INTO playlists(name,platform,source_ref) VALUES('旧歌单','QQ音乐','123456')")
    conn.execute("INSERT INTO playlist_tracks(playlist_id,title) VALUES(1,'旧歌曲')")
    conn.commit(); conn.close()

    db = Database(db_path)
    service = PlaylistService(db)
    assert service.list_playlists() == []
    assert service.get_playlist(1)["name"] == "旧歌单"
    assert service.list_tracks(1)[0].title == "旧歌曲"
    columns = {row["name"] for row in db.fetchall("PRAGMA table_info(playlists)")}
    assert "sync_status" in columns and "cover_url" in columns


def test_netease_remote_playlist_autoplay_is_interrupted_by_request_and_resumes_next(tmp_path):
    _db, playlists, queue = make_services(tmp_path)
    playlist_id = playlists.add_playlist("自动播放", "网易云音乐", "123")
    remote = NeteasePlaylist("123", "自动播放", "", "", 2, (
        NeteaseTrack("101", "歌曲 A", "歌手 A"),
        NeteaseTrack("102", "歌曲 B", "歌手 B"),
    ))
    playlists.replace_synced_tracks(playlist_id, remote)
    playlists.set_mode(playlist_id, "列表循环")
    playlists.set_active(playlist_id)
    playlists.set_autoplay(True)

    resolved = []
    backend = FakeBackend()
    coordinator = PlaybackCoordinator(
        queue, playlists, backend,
        on_remote_request=lambda ref, title, artist: resolved.append(("request", ref, title, artist)) or True,
        on_remote_playlist=lambda ref, sid, title, artist: resolved.append(("autoplay", ref, sid, title, artist)) or True,
    )

    coordinator.poll()
    first = resolved[-1]
    assert first[0] == "autoplay"
    assert coordinator.start_remote("autoplay", first[1], "https://media.test/a", first[3], first[4], first[2])

    request_id = queue.enqueue("观众点的歌", requester_name="观众甲", source="danmaku")
    coordinator.poll()
    assert backend.stopped == 1
    request = resolved[-1]
    assert request[0] == "request" and request[1] == request_id
    assert coordinator.start_remote("request", request_id, "https://media.test/request", "观众点的歌", "歌手", "999")

    coordinator.on_track_ended()
    next_autoplay = resolved[-1]
    assert next_autoplay[0] == "autoplay"
    assert next_autoplay[2] == "102"
    history = playlists.playback_history(20)
    assert history[0]["title"] == "观众点的歌"
    assert history[0]["file_path"] == ""  # temporary stream URLs are never persisted


def test_failed_netease_request_is_skipped_and_next_request_continues(tmp_path):
    _db, playlists, queue = make_services(tmp_path)
    first_id = queue.enqueue("不可播放歌曲", requester_name="甲", source="danmaku")
    second_id = queue.enqueue("下一首", requester_name="乙", source="danmaku")
    resolved = []
    backend = FakeBackend()
    coordinator = PlaybackCoordinator(
        queue, playlists, backend,
        on_remote_request=lambda ref, title, artist: resolved.append(ref) or True,
    )
    coordinator.poll()
    assert resolved == [first_id]
    coordinator.remote_failed("request", first_id, "资源不可用")
    assert resolved == [first_id, second_id]
    assert queue.get_song(first_id).status == "skipped"


def test_netease_song_url_falls_back_to_lower_requested_quality():
    requested = []

    def opener(request, timeout):
        level = parse_qs(urlparse(request.full_url).query)["level"][0]
        requested.append(level)
        if level == "lossless":
            return FakeResponse({"code": 200, "data": [{"url": None}]})
        return FakeResponse({"code": 200, "data": [{"url": "https://media.test/exhigh.mp3", "freeTrialInfo": None}]})

    url = NeteaseApiClient(opener=opener).song_url(123, "lossless")
    assert url == "https://media.test/exhigh.mp3"
    assert requested == ["lossless", "exhigh"]


def test_skip_current_preserves_following_queue_even_if_backend_stop_emits_end_callback(tmp_path):
    db, playlists, queue = make_services(tmp_path)
    backend = FakeBackend()
    coordinator = PlaybackCoordinator(
        queue, playlists, backend,
        on_remote_request=lambda _song_id, _title, _artist: True,
    )
    ids = [
        queue.enqueue(name, requester_name=f"观众{i}", source="danmaku")
        for i, name in enumerate(("歌曲 A", "歌曲 B", "歌曲 C", "歌曲 D"), start=1)
    ]
    coordinator.poll()
    assert coordinator._pending_remote == ("request", ids[0])
    assert coordinator.start_remote("request", ids[0], "https://example.test/a.mp3", "歌曲 A")

    # Simulate Qt emitting a completion callback synchronously from stop().
    backend.on_stop = coordinator.on_track_ended
    coordinator.skip_current()

    assert db.fetchone("SELECT status FROM songs WHERE id=?", (ids[0],))["status"] == "skipped"
    assert db.fetchone("SELECT status FROM songs WHERE id=?", (ids[1],))["status"] == "playing"
    assert [song.id for song in queue.list_queue()] == ids[2:]
    assert coordinator._pending_remote == ("request", ids[1])

    assert coordinator.start_remote("request", ids[1], "https://example.test/b.mp3", "歌曲 B")
    coordinator.skip_current()
    assert db.fetchone("SELECT status FROM songs WHERE id=?", (ids[1],))["status"] == "skipped"
    assert db.fetchone("SELECT status FROM songs WHERE id=?", (ids[2],))["status"] == "playing"
    assert [song.id for song in queue.list_queue()] == ids[3:]


def test_netease_login_status_returns_verified_profile():
    client = NeteaseApiClient(
        cookie="MUSIC_U=test-session",
        opener=lambda _request, timeout: FakeResponse({"data": {
            "account": {"id": 12345},
            "profile": {"userId": 12345, "nickname": "测试账号"},
        }}),
    )
    profile = client.login_status()
    assert profile["user_id"] == 12345
    assert profile["nickname"] == "测试账号"


def test_netease_login_status_rejects_saved_but_invalid_cookie():
    client = NeteaseApiClient(
        cookie="MUSIC_U=expired-session",
        opener=lambda _request, timeout: FakeResponse({"data": {
            "account": None,
            "profile": None,
        }}),
    )
    with pytest.raises(NeteaseError, match="尚未确认登录状态"):
        client.login_status()
