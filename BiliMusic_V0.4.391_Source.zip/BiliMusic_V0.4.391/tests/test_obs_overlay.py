from __future__ import annotations

import json
import socket
import time
import urllib.error
import urllib.request

import pytest
from websockets.sync.client import connect

from app.integrations.obs.server import OBSOverlayServer


def _http(port: int, path: str, headers: dict | None = None):
    request = urllib.request.Request(
        f"http://127.0.0.1:{port}{path}", headers=headers or {}, method="GET"
    )
    with urllib.request.urlopen(request, timeout=3) as response:
        return response.status, response.headers, response.read()


def test_obs_server_serves_health_overlay_assets_and_live_state():
    state = {
        "schemaVersion": 1,
        "timestamp": "2026-11-24T00:00:00Z",
        "current": {"id": "10", "title": "当前歌曲", "artist": "歌手", "requesterName": "观众甲"},
        "queue": [{"id": "11", "title": "待播歌曲", "artist": "歌手乙", "requesterName": "观众乙"}],
        "queueLength": 1,
        "display": {"background": "transparent", "alignment": "left"},
    }
    server = OBSOverlayServer(lambda: state, preferred_port=0)
    try:
        status = server.start()
        assert status["running"] is True
        assert status["port"] and status["port"] > 0
        port = status["port"]

        code, _headers, body = _http(port, "/health")
        assert code == 200
        assert json.loads(body)["ok"] is True

        code, headers, body = _http(port, "/overlay/")
        assert code == 200
        assert "text/html" in headers.get("Content-Type", "")
        assert b"BiliMusic" in body

        code, _headers, body = _http(port, "/overlay/app.js")
        assert code == 200
        assert b"WebSocket" in body

        code, _headers, body = _http(port, "/api/v1/state")
        assert json.loads(body)["current"]["requesterName"] == "观众甲"

        with connect(f"ws://127.0.0.1:{port}/ws", origin=f"http://127.0.0.1:{port}", open_timeout=3) as ws:
            initial = json.loads(ws.recv(timeout=3))
            assert initial["type"] == "state"
            assert initial["data"]["queue"][0]["requesterName"] == "观众乙"
            state["queue"].append({"id": "12", "title": "新增", "artist": "", "requesterName": "观众丙"})
            updated = json.loads(ws.recv(timeout=3))
            assert len(updated["data"]["queue"]) == 2
    finally:
        server.stop()
    assert server.status()["running"] is False


def test_obs_server_rejects_non_loopback_host_header():
    server = OBSOverlayServer(lambda: {"schemaVersion": 1}, preferred_port=0)
    try:
        status = server.start()
        port = status["port"]
        request = urllib.request.Request(
            f"http://127.0.0.1:{port}/health", headers={"Host": f"example.test:{port}"}
        )
        with pytest.raises(urllib.error.HTTPError) as exc:
            urllib.request.urlopen(request, timeout=3)
        assert exc.value.code == 403
    finally:
        server.stop()


def test_obs_server_falls_forward_when_preferred_port_is_occupied():
    with socket.socket() as occupied:
        occupied.bind(("127.0.0.1", 0))
        occupied.listen(1)
        preferred = occupied.getsockname()[1]
        server = OBSOverlayServer(lambda: {"schemaVersion": 1}, preferred_port=preferred)
        try:
            status = server.start()
            assert status["running"] is True
            assert status["port"] != preferred
            assert status["port"] > preferred
        finally:
            server.stop()


def test_obs_server_rejects_cross_origin_http_reads():
    server = OBSOverlayServer(lambda: {"schemaVersion": 1}, preferred_port=0)
    try:
        status = server.start()
        port = status["port"]
        request = urllib.request.Request(
            f"http://127.0.0.1:{port}/api/v1/state",
            headers={"Origin": "https://example.invalid"},
        )
        with pytest.raises(urllib.error.HTTPError) as exc:
            urllib.request.urlopen(request, timeout=3)
        assert exc.value.code == 403
    finally:
        server.stop()


def test_obs_state_uses_live_playback_metadata_and_queue_requesters():
    from types import SimpleNamespace

    from app.integrations.obs.state import build_obs_state

    current = SimpleNamespace(id=7, requester_name="点歌人甲", title="原始歌曲", artist="原始歌手", source="danmaku")
    queued = SimpleNamespace(id=8, title="待播歌曲", artist="待播歌手", requester_name="点歌人乙", source="danmaku")
    queue = SimpleNamespace(current_playing=lambda: current, list_queue=lambda: [queued])
    playback = SimpleNamespace(
        current_track=(SimpleNamespace(title="实际播放标题", artist="实际歌手"), "观众点歌", "点歌人甲"),
        current_source="request",
    )
    state = build_obs_state(queue, playback, {"alignment": "center"})
    assert state["current"] == {
        "id": "7", "title": "实际播放标题", "artist": "实际歌手",
        "requesterName": "点歌人甲", "source": "观众点歌",
    }
    assert state["queue"][0]["requesterName"] == "点歌人乙"
    assert state["queueLength"] == 1
    assert state["display"]["alignment"] == "center"


def test_obs_state_supports_playlist_playback_without_requester():
    from types import SimpleNamespace

    from app.integrations.obs.state import build_obs_state

    queue = SimpleNamespace(current_playing=lambda: None, list_queue=lambda: [])
    playback = SimpleNamespace(
        current_track=(SimpleNamespace(title="歌单曲目", artist="歌手"), "自动播放", ""),
        current_source="autoplay",
    )
    state = build_obs_state(queue, playback)
    assert state["current"]["requesterName"] == "歌单播放"
    assert state["queue"] == []


def test_obs_state_ignores_stale_database_playing_row_after_app_restart():
    from types import SimpleNamespace

    from app.integrations.obs.state import build_obs_state

    stale = SimpleNamespace(id=12, title="旧的歌曲", artist="歌手", requester_name="旧点歌人", source="danmaku")
    queue = SimpleNamespace(current_playing=lambda: stale, list_queue=lambda: [])
    playback = SimpleNamespace(current_track=None, current_source=None, _pending_remote=None)
    assert build_obs_state(queue, playback)["current"] is None


def test_obs_state_shows_request_while_remote_stream_is_resolving():
    from types import SimpleNamespace

    from app.integrations.obs.state import build_obs_state

    pending = SimpleNamespace(id=13, title="解析中的歌", artist="歌手", requester_name="点歌观众", source="danmaku")
    queue = SimpleNamespace(current_playing=lambda: pending, list_queue=lambda: [])
    playback = SimpleNamespace(current_track=None, current_source="request", _pending_remote=("request", 13))
    assert build_obs_state(queue, playback)["current"]["requesterName"] == "点歌观众"
