from __future__ import annotations

import json
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from app.core.cache_manager import CacheManager
from app.core.playback import PlaybackCoordinator
from app.core.playlists import PlaylistService
from app.core.queue_service import QueueService
from app.integrations.music.netease import (
    NeteaseApiClient,
    NeteasePlaylist,
    NeteaseTrack,
    parse_lyric_payload,
)
from app.storage.database import Database


class FakeBackend:
    def __init__(self):
        self.played_urls = []
        self.played_files = []
        self.stop_count = 0

    def play_url(self, url):
        self.played_urls.append(url)

    def play_file(self, path):
        self.played_files.append(path)

    def pause(self):
        pass

    def resume(self):
        pass

    def stop(self):
        self.stop_count += 1

    def set_volume(self, value):
        pass


def make_services(tmp_path):
    db = Database(tmp_path / "features.db")
    db.initialize()
    return db, PlaylistService(db), QueueService(db)


class FakeHeaders:
    def get_all(self, name):
        return []


class FakeResponse:
    def __init__(self, payload):
        self.payload = payload
        self.headers = FakeHeaders()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        return False

    def read(self, _limit):
        return json.dumps(self.payload).encode("utf-8")


def test_parse_lyric_payload_merges_original_translation_and_multiple_timestamps():
    rows = parse_lyric_payload({
        "lrc": {"lyric": "[00:01.00][00:02.25]第一句\n[00:03.000]第二句"},
        "tlyric": {"lyric": "[00:01.00]First line\n[00:03.000]Second line"},
    })

    assert rows == [
        {"time_ms": 1000, "text": "第一句", "translation": "First line"},
        {"time_ms": 2250, "text": "第一句", "translation": ""},
        {"time_ms": 3000, "text": "第二句", "translation": "Second line"},
    ]


def test_netease_client_fetches_timed_lyrics_using_song_id_and_cookie():
    seen = []

    def opener(request, timeout):
        seen.append(request)
        return FakeResponse({
            "code": 200,
            "lrc": {"lyric": "[00:00.50]测试歌词"},
            "tlyric": {"lyric": "[00:00.50]Test lyric"},
        })

    client = NeteaseApiClient(cookie="MUSIC_U=secret", opener=opener)
    rows = client.lyrics("12345")
    assert rows[0]["time_ms"] == 500
    assert rows[0]["text"] == "测试歌词"
    assert rows[0]["translation"] == "Test lyric"
    assert seen[0].get_header("Cookie") == "MUSIC_U=secret"
    assert parse_qs(urlparse(seen[0].full_url).query)["id"] == ["12345"]


def test_play_all_playlist_runs_even_when_global_autoplay_is_disabled(tmp_path):
    _db, playlists, queue = make_services(tmp_path)
    playlist_id = playlists.add_playlist("整张歌单", "网易云音乐", "123")
    remote = NeteasePlaylist(
        playlist_id="123",
        name="整张歌单",
        description="",
        cover_url="",
        total_count=3,
        tracks=(
            NeteaseTrack("101", "歌曲 A", "歌手 A"),
            NeteaseTrack("102", "歌曲 B", "歌手 B"),
            NeteaseTrack("103", "歌曲 C", "歌手 C"),
        ),
    )
    playlists.replace_synced_tracks(playlist_id, remote)
    playlists.set_autoplay(False)
    requested = []

    def resolve_playlist(track_id, song_id, title, artist):
        requested.append((track_id, song_id, title, artist))
        return True

    backend = FakeBackend()
    coordinator = PlaybackCoordinator(
        queue, playlists, backend,
        on_remote_playlist=resolve_playlist,
    )

    assert coordinator.play_playlist(playlist_id) is True
    assert playlists.active_playlist_id() == playlist_id
    assert requested[0][1] == "101"

    assert coordinator.start_remote("autoplay", requested[0][0], "https://audio.test/a", "歌曲 A", "歌手 A", "101")
    coordinator.on_track_ended()
    assert requested[1][1] == "102"
    assert coordinator.start_remote("autoplay", requested[1][0], "https://audio.test/b", "歌曲 B", "歌手 B", "102")
    coordinator.on_track_ended()
    assert requested[2][1] == "103"


def test_clear_history_and_disposable_media_cache_preserve_original_audio(tmp_path):
    db, playlists, _queue = make_services(tmp_path)
    cache = CacheManager(db, tmp_path / "managed-cache")
    local_audio = tmp_path / "original.mp3"
    local_audio.write_bytes(b"user-owned-original")
    cached_source = tmp_path / "cached.bin"
    cached_source.write_bytes(b"cache-copy")

    playlists.record_playback("歌曲", "歌手", "自动播放", "", "播放完成", str(local_audio), "start", "end")
    disposable = cache.register_file("history:old-item", cached_source)
    protected = cache.register_file("history:current", cached_source, protected=True)

    removed_history = playlists.clear_playback_history()
    removed_cache = cache.clear_all()

    assert removed_history == 1
    assert playlists.playback_history() == []
    assert removed_cache == 1
    assert not disposable.exists()
    assert protected.exists()
    assert local_audio.read_bytes() == b"user-owned-original"


def test_explicit_playlist_waits_for_audience_request_then_resumes_playlist(tmp_path):
    _db, playlists, queue = make_services(tmp_path)
    playlist_id = playlists.add_playlist("背景歌单", "网易云音乐", "123")
    playlists.replace_synced_tracks(playlist_id, NeteasePlaylist(
        playlist_id="123", name="背景歌单", description="", cover_url="", total_count=1,
        tracks=(NeteaseTrack("201", "背景歌曲", "歌手"),),
    ))
    request_calls = []
    playlist_calls = []
    backend = FakeBackend()
    coordinator = PlaybackCoordinator(
        queue, playlists, backend,
        on_remote_request=lambda song_id, title, artist: request_calls.append(song_id) or True,
        on_remote_playlist=lambda track_id, song_id, title, artist: playlist_calls.append(song_id) or True,
    )
    request_id = queue.enqueue("观众歌曲", requester_name="观众", source="danmaku")

    coordinator.poll()
    assert request_calls == [request_id]
    assert coordinator.play_playlist(playlist_id) is True
    assert playlist_calls == []

    assert coordinator.start_remote("request", request_id, "https://audio.test/request", "观众歌曲", "观众", "999")
    coordinator.on_track_ended()
    assert playlist_calls == ["201"]
    assert coordinator._pending_remote == ("autoplay", playlists.list_tracks(playlist_id)[0].id)


def test_manual_full_playlist_finishes_after_last_track_when_autoplay_is_off(tmp_path):
    _db, playlists, queue = make_services(tmp_path)
    playlist_id = playlists.add_playlist("单曲歌单", "网易云音乐", "123")
    playlists.replace_synced_tracks(playlist_id, NeteasePlaylist(
        playlist_id="123", name="单曲歌单", description="", cover_url="", total_count=1,
        tracks=(NeteaseTrack("301", "唯一歌曲", "歌手"),),
    ))
    states = []
    backend = FakeBackend()
    coordinator = PlaybackCoordinator(
        queue, playlists, backend,
        on_state=lambda state, detail: states.append(state),
        on_remote_playlist=lambda *_args: True,
    )
    assert coordinator.play_playlist(playlist_id)
    track_row = playlists.list_tracks(playlist_id)[0]
    assert coordinator.start_remote("autoplay", track_row.id, "https://audio.test/one", "唯一歌曲", "歌手", "301")
    coordinator.on_track_ended()
    assert coordinator._playlist_playback_requested is False
    assert states[-1] == "歌单播放完成"
