from datetime import datetime, timedelta, timezone

import pytest

from app.core.cache_manager import CacheManager
from app.storage.database import Database


def make_cache(tmp_path):
    db = Database(tmp_path / "cache.db")
    db.initialize()
    return db, CacheManager(db, tmp_path / "cache")


def test_cache_register_get_and_protected_clear(tmp_path):
    db, cache = make_cache(tmp_path)
    source = tmp_path / "source.mp3"
    source.write_bytes(b"audio-bytes")
    cached = cache.register_file("song-a", source, protected=True)
    assert cached.read_bytes() == b"audio-bytes"
    assert cache.get("song-a") == cached
    assert cache.clear_all() == 0
    assert cached.exists()
    assert cache.get("song-a", protect=False) == cached
    assert cache.clear_all() == 1
    assert not cached.exists()
    assert cache.stats().files == 0


def test_cache_settings_validate_supported_capacity(tmp_path):
    _db, cache = make_cache(tmp_path)
    cache.configure(max_mb=1024, cleanup_interval_days=2, retention_days=14)
    assert cache.max_bytes == 1024 * 1024 * 1024
    with pytest.raises(ValueError):
        cache.configure(max_mb=333)


def test_cache_expiry_preserves_protected_entries(tmp_path):
    db, cache = make_cache(tmp_path)
    source = tmp_path / "old.mp3"
    source.write_bytes(b"x" * 32)
    path = cache.register_file("old", source)
    protected = cache.register_file("protected", source, protected=True)
    old = (datetime.now(timezone.utc) - timedelta(days=10)).isoformat(timespec="seconds")
    db.execute("UPDATE media_cache SET last_used_at=?", (old,))
    assert cache.cleanup_expired() == 1
    assert not path.exists()
    assert protected.exists()


def test_cache_capacity_lru_reduces_to_seventy_percent(tmp_path):
    db, cache = make_cache(tmp_path)
    cache.configure(max_mb=256)
    source = tmp_path / "large.bin"
    source.write_bytes(b"a" * (100 * 1024 * 1024))
    cache.register_file("one", source)
    cache.register_file("two", source)
    cache.register_file("three", source)
    stats = cache.stats()
    assert stats.bytes_used <= int(stats.max_bytes * 0.70)


def test_cleanup_scheduler_respects_daily_interval(tmp_path):
    _db, cache = make_cache(tmp_path)
    now = datetime.now(timezone.utc)
    cache.cleanup_if_due(now=now)
    assert cache.cleanup_if_due(now=now + timedelta(hours=12)) == 0
    assert cache.cleanup_if_due(now=now + timedelta(days=1, seconds=1)) >= 0
