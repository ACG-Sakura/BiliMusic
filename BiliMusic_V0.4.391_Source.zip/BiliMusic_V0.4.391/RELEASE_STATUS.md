# V0.4.391 Release Status

## 本版实现

- 基于用户提供的 `BiliMusic_V0.4.38_Source.zip` 建立 V0.4.391 源码目录。
- 新增 OBS 本机只读 HTTP + WebSocket 服务，绑定 `127.0.0.1`；首选端口默认 5556，冲突时顺延至最多 20 个后续端口。
- 提供 `/overlay/`、`/health`、`/api/v1/state`、`/api/v1/queue` 和 `/ws`。
- 状态由现有 `PlaybackCoordinator` 与 `QueueService` 生成，不额外维护一套歌曲队列。
- 新增 OBS 点歌列表页面：固定当前播放 1 首 + 待播 3 首；待播较多时上下循环滚动；每行长文本独立横向滚动。
- 新增服务开关、端口设置、复制地址、本机预览、背景/对齐/字号/透明度/文字颜色设置。
- 新增源代码、Windows 构建脚本和 GitHub Actions 对 OBS 网页资源及 websockets 依赖的打包配置。
- 未改动 B 站弹幕接入；BiliMusic 原有本机歌词面板保留，但本版不向 OBS 输出歌词。

## 本次实际验证

- `pytest -q`：93 项通过。
- `python -m compileall -q app tests main.py`：通过。
- `node --check app/integrations/obs/web/app.js`：通过。
- OBS 服务集成测试实际启动本机 HTTP / WebSocket，验证健康检查、HTML/CSS/JS 资源、状态 JSON、实时 WebSocket 更新、Host/Origin 拒绝和端口冲突回退。
- 项目元数据解析：`pyproject.toml` 版本为 `0.4.391`。

## 尚未完成的实机验收

- 当前容器未安装 PySide6，因此没有在此处启动完整 Qt 桌面界面。
- 没有在 Windows 上运行 PyInstaller；需要通过 GitHub Actions Windows 工作流或 Windows 本机 `build_windows.bat` 构建验收。
- 尚未实际打开 OBS Studio 浏览器源验证 Windows WebView 的显示效果、字体加载和动画节奏。
- 用户需要在 Windows 上验收：启动服务、复制 URL、OBS 加载、当前歌曲切换、队列超过三首时的纵向滚动、长文本横向滚动、端口冲突回退和退出时服务关闭。

## 可选字体

源码包不包含字体二进制文件。上传字体文件的内部 family metadata 与文件名不同，识别结果为 `蘋方-簡`；其授权/再分发条款未核实，因此没有把字体文件复制进发布包。若确认有权使用，请将本地字体放到：

`app/integrations/obs/web/fonts/super-hualunwan-85.ttf`

然后重新执行 Windows 构建。未放入时前端使用 Microsoft YaHei / 系统 sans-serif 回退字体。

## 版本范围

V0.4.391 专注 OBS 点歌队列展示，不包含 B 站直播弹幕或官方开放平台真实连接。相关接入等待用户告知开发者审核通过后再继续。
