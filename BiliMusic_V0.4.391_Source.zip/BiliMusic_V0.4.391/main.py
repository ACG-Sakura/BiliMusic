"""BiliMusic Windows desktop application entry point."""
from __future__ import annotations

import sys
from PySide6.QtWidgets import QApplication

from app.storage.database import Database
from app.core.settings import SettingsStore
from app.core.queue_service import QueueService
from app.ui.main_window import MainWindow


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("BiliMusic")
    app.setOrganizationName("BiliMusic")
    app.setStyle("Fusion")

    database = Database()
    database.initialize()
    settings = SettingsStore(database)
    queue = QueueService(database, settings)

    window = MainWindow(database=database, settings=settings, queue=queue)
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
