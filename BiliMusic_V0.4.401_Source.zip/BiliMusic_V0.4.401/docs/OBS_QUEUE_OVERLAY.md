# OBS 点歌队列展示（V0.4.401）

## 数据流

```text
PlaybackCoordinator + QueueService + SQLite
                  │
                  ▼
         OBSOverlayServer
      127.0.0.1:5556（端口可回退）
          │              │
          ▼              ▼
      HTTP GET        WebSocket
      /overlay/         /ws
      /health
      /api/v1/state
      /api/v1/queue
          │              │
          └──────┬───────┘
                 ▼
          OBS 浏览器来源
```

OBS 页面对现有状态进行只读展示，不维护第二份播放队列，也不提供控制接口。当前歌曲优先读取 `PlaybackCoordinator.current_track`；请求曲目仍在解析期间，回退到数据库中 `status='playing'` 的请求记录。待播列表来自 `QueueService.list_queue()`，顺序与桌面队列一致。

## 浏览器源

启动软件后进入「OBS 展示」并点击「启动服务」。页面会显示实际地址。默认首选端口为 5556，如果被占用，则在 5557–5576 中依次寻找可用端口。

建议尺寸：`1000 × 230`。页面的内容结构为顶部固定当前播放歌曲 + 下方三首待播歌曲。超过三首时以 22 px/s 连续匀速滚动并无缝循环；不足四首时保持静止。待播歌曲超过三首时以固定 22 px/s 匀速连续向上滚动并无缝循环；不超过三首时静止显示；单首歌曲信息超过可用宽度时独立水平滚动。

## 状态协议

`GET /api/v1/state` 返回：

```json
{
  "schemaVersion": 1,
  "timestamp": "ISO-8601 UTC",
  "current": {
    "id": "42",
    "title": "歌曲名称",
    "artist": "歌手",
    "requesterName": "点歌人",
    "source": "观众点歌"
  },
  "queue": [
    {
      "id": "43",
      "title": "待播歌曲",
      "artist": "歌手",
      "requesterName": "点歌人",
      "source": "danmaku"
    }
  ],
  "queueLength": 1,
  "display": {
    "background": "transparent",
    "alignment": "left",
    "fontSize": 28,
    "opacity": 0.72,
    "currentColor": "#F7FAFF",
    "queueColor": "#E7EFFF",
    "fontEnabled": false
  }
}
```

WebSocket `/ws` 连接后立即发送 `{ "type": "state", "data": <同上快照> }`；状态发生变化时再发送。WebSocket 断开时页面以每秒一次 HTTP 轮询兜底，并进行自动重连。服务绑定 `127.0.0.1`，检查 Host 与 Origin，不向外部网络提供接口。

## 安全与许可

- 仅 GET 状态读取和静态资源，不接受控制命令。
- 歌曲、歌手和昵称均通过前端 `textContent` 写入，不将外部文本作为 HTML 解析。
- 不接入 B 站直播弹幕，不读取 B 站登录态，也不主动控制直播间。
- OBS 默认使用系统字体。用户可在「OBS 展示」页面选择本地 TTF 字体；服务通过 `/overlay/custom-font` 只读提供该文件，不安装到 Windows、不复制进应用目录，也不随源码包分发。文件失效时页面回退系统字体。
