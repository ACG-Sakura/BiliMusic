# Changelog

## V0.1.4.2
- Fixed the post-drop blank/stale queue row: custom QDrag now carries a stable song ID without invoking Qt base-class source-row cleanup.
- Defer persistence and QTableWidget refresh until QDrag.exec() returns, then restore selection to the moved song.


## V0.1.4.1
- Fixed drag-and-drop queue ordering by moving songs through stable database IDs instead of Qt's native cell-level InternalMove behavior.
- A drop onto a row now inserts the dragged song at that row's position and persists the complete queue order.
- Added tests for dragging a song to the first/last position and invalid drag targets.


## V0.1.4
- Set the UI to a fixed blue-white light theme; removed appearance mode and accent-color controls.
- Reworked queue rules: ordinary fan-badge cooldown defaults to 300 seconds; captain/admiral/governor cooldown defaults to 180 seconds.
- Removed the global cooldown setting; SC requests are explicitly exempt from personal cooldowns in the rule UI.
- Replaced numeric spin boxes with validated text fields.
- Restyled the log-level filter.
- Added drag-and-drop queue ordering, confirmed single-song deletion, and confirmed clear-queue action.
- Added a queue service operation that cancels queued items without deleting playback history.


## V0.1.3
- Reworked the desktop UI around a consistent Material 3-inspired blue/white design system.
- Light mode is now the default; dark mode and system-following mode remain available.
- Redesigned dashboard, queue management, rules, accounts, OBS, logs, and settings pages.
- Added queue summary, clearer source labels, improved table sizing, and more obvious host controls.
- Added log text search and level filtering.
- Preserved the existing SQLite schema and queue/rule business logic.

## V0.1.2.1
- Improved SQLite connection lifecycle handling for Windows test runs.
