"""Bilibili video-audio fallback for NetEase playback.

Uses public Bilibili view/search/playurl endpoints. Playback is proxied locally
because Bilibili requires a Referer header that Qt Multimedia cannot attach.
No cookies are required for public video audio; an optional cookie can be used
for account-visible videos. No entitlement or paywall bypass is implemented.
"""
from __future__ import annotations

import hashlib
import json
import re
import secrets
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")
MIXIN_TAB = [46,47,18,2,53,8,23,32,15,50,10,31,58,3,45,35,27,43,5,49,33,9,42,19,29,28,14,39,12,38,41,13,37,48,7,16,24,55,40,61,26,17,0,1,60,51,30,4,22,25,54,21,56,59,6,63,57,62,11,36,20,34,44,52]


def _request(url: str, *, headers: dict[str, str] | None = None, timeout: int = 15) -> bytes:
    h = {"User-Agent": UA, "Referer": "https://www.bilibili.com/", **(headers or {})}
    req = urllib.request.Request(url, headers=h)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read(8 * 1024 * 1024 + 1)


def _json(url: str, headers: dict[str, str] | None = None) -> dict[str, Any]:
    raw = _request(url, headers=headers)
    if len(raw) > 8 * 1024 * 1024:
        raise RuntimeError("B站接口响应过大，已停止读取。")
    try:
        data = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise RuntimeError("B站接口返回了无法识别的数据。") from exc
    if int(data.get("code", -1)) != 0:
        raise BilibiliApiError(
            int(data.get("code", -1)),
            str(data.get("message") or data.get("msg") or "未知错误"),
        )
    return data.get("data") or {}


def _mixin_key(img_url: str, sub_url: str) -> str:
    def stem(value: str) -> str:
        return value.rsplit("/", 1)[-1].split(".", 1)[0]
    raw = stem(img_url) + stem(sub_url)
    if len(raw) < 64:
        raise RuntimeError("B站 WBI 密钥格式不正确。")
    return "".join(raw[i] for i in MIXIN_TAB)[:32]


class BilibiliApiError(RuntimeError):
    """A structured error returned by a Bilibili API endpoint."""

    def __init__(self, code: int, message: str):
        self.code = int(code)
        self.message = str(message or "未知错误")
        super().__init__(f"B站接口错误 code={self.code}：{self.message}")


class BilibiliVideoClient:
    def __init__(self, cookie: str = ""):
        self.cookie = cookie.strip()
        self._key = ""
        self._key_at = 0.0

    @property
    def headers(self) -> dict[str, str]:
        result = {"User-Agent": UA, "Referer": "https://www.bilibili.com/"}
        if self.cookie:
            result["Cookie"] = self.cookie
        return result

    def _wbi_url(self, base: str, params: dict[str, Any]) -> str:
        if not self._key or time.time() - self._key_at > 6 * 3600:
            nav = _json("https://api.bilibili.com/x/web-interface/nav", headers=self.headers)
            wbi = nav.get("wbi_img") or {}
            self._key = _mixin_key(wbi.get("img_url", ""), wbi.get("sub_url", ""))
            self._key_at = time.time()
        values = {**params, "wts": str(int(time.time()))}
        clean = {k: re.sub(r"[!'()*]", "", str(v)) for k, v in values.items()}
        query = urllib.parse.urlencode(sorted(clean.items()), quote_via=urllib.parse.quote, safe="")
        values["w_rid"] = hashlib.md5((query + self._key).encode()).hexdigest()
        return base + "?" + urllib.parse.urlencode(sorted(values.items()), quote_via=urllib.parse.quote, safe="")

    @staticmethod
    def _parse_ref(ref: str) -> tuple[str, int]:
        text = (ref or "").strip()
        page_match = re.search(r"[?&]p=(\d+)", text, re.I) or re.search(r"\s+[Pp](\d+)$", text)
        page = max(1, int(page_match.group(1))) if page_match else 1
        m = re.search(r"[Bb][Vv][0-9A-Za-z]{10}", text)
        if m:
            return "BV" + m.group(0)[2:], page
        m = re.search(r"av(\d+)", text, re.I)
        if m:
            return "av" + m.group(1), page
        if text.startswith(("https://b23.tv/", "http://b23.tv/")):
            req = urllib.request.Request(text, headers={"User-Agent": UA}, method="GET")
            with urllib.request.urlopen(req, timeout=12) as resp:
                target = resp.geturl()
            return BilibiliVideoClient._parse_ref(target)
        raise RuntimeError("无法识别 B站视频号。")

    def _video_info(self, ref: str) -> dict[str, Any]:
        vid, page = self._parse_ref(ref)
        key = "bvid" if vid.startswith("BV") else "aid"
        data = _json("https://api.bilibili.com/x/web-interface/view?" + urllib.parse.urlencode({key: vid if key == "bvid" else vid[2:]}), headers=self.headers)
        pages = data.get("pages") or []
        selected = next((p for p in pages if int(p.get("page", 1)) == page), None)
        selected = selected or (pages[0] if pages else {})
        cid = selected.get("cid", data.get("cid"))
        if not cid:
            raise RuntimeError("B站视频没有可用的分P信息。")
        title = str(selected.get("part") or data.get("title") or "B站视频")
        owner = str((data.get("owner") or {}).get("name") or "B站视频")
        return {"bvid": data.get("bvid") or vid, "cid": int(cid), "title": title, "artist": owner}

    def _playurl(self, bvid: str, cid: int) -> str:
        params = {"bvid": bvid, "cid": cid, "fnval": 4048, "fnver": 0, "fourk": 1}
        url = self._wbi_url("https://api.bilibili.com/x/player/wbi/playurl", params)
        try:
            data = _json(url, headers=self.headers)
        except BilibiliApiError as exc:
            # -101 is an explicit login gate, not a WBI-signature problem. Retrying
            # the legacy endpoint only repeats the same auth failure and hides the
            # useful reason from the candidate-selection loop.
            if exc.code == -101:
                raise
            # Keep the legacy endpoint as a compatibility fallback for WBI failures.
            data = _json("https://api.bilibili.com/x/player/playurl?" + urllib.parse.urlencode(params), headers=self.headers)
        audios = (data.get("dash") or {}).get("audio") or []
        audios = sorted(audios, key=lambda a: int(a.get("bandwidth") or 0), reverse=True)
        for audio in audios:
            candidate = audio.get("baseUrl") or audio.get("base_url")
            if candidate:
                return candidate
        raise RuntimeError("该视频没有可用的独立音频流。")

    def resolve(self, title: str, artist: str = "") -> tuple[str, str, str, str]:
        keyword = " ".join(x for x in (title.strip(), artist.strip()) if x).strip()
        if not keyword:
            raise RuntimeError("歌曲名称为空，无法搜索 B站视频。")
        search_url = self._wbi_url("https://api.bilibili.com/x/web-interface/wbi/search/type", {
            "search_type": "video", "keyword": keyword, "page": 1, "page_size": 10,
        })
        try:
            data = _json(search_url, headers={**self.headers, "Referer": "https://search.bilibili.com/"})
        except BilibiliApiError as exc:
            if exc.code == -101:
                raise RuntimeError(
                    "B站搜索接口要求登录（code=-101）。请在「账号与平台」页面扫码登录B站视频备用源账号后重试。"
                ) from exc
            raise
        results = (data.get("result") or [])
        if not results:
            raise RuntimeError(f"B站没有搜索到《{title}》的视频。")

        # Search ranking's first item is not necessarily publicly playable. In
        # particular, a high-ranked result may return -101 (login required), be
        # unavailable, or expose no DASH audio. Try several candidates instead
        # of treating the first result as the only possible backup source.
        login_gated = 0
        unavailable = 0
        failures: list[str] = []
        seen: set[str] = set()
        for candidate in results[:10]:
            bvid = str(candidate.get("bvid") or "").strip()
            if not bvid or bvid in seen:
                continue
            seen.add(bvid)
            try:
                info = self._video_info(bvid)
                stream = self._playurl(info["bvid"], info["cid"])
                return stream, info["title"] or title, info["artist"] or artist, info["bvid"]
            except BilibiliApiError as exc:
                if exc.code == -101:
                    login_gated += 1
                    continue
                if exc.code in (-404, -403):
                    unavailable += 1
                    continue
                # Rate limits and WBI/signature errors are global failures;
                # continuing would only send more requests and risk more blocks.
                raise
            except RuntimeError as exc:
                message = str(exc)
                if "没有可用的独立音频流" in message or "没有可用的分P信息" in message:
                    unavailable += 1
                    continue
                failures.append(message)

        if login_gated and login_gated == len(seen):
            raise RuntimeError(
                f"B站搜索到的 {login_gated} 个候选视频均要求登录（code=-101）。"
                "请在「账号与平台」页面扫码登录B站视频备用源账号后重试。"
            )
        if login_gated or unavailable:
            raise RuntimeError(
                f"B站已检查 {len(seen)} 个候选视频，其中 {login_gated} 个要求登录、"
                f"{unavailable} 个不可用或没有独立音频流；没有找到可播放的视频。"
            )
        if failures:
            raise RuntimeError("B站候选视频解析失败：" + failures[0])
        raise RuntimeError("B站搜索结果没有包含可解析的视频编号。")


class _BiliProxyServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class BilibiliStreamProxy:
    """Loopback-only byte-range proxy that injects Bilibili's required Referer."""
    def __init__(self):
        self._lock = threading.Lock()
        self._streams: dict[str, str] = {}
        owner = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"
            def log_message(self, *_args):
                return
            def do_GET(self):
                token = self.path.rsplit("/", 1)[-1]
                with owner._lock:
                    target = owner._streams.get(token)
                if not target:
                    self.send_error(404)
                    return
                headers = {"User-Agent": UA, "Referer": "https://www.bilibili.com/"}
                if self.headers.get("Range"):
                    headers["Range"] = self.headers["Range"]
                req = urllib.request.Request(target, headers=headers)
                try:
                    upstream = urllib.request.urlopen(req, timeout=30)
                except urllib.error.HTTPError as exc:
                    upstream = exc
                except Exception:
                    self.send_error(502, "Bilibili upstream unavailable")
                    return
                with upstream:
                    status = getattr(upstream, "status", 200)
                    self.send_response(status)
                    for name in ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges", "Cache-Control"):
                        value = upstream.headers.get(name)
                        if value:
                            self.send_header(name, value)
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.send_header("Connection", "close")
                    self.end_headers()
                    try:
                        while True:
                            chunk = upstream.read(128 * 1024)
                            if not chunk:
                                break
                            self.wfile.write(chunk)
                    except (BrokenPipeError, ConnectionResetError):
                        pass
        self.server = _BiliProxyServer(("127.0.0.1", 0), Handler)
        self.port = self.server.server_address[1]
        self.thread = threading.Thread(target=self.server.serve_forever, name="BiliMusic-BiliProxy", daemon=True)
        self.thread.start()

    def register(self, remote_url: str) -> str:
        token = secrets.token_urlsafe(24)
        with self._lock:
            self._streams[token] = remote_url
            # Keep the process-local URL registry bounded during long live sessions.
            while len(self._streams) > 128:
                self._streams.pop(next(iter(self._streams)))
        return f"http://127.0.0.1:{self.port}/stream/{token}"


_PROXY: BilibiliStreamProxy | None = None
_PROXY_LOCK = threading.Lock()

def local_bilibili_stream(remote_url: str) -> str:
    global _PROXY
    with _PROXY_LOCK:
        if _PROXY is None:
            _PROXY = BilibiliStreamProxy()
        return _PROXY.register(remote_url)
