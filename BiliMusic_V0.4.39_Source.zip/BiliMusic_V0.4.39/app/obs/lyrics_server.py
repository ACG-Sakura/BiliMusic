from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import sys
from typing import Any


PROJECT_ROOT = Path(__file__).resolve().parents[2]
RESOURCE_ROOT = Path(getattr(sys, "_MEIPASS", PROJECT_ROOT))
HTML_PATH = RESOURCE_ROOT / "app" / "obs" / "lyrics.html"
FONT_PATH = RESOURCE_ROOT / "assets" / "lyrics_font.ttf"

DEFAULT_OVERLAY_STATE: dict[str, Any] = {
    "enabled": False,
    "title": "",
    "artist": "",
    "current": "",
    "next": "",
    "background": "transparent",
    "background_opacity": 0.22,
    "alignment": "center",
    "current_color": "#FFFFFF",
    "next_color": "#DCE5F2",
    "current_size": 38,
    "next_size": 25,
}


def normalize_state(state: dict[str, Any] | None) -> dict[str, Any]:
    value = dict(DEFAULT_OVERLAY_STATE)
    if state:
        value.update(state)
    value["alignment"] = value["alignment"] if value["alignment"] in {"left", "center", "right"} else "center"
    value["background"] = value["background"] if value["background"] in {"transparent", "translucent"} else "transparent"
    for key, low, high in (("background_opacity", 0.05, 0.65), ("current_size", 20, 72), ("next_size", 14, 48)):
        try:
            value[key] = max(low, min(high, float(value[key]) if key == "background_opacity" else int(value[key])))
        except (TypeError, ValueError):
            value[key] = DEFAULT_OVERLAY_STATE[key]
    for key in ("current_color", "next_color"):
        color = str(value.get(key, ""))
        if len(color) != 7 or not color.startswith("#") or any(c not in "0123456789abcdefABCDEF" for c in color[1:]):
            value[key] = DEFAULT_OVERLAY_STATE[key]
    for key in ("enabled", "title", "artist", "current", "next"):
        value[key] = bool(value[key]) if key == "enabled" else str(value[key] or "")
    return value


class _ReusableThreadingHTTPServer(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True


class ObsLyricsServer:
    """Loopback-only HTTP server for OBS Browser Source and its live state endpoint."""

    def __init__(self):
        self._state = normalize_state(None)
        self._lock = threading.Lock()
        self._server: _ReusableThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None

    @property
    def running(self) -> bool:
        return self._server is not None

    @property
    def port(self) -> int | None:
        return self._server.server_address[1] if self._server else None

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self.port}/lyrics" if self.port else ""

    def update(self, state: dict[str, Any]) -> None:
        with self._lock:
            self._state = normalize_state(state)

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return dict(self._state)

    def start(self) -> str:
        if self._server:
            return self.url
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):  # noqa: N802
                if self.path == "/lyrics" or self.path == "/lyrics/":
                    self._send_file(HTML_PATH, "text/html; charset=utf-8")
                elif self.path == "/state":
                    payload = json.dumps(owner.snapshot(), ensure_ascii=False).encode("utf-8")
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json; charset=utf-8")
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.send_header("Content-Length", str(len(payload)))
                    self.end_headers()
                    self.wfile.write(payload)
                elif self.path == "/assets/lyrics_font.ttf":
                    self._send_file(FONT_PATH, "font/ttf")
                elif self.path == "/health":
                    payload = b'{"ok":true}'
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Content-Length", str(len(payload)))
                    self.end_headers()
                    self.wfile.write(payload)
                else:
                    self.send_error(404)

            def _send_file(self, path: Path, content_type: str):
                if not path.is_file():
                    self.send_error(404)
                    return
                payload = path.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", content_type)
                self.send_header("Cache-Control", "no-cache")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)

            def log_message(self, _format, *_args):
                return

        self._server = _ReusableThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self._thread = threading.Thread(target=self._server.serve_forever, name="BiliMusic-OBS-HTTP", daemon=True)
        self._thread.start()
        return self.url

    def stop(self) -> None:
        server, thread = self._server, self._thread
        self._server = None
        self._thread = None
        if server:
            server.shutdown()
            server.server_close()
        if thread and thread.is_alive():
            thread.join(timeout=2)
