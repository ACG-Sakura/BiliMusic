"""Local OBS browser-source integration."""
