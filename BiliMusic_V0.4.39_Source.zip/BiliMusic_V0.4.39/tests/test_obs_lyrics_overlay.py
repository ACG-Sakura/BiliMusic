from __future__ import annotations

import json
from pathlib import Path
from urllib.request import urlopen

from app.obs.lyrics_server import ObsLyricsServer, normalize_state


def test_overlay_state_defaults_and_validation():
    state = normalize_state({
        "alignment": "diagonal", "background": "gradient",
        "current_color": "red", "current_size": 999,
        "next_size": 1, "background_opacity": 2,
    })
    assert state["alignment"] == "center"
    assert state["background"] == "transparent"
    assert state["current_color"] == "#FFFFFF"
    assert state["current_size"] == 72
    assert state["next_size"] == 14
    assert state["background_opacity"] == 0.65


def test_obs_server_serves_overlay_state_html_and_font():
    server = ObsLyricsServer()
    server.update({"enabled": True, "current": "当前歌词", "next": "下一行"})
    base = server.start()
    try:
        with urlopen(base.replace("/lyrics", "/health"), timeout=2) as response:
            assert json.loads(response.read()) == {"ok": True}
        with urlopen(base.replace("/lyrics", "/state"), timeout=2) as response:
            state = json.loads(response.read())
            assert state["enabled"] is True
            assert state["current"] == "当前歌词"
            assert state["next"] == "下一行"
        with urlopen(base, timeout=2) as response:
            html = response.read().decode("utf-8")
            assert "@font-face" in html
            assert "setInterval(poll,250)" in html
            assert "marquee" in html
        with urlopen(base.replace("/lyrics", "/assets/lyrics_font.ttf"), timeout=3) as response:
            assert response.headers.get_content_type() == "font/ttf"
            assert len(response.read()) > 1_000_000
    finally:
        server.stop()


def test_obs_font_asset_is_in_project():
    root = Path(__file__).parents[1]
    assert (root / "assets" / "lyrics_font.ttf").is_file()
    assert (root / "app" / "obs" / "lyrics.html").is_file()
