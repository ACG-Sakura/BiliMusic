# Changelog

## V0.3.0 — 官方接入基础框架（预览）
- 将 V0.2.0 标记为本地功能验收通过版本；模拟消息、点歌队列、规则处理及既有 UI 由用户在 Windows 实机验收通过。
- 新增 B站直播开放平台 REST 客户端，覆盖官方文档中的 `/v2/app/start`、`/v2/app/heartbeat` 和 `/v2/app/end` 生命周期接口。
- 新增带 HMAC-SHA256 签名头的 API 请求模块；请求体按实际发送字节计算 MD5。
- 新增 WSS 长连接后台线程、鉴权包、消息包解析、项目心跳和备用 WSS 节点尝试。
- 新增官方事件适配层，将 DM、SC、大航海、礼物、点赞、进房和开/下播事件统一映射到内部消息模型。
- 新增 Windows DPAPI 凭证存储。access_secret、access_key、app_id 和主播身份码不写入 SQLite、普通 JSON 或日志。
- 新增「B站开放平台」页面，提供凭证安全保存、官方连接/断开及消息处理结果展示。
- 真实联调仍需 B站开发者审核、项目授权、主播身份码和相应消息类型权限；尚未用真实凭证完成联调，因此此接入标记为预览，不能视为已验证可用。
- 纯 Windows 桌面端 client 模式的产品形态要求仍需向 B站开放平台确认；文档指出 Web 开发者需自建服务端，其他开发者应使用官方 API 或联系平台。

## V0.2.0 — 本地功能验收通过（2026-11-22）
- 用户已在 Windows 实机确认桌面功能测试正常；此版本作为后续开发基线。
- 点歌弹幕格式为 `点歌 歌名 歌手`；歌手可省略。
- 新增「B站消息测试」页面与本地模拟消息工作流，模拟弹幕和 SC 会经过共享解析器、点歌规则和 SQLite 队列。
- 模拟内容不会连接真实 B站，也不会伪装真实连接状态。

## V0.1.4.2
- Fixed the post-drop blank/stale queue row: custom QDrag now carries a stable song ID without invoking Qt base-class source-row cleanup.
- Defer persistence and QTableWidget refresh until QDrag.exec() returns, then restore selection to the moved song.

## V0.1.4.1
- Fixed drag-and-drop queue ordering by moving songs through stable database IDs instead of Qt's native cell-level InternalMove behavior.
- A drop onto a row now inserts the dragged song at that row's position and persists the complete queue order.
- Added tests for dragging a song to the first/last position and invalid drag targets.

## V0.1.4
- Set the UI to a fixed blue-white light theme.
- Updated cooldown defaults and removed global cooldown.
- Added confirmed queue deletion and drag-and-drop ordering.

## V0.4.0
- Added local playlist catalogue for NetEase Cloud Music and QQ Music.
- Added playlist source URL/ID metadata, local track management, play-mode settings, active playlist selection, and autoplay preference persistence.
- Added tests for playlist CRUD, track CRUD, settings persistence, and input validation.
- Explicitly does not scrape playlist pages, access protected audio, download music, or bypass platform membership/payment controls. Actual platform synchronization and audio playback remain future authorized integrations.
