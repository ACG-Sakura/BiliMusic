@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Please run run_windows.bat once to create the virtual environment.
  pause
  exit /b 1
)
call .venv\Scripts\activate.bat
pip install -r requirements-dev.txt
if errorlevel 1 goto :error
pyinstaller --noconfirm --clean --windowed --onedir --name BiliMusic --collect-all PySide6 main.py
if errorlevel 1 goto :error
echo.
echo Build complete: dist\BiliMusic\BiliMusic.exe
echo Note: This is a development build, not a signed production installer.
pause
exit /b 0
:error
echo Build failed. See the error message above.
pause
exit /b 1
