# BiliMusic release status

- V0.1.4.2: accepted baseline for the original queue UI and drag sorting.
- V0.2.0: local message simulation and queue-rule workflow accepted by user.
- V0.3.0: Windows build accepted for local preview; real Bilibili Open Live end-to-end connection remains pending platform approval and permission validation.
- V0.4.0: playlist catalogue and autoplay-policy configuration preview. Platform playlist synchronization and actual audio playback are not included yet.
