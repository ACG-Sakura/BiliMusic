"""Music platform integration boundary."""
