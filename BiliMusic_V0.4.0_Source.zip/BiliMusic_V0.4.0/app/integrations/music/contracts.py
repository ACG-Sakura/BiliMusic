"""Music playback integration contract.

Only official or otherwise explicitly permitted account authorization and playback
mechanisms may be implemented by concrete providers. Do not persist cookies/tokens
in SQLite or plain-text settings files.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True, slots=True)
class Track:
    provider: str
    track_id: str
    title: str
    artist: str = ""
    duration_seconds: int | None = None


class MusicProvider(Protocol):
    provider_name: str

    def login(self) -> None: ...
    def logout(self) -> None: ...
    def is_authenticated(self) -> bool: ...
    def search(self, keyword: str) -> list[Track]: ...
    def play(self, track: Track) -> None: ...
    def pause(self) -> None: ...
    def resume(self) -> None: ...
    def stop(self) -> None: ...


class ProviderNotConfigured(RuntimeError):
    pass
