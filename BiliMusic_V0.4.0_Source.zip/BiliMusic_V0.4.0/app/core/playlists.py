from __future__ import annotations

from dataclasses import dataclass
from app.storage.database import Database


@dataclass(frozen=True, slots=True)
class Playlist:
    id: int
    name: str
    platform: str
    source_ref: str
    play_mode: str
    enabled: bool
    track_count: int


@dataclass(frozen=True, slots=True)
class PlaylistTrack:
    id: int
    playlist_id: int
    title: str
    artist: str
    source_ref: str
    position: int


class PlaylistService:
    """Local playlist catalogue. It never extracts or downloads protected audio."""
    MODES = {"顺序播放", "列表循环", "随机播放"}

    def __init__(self, database: Database):
        self.db = database
        with self.db.session() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS playlists (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    platform TEXT NOT NULL CHECK(platform IN ('网易云音乐','QQ音乐')),
                    source_ref TEXT NOT NULL DEFAULT '',
                    play_mode TEXT NOT NULL DEFAULT '顺序播放',
                    enabled INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
                );
                CREATE TABLE IF NOT EXISTS playlist_tracks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    playlist_id INTEGER NOT NULL REFERENCES playlists(id) ON DELETE CASCADE,
                    title TEXT NOT NULL,
                    artist TEXT NOT NULL DEFAULT '',
                    source_ref TEXT NOT NULL DEFAULT '',
                    position INTEGER NOT NULL DEFAULT 0,
                    UNIQUE(playlist_id, position)
                );
                CREATE TABLE IF NOT EXISTS playlist_settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                INSERT OR IGNORE INTO playlist_settings(key,value) VALUES ('autoplay_enabled','0');
                INSERT OR IGNORE INTO playlist_settings(key,value) VALUES ('active_playlist_id','');
            """)

    def add_playlist(self, name: str, platform: str, source_ref: str = "") -> int:
        name = name.strip()
        if not name:
            raise ValueError("歌单名称不能为空")
        if platform not in {"网易云音乐", "QQ音乐"}:
            raise ValueError("不支持的音乐平台")
        return self.db.execute("INSERT INTO playlists(name,platform,source_ref) VALUES(?,?,?)", (name, platform, source_ref.strip()))

    def list_playlists(self) -> list[Playlist]:
        rows = self.db.fetchall("""SELECT p.*, COUNT(t.id) AS track_count FROM playlists p
            LEFT JOIN playlist_tracks t ON t.playlist_id=p.id GROUP BY p.id ORDER BY p.id DESC""")
        return [Playlist(int(r['id']),r['name'],r['platform'],r['source_ref'],r['play_mode'],bool(r['enabled']),int(r['track_count'])) for r in rows]

    def remove_playlist(self, playlist_id: int) -> None:
        with self.db.session() as conn:
            conn.execute("DELETE FROM playlist_tracks WHERE playlist_id=?", (playlist_id,))
            conn.execute("DELETE FROM playlists WHERE id=?", (playlist_id,))
            conn.execute("UPDATE playlist_settings SET value='' WHERE key='active_playlist_id' AND value=?", (str(playlist_id),))

    def add_track(self, playlist_id: int, title: str, artist: str = "", source_ref: str = "") -> int:
        title = title.strip()
        if not title:
            raise ValueError("歌曲名称不能为空")
        pos = self.db.fetchone("SELECT COALESCE(MAX(position),-1)+1 AS n FROM playlist_tracks WHERE playlist_id=?", (playlist_id,))["n"]
        return self.db.execute("INSERT INTO playlist_tracks(playlist_id,title,artist,source_ref,position) VALUES(?,?,?,?,?)", (playlist_id,title,artist.strip(),source_ref.strip(),int(pos)))

    def list_tracks(self, playlist_id: int) -> list[PlaylistTrack]:
        rows = self.db.fetchall("SELECT * FROM playlist_tracks WHERE playlist_id=? ORDER BY position,id", (playlist_id,))
        return [PlaylistTrack(int(r['id']),int(r['playlist_id']),r['title'],r['artist'],r['source_ref'],int(r['position'])) for r in rows]

    def remove_track(self, track_id: int) -> None:
        self.db.execute("DELETE FROM playlist_tracks WHERE id=?", (track_id,))

    def set_mode(self, playlist_id: int, mode: str) -> None:
        if mode not in self.MODES:
            raise ValueError("无效的播放模式")
        self.db.execute("UPDATE playlists SET play_mode=? WHERE id=?", (mode, playlist_id))

    def set_active(self, playlist_id: int | None) -> None:
        if playlist_id is not None and not self.db.fetchone("SELECT id FROM playlists WHERE id=?", (playlist_id,)):
            raise ValueError("歌单不存在")
        self.db.execute("UPDATE playlist_settings SET value=? WHERE key='active_playlist_id'", (str(playlist_id or ''),))

    def active_playlist_id(self) -> int | None:
        value = self.db.fetchone("SELECT value FROM playlist_settings WHERE key='active_playlist_id'")["value"]
        return int(value) if value else None

    def set_autoplay(self, enabled: bool) -> None:
        self.db.execute("UPDATE playlist_settings SET value=? WHERE key='autoplay_enabled'", ('1' if enabled else '0',))

    def autoplay_enabled(self) -> bool:
        return self.db.fetchone("SELECT value FROM playlist_settings WHERE key='autoplay_enabled'")["value"] == '1'
