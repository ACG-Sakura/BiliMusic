# Third-party references and notices

BiliMusic V0.1.1 contains no source code copied from the reference repositories listed below. They are acknowledged as design and technical research references only.

- AwooMusicBot — https://github.com/Enkianssus/AwooMusicBot
- BiliHUD — https://github.com/locez/bilihud
- blivedm — https://github.com/xfgryujk/blivedm
- NekoFM — https://github.com/7starsseeker/nekofm

If code from any third-party project is incorporated in a later release, its license, notices, dependencies, and applicable platform terms must be reviewed and preserved before distribution.
