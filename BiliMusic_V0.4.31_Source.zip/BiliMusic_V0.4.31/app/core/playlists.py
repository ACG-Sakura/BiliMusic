from __future__ import annotations

import random
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from app.storage.database import Database


AUDIO_EXTENSIONS = {".mp3", ".wav", ".flac", ".m4a", ".aac", ".ogg", ".opus", ".wma"}


@dataclass(frozen=True, slots=True)
class Playlist:
    id: int
    name: str
    platform: str
    source_ref: str
    play_mode: str
    enabled: bool
    track_count: int


@dataclass(frozen=True, slots=True)
class PlaylistTrack:
    id: int
    playlist_id: int
    title: str
    artist: str
    source_ref: str
    position: int


@dataclass(frozen=True, slots=True)
class LocalAudioTrack:
    id: int
    title: str
    artist: str
    file_path: str
    position: int


class PlaylistService:
    """Local playlist catalog plus user-selected local audio files.

    NetEase records contain metadata and song IDs. Temporary streaming URLs are
    resolved at playback time and are never persisted in this catalog.
    """
    MODES = {"顺序播放", "列表循环", "随机播放"}

    def __init__(self, database: Database):
        self.db = database
        with self.db.session() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS playlists (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    platform TEXT NOT NULL CHECK(platform IN ('网易云音乐')),
                    source_ref TEXT NOT NULL DEFAULT '',
                    play_mode TEXT NOT NULL DEFAULT '顺序播放',
                    enabled INTEGER NOT NULL DEFAULT 1,
                    cover_url TEXT NOT NULL DEFAULT '',
                    description TEXT NOT NULL DEFAULT '',
                    last_synced_at TEXT NOT NULL DEFAULT '',
                    sync_status TEXT NOT NULL DEFAULT '未同步',
                    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
                );
                CREATE TABLE IF NOT EXISTS playlist_tracks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    playlist_id INTEGER NOT NULL REFERENCES playlists(id) ON DELETE CASCADE,
                    title TEXT NOT NULL,
                    artist TEXT NOT NULL DEFAULT '',
                    source_ref TEXT NOT NULL DEFAULT '',
                    position INTEGER NOT NULL DEFAULT 0,
                    external_url TEXT NOT NULL DEFAULT '',
                    synced INTEGER NOT NULL DEFAULT 0,
                    UNIQUE(playlist_id, position)
                );
                CREATE TABLE IF NOT EXISTS playlist_settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS local_audio_tracks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    artist TEXT NOT NULL DEFAULT '',
                    file_path TEXT NOT NULL UNIQUE,
                    position INTEGER NOT NULL DEFAULT 0,
                    added_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
                );
                CREATE TABLE IF NOT EXISTS playback_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    artist TEXT NOT NULL DEFAULT '',
                    source TEXT NOT NULL,
                    requester_name TEXT NOT NULL DEFAULT '',
                    result TEXT NOT NULL,
                    file_path TEXT NOT NULL DEFAULT '',
                    started_at TEXT NOT NULL,
                    ended_at TEXT NOT NULL
                );
                INSERT OR IGNORE INTO playlist_settings(key,value) VALUES ('autoplay_enabled','0');
                INSERT OR IGNORE INTO playlist_settings(key,value) VALUES ('active_playlist_id','');
                INSERT OR IGNORE INTO playlist_settings(key,value) VALUES ('local_audio_mode','顺序播放');
            """)
            self._ensure_columns(conn, "playlists", {
                "cover_url": "TEXT NOT NULL DEFAULT ''",
                "description": "TEXT NOT NULL DEFAULT ''",
                "last_synced_at": "TEXT NOT NULL DEFAULT ''",
                "sync_status": "TEXT NOT NULL DEFAULT '未同步'",
            })
            self._ensure_columns(conn, "playlist_tracks", {
                "external_url": "TEXT NOT NULL DEFAULT ''",
                "synced": "INTEGER NOT NULL DEFAULT 0",
            })

    @staticmethod
    def _ensure_columns(conn: sqlite3.Connection, table: str, definitions: dict[str, str]) -> None:
        existing = {row["name"] for row in conn.execute(f"PRAGMA table_info({table})")}
        for name, definition in definitions.items():
            if name not in existing:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {definition}")

    def add_playlist(self, name: str, platform: str, source_ref: str = "") -> int:
        name = name.strip()
        if not name:
            raise ValueError("歌单名称不能为空")
        if platform != "网易云音乐":
            raise ValueError("V0.4.311 仅支持网易云音乐。")
        return self.db.execute(
            "INSERT INTO playlists(name,platform,source_ref) VALUES(?,?,?)",
            (name, platform, source_ref.strip()),
        )

    def list_playlists(self) -> list[Playlist]:
        # Old QQ Music rows are retained in SQLite for rollback/data safety, but
        # are hidden from the NetEase-only UI and cannot be selected for playback.
        rows = self.db.fetchall("""SELECT p.*, COUNT(t.id) AS track_count FROM playlists p
            LEFT JOIN playlist_tracks t ON t.playlist_id=p.id
            WHERE p.platform='网易云音乐' GROUP BY p.id ORDER BY p.id DESC""")
        return [Playlist(int(r['id']), r['name'], r['platform'], r['source_ref'],
                         r['play_mode'], bool(r['enabled']), int(r['track_count'])) for r in rows]

    def get_playlist(self, playlist_id: int):
        return self.db.fetchone("SELECT * FROM playlists WHERE id=?", (playlist_id,))

    def remove_playlist(self, playlist_id: int) -> None:
        with self.db.session() as conn:
            conn.execute("DELETE FROM playlist_tracks WHERE playlist_id=?", (playlist_id,))
            conn.execute("DELETE FROM playlists WHERE id=?", (playlist_id,))
            conn.execute("UPDATE playlist_settings SET value='' WHERE key='active_playlist_id' AND value=?", (str(playlist_id),))

    def add_track(self, playlist_id: int, title: str, artist: str = "", source_ref: str = "") -> int:
        title = title.strip()
        if not title:
            raise ValueError("歌曲名称不能为空")
        pos = self.db.fetchone("SELECT COALESCE(MAX(position),-1)+1 AS n FROM playlist_tracks WHERE playlist_id=?", (playlist_id,))["n"]
        return self.db.execute(
            "INSERT INTO playlist_tracks(playlist_id,title,artist,source_ref,position) VALUES(?,?,?,?,?)",
            (playlist_id, title, artist.strip(), source_ref.strip(), int(pos)),
        )

    def list_tracks(self, playlist_id: int) -> list[PlaylistTrack]:
        rows = self.db.fetchall("SELECT * FROM playlist_tracks WHERE playlist_id=? ORDER BY position,id", (playlist_id,))
        return [PlaylistTrack(int(r['id']), int(r['playlist_id']), r['title'], r['artist'], r['source_ref'], int(r['position'])) for r in rows]

    def replace_synced_tracks(self, playlist_id: int, remote_playlist) -> int:
        """Replace a remote metadata snapshot transactionally; never store audio URLs."""
        tracks = remote_playlist.tracks
        with self.db.session() as conn:
            playlist = conn.execute("SELECT id, name FROM playlists WHERE id=?", (playlist_id,)).fetchone()
            if playlist is None:
                raise ValueError("歌单不存在")
            conn.execute("DELETE FROM playlist_tracks WHERE playlist_id=?", (playlist_id,))
            for position, track in enumerate(tracks):
                conn.execute(
                    "INSERT INTO playlist_tracks(playlist_id,title,artist,source_ref,position,external_url,synced) VALUES(?,?,?,?,?,?,1)",
                    (playlist_id, track.title, track.artist, track.external_id, position, track.external_url),
                )
            conn.execute(
                "UPDATE playlists SET name=?,description=?,cover_url=?,last_synced_at=?,sync_status='同步成功' WHERE id=?",
                (getattr(remote_playlist, "name", "") or playlist["name"],
                 getattr(remote_playlist, "description", ""), getattr(remote_playlist, "cover_url", ""),
                 datetime.now(timezone.utc).isoformat(timespec="seconds"), playlist_id),
            )
        return len(tracks)

    def set_sync_error(self, playlist_id: int, reason: str) -> None:
        safe_reason = (reason or "同步失败").replace("\n", " ")[:180]
        self.db.execute("UPDATE playlists SET sync_status=? WHERE id=?", (f"同步失败：{safe_reason}", playlist_id))

    def remove_track(self, track_id: int) -> None:
        self.db.execute("DELETE FROM playlist_tracks WHERE id=?", (track_id,))

    def set_mode(self, playlist_id: int, mode: str) -> None:
        if mode not in self.MODES:
            raise ValueError("无效的播放模式")
        self.db.execute("UPDATE playlists SET play_mode=? WHERE id=?", (mode, playlist_id))

    def set_active(self, playlist_id: int | None) -> None:
        if playlist_id is not None and not self.db.fetchone("SELECT id FROM playlists WHERE id=?", (playlist_id,)):
            raise ValueError("歌单不存在")
        self.db.execute("UPDATE playlist_settings SET value=? WHERE key='active_playlist_id'", (str(playlist_id or ''),))

    def active_playlist_id(self) -> int | None:
        value = self.db.fetchone("SELECT value FROM playlist_settings WHERE key='active_playlist_id'")["value"]
        return int(value) if value else None

    def active_playlist_tracks(self) -> tuple[int | None, str, list[PlaylistTrack]]:
        """Return the active NetEase playlist ID, mode, and synced track snapshot."""
        playlist_id = self.active_playlist_id()
        if playlist_id is None:
            return None, "顺序播放", []
        row = self.db.fetchone("SELECT platform,play_mode,enabled FROM playlists WHERE id=?", (playlist_id,))
        if row is None or row["platform"] != "网易云音乐" or not bool(row["enabled"]):
            return None, "顺序播放", []
        return playlist_id, str(row["play_mode"]), self.list_tracks(playlist_id)

    def set_autoplay(self, enabled: bool) -> None:
        self.db.execute("UPDATE playlist_settings SET value=? WHERE key='autoplay_enabled'", ('1' if enabled else '0',))

    def autoplay_enabled(self) -> bool:
        return self.db.fetchone("SELECT value FROM playlist_settings WHERE key='autoplay_enabled'")["value"] == '1'

    def set_local_audio_mode(self, mode: str) -> None:
        if mode not in self.MODES:
            raise ValueError("无效的本地音频播放模式")
        self.db.execute("UPDATE playlist_settings SET value=? WHERE key='local_audio_mode'", (mode,))

    def local_audio_mode(self) -> str:
        return self.db.fetchone("SELECT value FROM playlist_settings WHERE key='local_audio_mode'")["value"]

    def add_local_audio_files(self, paths: list[str | Path]) -> int:
        added = 0
        for raw_path in paths:
            path = Path(raw_path).expanduser().resolve()
            if not path.is_file() or path.suffix.lower() not in AUDIO_EXTENSIONS:
                continue
            title = path.stem.strip() or path.name
            existing = self.db.fetchone("SELECT id FROM local_audio_tracks WHERE file_path=?", (str(path),))
            if existing:
                continue
            position = self.db.fetchone("SELECT COALESCE(MAX(position),-1)+1 AS n FROM local_audio_tracks")["n"]
            self.db.execute(
                "INSERT INTO local_audio_tracks(title,artist,file_path,position) VALUES(?,?,?,?)",
                (title, "", str(path), int(position)),
            )
            added += 1
        return added

    def list_local_audio_tracks(self) -> list[LocalAudioTrack]:
        rows = self.db.fetchall("SELECT * FROM local_audio_tracks ORDER BY position,id")
        return [LocalAudioTrack(int(r['id']), r['title'], r['artist'], r['file_path'], int(r['position'])) for r in rows]

    def remove_local_audio_track(self, track_id: int) -> None:
        self.db.execute("DELETE FROM local_audio_tracks WHERE id=?", (track_id,))

    def update_local_audio_track(self, track_id: int, title: str, artist: str = "") -> None:
        clean_title = (title or "").strip()
        if not clean_title:
            raise ValueError("歌曲名称不能为空")
        cursor = self.db.execute(
            "UPDATE local_audio_tracks SET title=?,artist=? WHERE id=?",
            (clean_title, (artist or "").strip(), track_id),
        )
        if not cursor:
            exists = self.db.fetchone("SELECT id FROM local_audio_tracks WHERE id=?", (track_id,))
            if exists is None:
                raise ValueError("本地音频记录不存在")

    @staticmethod
    def _norm(value: str) -> str:
        return "".join((value or "").casefold().split())

    def find_local_audio(self, title: str, artist: str = "") -> LocalAudioTrack | None:
        target_title = self._norm(title)
        target_artist = self._norm(artist)
        for track in self.list_local_audio_tracks():
            if self._norm(track.title) != target_title:
                continue
            if target_artist and track.artist and self._norm(track.artist) != target_artist:
                continue
            if Path(track.file_path).is_file():
                return track
        return None

    def record_playback(self, title: str, artist: str, source: str, requester_name: str,
                        result: str, file_path: str, started_at: str, ended_at: str) -> None:
        self.db.execute(
            "INSERT INTO playback_history(title,artist,source,requester_name,result,file_path,started_at,ended_at) VALUES(?,?,?,?,?,?,?,?)",
            (title, artist, source, requester_name, result, file_path, started_at, ended_at),
        )

    def playback_history(self, limit: int = 100):
        return self.db.fetchall("SELECT * FROM playback_history ORDER BY id DESC LIMIT ?", (max(1, min(limit, 1000)),))
